package com.bikeservice.config;

import com.bikeservice.enums.UserRole;
import com.bikeservice.model.User;
import com.bikeservice.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * Creates a default ADMIN user on first startup if none exists.
 * Default credentials:
 *   Email   : admin@bikeservice.com
 *   Password: admin123
 *
 * Change the password immediately after first login!
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        if (!userRepository.existsByEmail("admin@bikeservice.com")) {
            User admin = User.builder()
                    .name("System Admin")
                    .email("admin@bikeservice.com")
                    .password(passwordEncoder.encode("admin123"))
                    .phone("9999999999")
                    .role(UserRole.ADMIN)
                    .active(true)
                    .build();
            userRepository.save(admin);
            log.info("========================================================");
            log.info("  Default ADMIN user created:");
            log.info("  Email   : admin@bikeservice.com");
            log.info("  Password: admin123");
            log.info("  Please change the password after first login!");
            log.info("========================================================");
        }
    }
}
