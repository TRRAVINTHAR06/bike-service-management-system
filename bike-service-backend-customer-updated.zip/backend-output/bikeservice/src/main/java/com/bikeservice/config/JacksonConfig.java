package com.bikeservice.config;

import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.hibernate6.Hibernate6Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.boot.autoconfigure.jackson.Jackson2ObjectMapperBuilderCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JacksonConfig {

    /**
     * Customizes Spring Boot's existing ObjectMapper instead of replacing it.
     *
     * FIX 1: Removed raw `new ObjectMapper()` @Bean — creating a new ObjectMapper
     *         as a @Bean conflicts with Spring Boot's auto-configured one, causing
     *         NoUniqueBeanDefinitionException or breaking MVC message converters.
     *
     * FIX 2: Removed Hibernate6Module.Feature.SERIALIZE_IDENTIFIER_FOR_MISSING_SUBTYPE —
     *         this feature does NOT exist in Hibernate6Module (it was in the old
     *         Hibernate5Module and was removed). Using it causes a runtime
     *         NoSuchFieldError / IllegalArgumentException on application startup.
     *
     * FIX 3: Using Jackson2ObjectMapperBuilderCustomizer — the correct Spring Boot
     *         way to configure Jackson. This hooks into the existing pipeline and
     *         ensures all MVC converters, Swagger, and other integrations still work.
     */
    @Bean
    public Jackson2ObjectMapperBuilderCustomizer jacksonCustomizer() {
        return builder -> {
            // Handle Hibernate lazy-loaded proxies — serialize as null instead of throwing
            Hibernate6Module hibernate6Module = new Hibernate6Module();
            hibernate6Module.configure(Hibernate6Module.Feature.FORCE_LAZY_LOADING, false);
            hibernate6Module.configure(Hibernate6Module.Feature.WRITE_MISSING_ENTITIES_AS_NULL, true);
            builder.modulesToInstall(hibernate6Module);

            // Handle Java 8 date/time types (LocalDateTime, LocalDate, etc.)
            builder.modulesToInstall(new JavaTimeModule());
            builder.featuresToDisable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

            // Prevent serialization failure on empty beans
            builder.featuresToDisable(SerializationFeature.FAIL_ON_EMPTY_BEANS);
        };
    }
}
