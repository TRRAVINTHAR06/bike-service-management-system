package com.bikeservice.config;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtAuthFilter jwtAuthFilter;
    private final UserDetailsServiceImpl userDetailsService;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(AbstractHttpConfigurer::disable)
            .cors(cors -> {})
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/auth/**").permitAll()
                .requestMatchers("/api/customer/auth/**").permitAll()
                .requestMatchers("/swagger-ui/**", "/api-docs/**", "/swagger-ui.html").permitAll()
                // Customer-only APIs
                .requestMatchers("/api/customer/**").hasRole("CUSTOMER")
                // Admin-only APIs
                .requestMatchers("/api/users/**").hasRole("ADMIN")
                .requestMatchers("/api/branches/**").hasAnyRole("ADMIN", "BRANCH_MANAGER")
                // Staff APIs — deny CUSTOMER
                .requestMatchers("/api/job-cards/**").hasAnyRole("ADMIN", "BRANCH_MANAGER", "SERVICE_ADVISOR", "TECHNICIAN", "QC_INSPECTOR", "ACCOUNTS", "STORE_INCHARGE")
                .requestMatchers("/api/inventory/**").hasAnyRole("ADMIN", "BRANCH_MANAGER", "STORE_INCHARGE", "ACCOUNTS")
                .requestMatchers("/api/parts/**").hasAnyRole("ADMIN", "BRANCH_MANAGER", "STORE_INCHARGE", "SERVICE_ADVISOR")
                .requestMatchers("/api/qc/**").hasAnyRole("ADMIN", "BRANCH_MANAGER", "QC_INSPECTOR")
                .requestMatchers("/api/dashboard/**").hasAnyRole("ADMIN", "BRANCH_MANAGER", "ACCOUNTS")
                .anyRequest().authenticated()
            )
            .sessionManagement(session ->
                session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authenticationProvider(authenticationProvider())
            .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    @Bean
    public AuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(userDetailsService);
        provider.setPasswordEncoder(passwordEncoder());
        return provider;
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config)
            throws Exception {
        return config.getAuthenticationManager();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
