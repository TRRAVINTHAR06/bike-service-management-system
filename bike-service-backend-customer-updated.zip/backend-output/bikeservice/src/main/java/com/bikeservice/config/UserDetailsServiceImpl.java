package com.bikeservice.config;

import com.bikeservice.model.CustomerUser;
import com.bikeservice.model.User;
import com.bikeservice.repository.CustomerUserRepository;
import com.bikeservice.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class UserDetailsServiceImpl implements UserDetailsService {

    private final UserRepository userRepository;
    private final CustomerUserRepository customerUserRepository;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        // Check staff users first
        var userOpt = userRepository.findByEmail(email);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            return new org.springframework.security.core.userdetails.User(
                    user.getEmail(),
                    user.getPassword(),
                    user.isActive(),
                    true, true, true,
                    List.of(new SimpleGrantedAuthority("ROLE_" + user.getRole().name()))
            );
        }

        // Check customer users
        CustomerUser customerUser = customerUserRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found: " + email));

        return new org.springframework.security.core.userdetails.User(
                customerUser.getEmail(),
                customerUser.getPassword(),
                customerUser.isActive(),
                true, true, true,
                List.of(new SimpleGrantedAuthority("ROLE_CUSTOMER"))
        );
    }
}
