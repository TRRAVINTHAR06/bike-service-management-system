package com.bikeservice.controller;

import com.bikeservice.config.JwtUtils;
import com.bikeservice.dto.ApiResponse;
import com.bikeservice.dto.request.ForgotPasswordRequest;
import com.bikeservice.dto.request.LoginRequest;
import com.bikeservice.dto.request.ResetPasswordRequest;
import com.bikeservice.dto.request.UserRequest;
import com.bikeservice.model.PasswordResetToken;
import com.bikeservice.model.User;
import com.bikeservice.repository.PasswordResetTokenRepository;
import com.bikeservice.repository.UserRepository;
import com.bikeservice.service.EmailService;
import jakarta.validation.Valid;
import lombok.*;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.*;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final JwtUtils jwtUtils;
    private final UserDetailsService userDetailsService;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final PasswordResetTokenRepository tokenRepository;
    private final EmailService emailService;

    // ─── Login ───────────────────────────────────────────────────────────────
    @PostMapping("/login")
    public ResponseEntity<ApiResponse<AuthResponse>> login(@Valid @RequestBody LoginRequest request) {
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword()));

        UserDetails userDetails = userDetailsService.loadUserByUsername(request.getEmail());
        String token = jwtUtils.generateToken(userDetails);

        User user = userRepository.findByEmail(request.getEmail()).orElseThrow();

        return ResponseEntity.ok(ApiResponse.success("Login successful",
                new AuthResponse(token, user.getName(), user.getEmail(), user.getRole().name())));
    }

    // ─── Register ─────────────────────────────────────────────────────────────
    @PostMapping("/register")
    public ResponseEntity<ApiResponse<String>> register(@Valid @RequestBody UserRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Email already registered"));
        }
        User user = User.builder()
                .name(request.getName())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .phone(request.getPhone())
                .role(request.getRole())
                .active(true)
                .build();
        userRepository.save(user);
        return ResponseEntity.ok(ApiResponse.success("User registered successfully", null));
    }

    // ─── Forgot Password ──────────────────────────────────────────────────────
    /**
     * POST /api/auth/forgot-password
     * Generates a reset token and emails a link to the user.
     * Always returns success to avoid email enumeration.
     */
    @PostMapping("/forgot-password")
    public ResponseEntity<ApiResponse<String>> forgotPassword(
            @Valid @RequestBody ForgotPasswordRequest request) {

        Optional<User> userOpt = userRepository.findByEmail(request.getEmail());

        if (userOpt.isPresent()) {
            User user = userOpt.get();

            // Remove any existing tokens for this user
            tokenRepository.deleteAllByUserId(user.getId());

            // Create a new 30-minute token
            String rawToken = UUID.randomUUID().toString();
            PasswordResetToken resetToken = PasswordResetToken.builder()
                    .token(rawToken)
                    .user(user)
                    .expiresAt(LocalDateTime.now().plusMinutes(30))
                    .used(false)
                    .build();
            tokenRepository.save(resetToken);

            emailService.sendPasswordResetEmail(user.getEmail(), rawToken);
        }

        // Always return success (prevents email enumeration)
        return ResponseEntity.ok(ApiResponse.success(
                "If that email exists, a reset link has been sent.", null));
    }

    // ─── Reset Password ───────────────────────────────────────────────────────
    /**
     * POST /api/auth/reset-password
     * Validates the token and sets the new password.
     */
    @PostMapping("/reset-password")
    public ResponseEntity<ApiResponse<String>> resetPassword(
            @Valid @RequestBody ResetPasswordRequest request) {

        PasswordResetToken resetToken = tokenRepository.findByToken(request.getToken())
                .orElse(null);

        if (resetToken == null || resetToken.isUsed() || resetToken.isExpired()) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Reset link is invalid or has expired. Please request a new one."));
        }

        User user = resetToken.getUser();
        user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        userRepository.save(user);

        resetToken.setUsed(true);
        tokenRepository.save(resetToken);

        return ResponseEntity.ok(ApiResponse.success("Password reset successfully. You can now sign in.", null));
    }

    // ─── Response DTO ─────────────────────────────────────────────────────────
    @Getter @Setter @AllArgsConstructor
    public static class AuthResponse {
        private String token;
        private String name;
        private String email;
        private String role;
    }
}
