package com.bikeservice.controller;

import com.bikeservice.dto.ApiResponse;
import com.bikeservice.exception.ResourceNotFoundException;
import com.bikeservice.model.Bay;
import com.bikeservice.model.Branch;
import com.bikeservice.repository.BayRepository;
import com.bikeservice.service.BranchService;
import lombok.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bays")
@RequiredArgsConstructor
public class BayController {

    private final BayRepository bayRepository;
    private final BranchService branchService;

    @PostMapping
    public ResponseEntity<ApiResponse<Bay>> createBay(@RequestBody BayRequest request) {
        Branch branch = branchService.getBranchById(request.getBranchId());
        Bay bay = Bay.builder()
                .branch(branch)
                .bayNo(request.getBayNo())
                .bayType(request.getBayType())
                .status("AVAILABLE")
                .active(true)
                .build();
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Bay created", bayRepository.save(bay)));
    }

    @GetMapping("/branch/{branchId}")
    public ResponseEntity<ApiResponse<List<Bay>>> getBaysByBranch(@PathVariable Long branchId) {
        return ResponseEntity.ok(ApiResponse.success(bayRepository.findByBranchId(branchId)));
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<ApiResponse<Bay>> updateBayStatus(@PathVariable Long id,
                                                              @RequestParam String status) {
        Bay bay = bayRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Bay not found: " + id));
        bay.setStatus(status);
        return ResponseEntity.ok(ApiResponse.success("Bay status updated", bayRepository.save(bay)));
    }

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor
    public static class BayRequest {
        private Long branchId;
        private String bayNo;
        private String bayType;
    }
}
