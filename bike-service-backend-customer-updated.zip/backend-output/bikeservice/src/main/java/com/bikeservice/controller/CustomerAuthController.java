package com.bikeservice.controller;

import com.bikeservice.config.JwtUtils;
import com.bikeservice.dto.ApiResponse;
import com.bikeservice.dto.request.CustomerRegisterRequest;
import com.bikeservice.dto.request.LoginRequest;
import com.bikeservice.model.Customer;
import com.bikeservice.model.CustomerUser;
import com.bikeservice.repository.CustomerRepository;
import com.bikeservice.repository.CustomerUserRepository;
import jakarta.validation.Valid;
import lombok.*;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.*;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/customer/auth")
@RequiredArgsConstructor
public class CustomerAuthController {

    private final AuthenticationManager authenticationManager;
    private final JwtUtils jwtUtils;
    private final UserDetailsService userDetailsService;
    private final CustomerUserRepository customerUserRepository;
    private final CustomerRepository customerRepository;
    private final PasswordEncoder passwordEncoder;

    @PostMapping("/register")
    public ResponseEntity<ApiResponse<String>> register(
            @Valid @RequestBody CustomerRegisterRequest request) {

        if (customerUserRepository.existsByEmail(request.getEmail())) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Email already registered"));
        }

        // Create a Customer record (admin-visible)
        Customer customer = Customer.builder()
                .name(request.getName())
                .phone(request.getPhone() != null ? request.getPhone() : "N/A")
                .email(request.getEmail())
                .address(request.getAddress())
                .city(request.getCity())
                .build();
        customer = customerRepository.save(customer);

        // Create login account
        CustomerUser customerUser = CustomerUser.builder()
                .name(request.getName())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .phone(request.getPhone())
                .address(request.getAddress())
                .city(request.getCity())
                .customer(customer)
                .active(true)
                .build();
        customerUserRepository.save(customerUser);

        return ResponseEntity.ok(ApiResponse.success("Registration successful! Please login.", null));
    }

    @PostMapping("/login")
    public ResponseEntity<ApiResponse<AuthResponse>> login(
            @Valid @RequestBody LoginRequest request) {
        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword()));
        } catch (BadCredentialsException e) {
            return ResponseEntity.badRequest().body(ApiResponse.error("Invalid email or password"));
        }

        CustomerUser customerUser = customerUserRepository.findByEmail(request.getEmail())
                .orElse(null);
        if (customerUser == null) {
            return ResponseEntity.badRequest().body(ApiResponse.error("Not a customer account. Use staff login."));
        }

        UserDetails userDetails = userDetailsService.loadUserByUsername(request.getEmail());
        String token = jwtUtils.generateToken(userDetails);

        Long customerId = customerUser.getCustomer() != null ? customerUser.getCustomer().getId() : null;

        return ResponseEntity.ok(ApiResponse.success("Login successful",
                new AuthResponse(token, customerUser.getName(), customerUser.getEmail(),
                        "CUSTOMER", customerUser.getId(), customerId)));
    }

    @Getter @Setter @AllArgsConstructor
    public static class AuthResponse {
        private String token;
        private String name;
        private String email;
        private String role;
        private Long customerUserId;
        private Long customerId;
    }
}
