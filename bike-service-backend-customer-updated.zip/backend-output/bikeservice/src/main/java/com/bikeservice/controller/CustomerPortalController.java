package com.bikeservice.controller;

import com.bikeservice.dto.ApiResponse;
import com.bikeservice.dto.request.AppointmentRequest;
import com.bikeservice.dto.request.FeedbackRequest;
import com.bikeservice.dto.request.ModificationRequestDto;
import com.bikeservice.dto.request.VehicleRequest;
import com.bikeservice.exception.ResourceNotFoundException;
import com.bikeservice.model.*;
import com.bikeservice.repository.*;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/customer")
@PreAuthorize("hasRole('CUSTOMER')")
@RequiredArgsConstructor
public class CustomerPortalController {

    private final CustomerUserRepository customerUserRepository;
    private final CustomerRepository customerRepository;
    private final VehicleRepository vehicleRepository;
    private final AppointmentRepository appointmentRepository;
    private final JobCardRepository jobCardRepository;
    private final InvoiceRepository invoiceRepository;
    private final PaymentRepository paymentRepository;
    private final FeedbackRepository feedbackRepository;
    private final ModificationRequestRepository modificationRequestRepository;
    private final BranchRepository branchRepository;

    // ─── Profile ──────────────────────────────────────────────────────────────
    @GetMapping("/profile")
    public ResponseEntity<ApiResponse<CustomerUser>> getProfile(Authentication auth) {
        CustomerUser cu = getCustomerUser(auth);
        return ResponseEntity.ok(ApiResponse.success("Profile fetched", cu));
    }

    @PutMapping("/profile")
    public ResponseEntity<ApiResponse<CustomerUser>> updateProfile(
            Authentication auth, @RequestBody CustomerUser updates) {
        CustomerUser cu = getCustomerUser(auth);
        if (updates.getName() != null) cu.setName(updates.getName());
        if (updates.getPhone() != null) cu.setPhone(updates.getPhone());
        if (updates.getAddress() != null) cu.setAddress(updates.getAddress());
        if (updates.getCity() != null) cu.setCity(updates.getCity());
        customerUserRepository.save(cu);
        return ResponseEntity.ok(ApiResponse.success("Profile updated", cu));
    }

    // ─── Bikes ────────────────────────────────────────────────────────────────
    @GetMapping("/bikes")
    public ResponseEntity<ApiResponse<List<Vehicle>>> getBikes(Authentication auth) {
        CustomerUser cu = getCustomerUser(auth);
        if (cu.getCustomer() == null) return ResponseEntity.ok(ApiResponse.success("No bikes", List.of()));
        List<Vehicle> vehicles = vehicleRepository.findByCustomerId(cu.getCustomer().getId());
        return ResponseEntity.ok(ApiResponse.success("Bikes fetched", vehicles));
    }

    @PostMapping("/bikes")
    public ResponseEntity<ApiResponse<Vehicle>> addBike(
            Authentication auth, @Valid @RequestBody VehicleRequest request) {
        CustomerUser cu = getCustomerUser(auth);
        Customer customer = cu.getCustomer();
        if (customer == null) {
            return ResponseEntity.badRequest().body(ApiResponse.error("Customer profile not linked"));
        }
        if (vehicleRepository.existsByChassisNo(request.getChassisNo())) {
            return ResponseEntity.badRequest().body(ApiResponse.error("Chassis number already registered"));
        }
        Vehicle vehicle = Vehicle.builder()
                .customer(customer)
                .chassisNo(request.getChassisNo())
                .engineNo(request.getEngineNo())
                .regNo(request.getRegNo())
                .make(request.getMake())
                .model(request.getModel())
                .year(request.getYear())
                .color(request.getColor())
                .odometer(request.getOdometer())
                .fuelType(request.getFuelType())
                .build();
        vehicleRepository.save(vehicle);
        return ResponseEntity.ok(ApiResponse.success("Bike added", vehicle));
    }

    @PutMapping("/bikes/{id}")
    public ResponseEntity<ApiResponse<Vehicle>> updateBike(
            Authentication auth, @PathVariable Long id, @RequestBody VehicleRequest request) {
        CustomerUser cu = getCustomerUser(auth);
        Vehicle vehicle = vehicleRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Vehicle not found"));
        if (cu.getCustomer() == null || !vehicle.getCustomer().getId().equals(cu.getCustomer().getId())) {
            return ResponseEntity.status(403).body(ApiResponse.error("Access denied"));
        }
        if (request.getMake() != null) vehicle.setMake(request.getMake());
        if (request.getModel() != null) vehicle.setModel(request.getModel());
        if (request.getColor() != null) vehicle.setColor(request.getColor());
        if (request.getOdometer() != null) vehicle.setOdometer(request.getOdometer());
        if (request.getRegNo() != null) vehicle.setRegNo(request.getRegNo());
        vehicleRepository.save(vehicle);
        return ResponseEntity.ok(ApiResponse.success("Bike updated", vehicle));
    }

    @DeleteMapping("/bikes/{id}")
    public ResponseEntity<ApiResponse<String>> deleteBike(Authentication auth, @PathVariable Long id) {
        CustomerUser cu = getCustomerUser(auth);
        Vehicle vehicle = vehicleRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Vehicle not found"));
        if (cu.getCustomer() == null || !vehicle.getCustomer().getId().equals(cu.getCustomer().getId())) {
            return ResponseEntity.status(403).body(ApiResponse.error("Access denied"));
        }
        vehicleRepository.delete(vehicle);
        return ResponseEntity.ok(ApiResponse.success("Bike removed", null));
    }

    // ─── Appointments ─────────────────────────────────────────────────────────
    @GetMapping("/appointments")
    public ResponseEntity<ApiResponse<List<Appointment>>> getAppointments(Authentication auth) {
        CustomerUser cu = getCustomerUser(auth);
        if (cu.getCustomer() == null) return ResponseEntity.ok(ApiResponse.success("No appointments", List.of()));
        List<Appointment> appointments = appointmentRepository.findByCustomerId(cu.getCustomer().getId());
        return ResponseEntity.ok(ApiResponse.success("Appointments fetched", appointments));
    }

    @PostMapping("/appointments")
    public ResponseEntity<ApiResponse<Appointment>> bookAppointment(
            Authentication auth, @Valid @RequestBody AppointmentRequest request) {
        CustomerUser cu = getCustomerUser(auth);
        if (cu.getCustomer() == null) {
            return ResponseEntity.badRequest().body(ApiResponse.error("Customer profile not linked"));
        }
        Branch branch = branchRepository.findById(request.getBranchId())
                .orElseThrow(() -> new ResourceNotFoundException("Branch not found"));
        Vehicle vehicle = vehicleRepository.findById(request.getVehicleId())
                .orElseThrow(() -> new ResourceNotFoundException("Vehicle not found"));
        if (!vehicle.getCustomer().getId().equals(cu.getCustomer().getId())) {
            return ResponseEntity.status(403).body(ApiResponse.error("Vehicle does not belong to you"));
        }
        Appointment appointment = Appointment.builder()
                .branch(branch)
                .customer(cu.getCustomer())
                .vehicle(vehicle)
                .slotTime(request.getSlotTime())
                .serviceType(request.getServiceType())
                .remarks(request.getRemarks())
                .pickupRequired(request.isPickupRequired())
                .pickupAddress(request.getPickupAddress())
                .build();
        appointmentRepository.save(appointment);
        return ResponseEntity.ok(ApiResponse.success("Appointment booked", appointment));
    }

    // ─── Service History ──────────────────────────────────────────────────────
    @GetMapping("/service-history")
    public ResponseEntity<ApiResponse<List<JobCard>>> getServiceHistory(Authentication auth) {
        CustomerUser cu = getCustomerUser(auth);
        if (cu.getCustomer() == null) return ResponseEntity.ok(ApiResponse.success("No history", List.of()));
        List<JobCard> jobCards = jobCardRepository.findByCustomerId(cu.getCustomer().getId());
        return ResponseEntity.ok(ApiResponse.success("Service history fetched", jobCards));
    }

    @GetMapping("/service-history/{jobCardId}")
    public ResponseEntity<ApiResponse<JobCard>> getServiceDetail(
            Authentication auth, @PathVariable Long jobCardId) {
        CustomerUser cu = getCustomerUser(auth);
        JobCard jobCard = jobCardRepository.findById(jobCardId)
                .orElseThrow(() -> new ResourceNotFoundException("Job card not found"));
        if (cu.getCustomer() == null || !jobCard.getCustomer().getId().equals(cu.getCustomer().getId())) {
            return ResponseEntity.status(403).body(ApiResponse.error("Access denied"));
        }
        return ResponseEntity.ok(ApiResponse.success("Job card fetched", jobCard));
    }

    // ─── Status Tracking ──────────────────────────────────────────────────────
    @GetMapping("/status")
    public ResponseEntity<ApiResponse<List<Map<String, Object>>>> trackStatus(Authentication auth) {
        CustomerUser cu = getCustomerUser(auth);
        if (cu.getCustomer() == null) return ResponseEntity.ok(ApiResponse.success("No active jobs", List.of()));
        List<JobCard> jobCards = jobCardRepository.findByCustomerId(cu.getCustomer().getId());
        List<Map<String, Object>> statuses = jobCards.stream()
                .filter(jc -> jc.getStatus() != null)
                .map(jc -> Map.<String, Object>of(
                        "jobCardId", jc.getId(),
                        "jobCardNo", jc.getJobCardNo(),
                        "status", jc.getStatus().name(),
                        "vehicleMake", jc.getVehicle().getMake(),
                        "vehicleModel", jc.getVehicle().getModel(),
                        "checkInTime", jc.getCheckInTime() != null ? jc.getCheckInTime().toString() : ""
                ))
                .toList();
        return ResponseEntity.ok(ApiResponse.success("Status fetched", statuses));
    }

    // ─── Billing & Invoices ───────────────────────────────────────────────────
    @GetMapping("/invoices")
    public ResponseEntity<ApiResponse<List<Invoice>>> getInvoices(Authentication auth) {
        CustomerUser cu = getCustomerUser(auth);
        if (cu.getCustomer() == null) return ResponseEntity.ok(ApiResponse.success("No invoices", List.of()));
        List<Invoice> invoices = invoiceRepository.findByCustomerId(cu.getCustomer().getId());
        return ResponseEntity.ok(ApiResponse.success("Invoices fetched", invoices));
    }

    @GetMapping("/invoices/{invoiceId}/payments")
    public ResponseEntity<ApiResponse<List<Payment>>> getPaymentsForInvoice(
            Authentication auth, @PathVariable Long invoiceId) {
        CustomerUser cu = getCustomerUser(auth);
        Invoice invoice = invoiceRepository.findById(invoiceId)
                .orElseThrow(() -> new ResourceNotFoundException("Invoice not found"));
        if (cu.getCustomer() == null || !invoice.getCustomer().getId().equals(cu.getCustomer().getId())) {
            return ResponseEntity.status(403).body(ApiResponse.error("Access denied"));
        }
        List<Payment> payments = paymentRepository.findByInvoiceId(invoiceId);
        return ResponseEntity.ok(ApiResponse.success("Payments fetched", payments));
    }

    // ─── Feedback ─────────────────────────────────────────────────────────────
    @PostMapping("/feedback")
    public ResponseEntity<ApiResponse<Feedback>> submitFeedback(
            Authentication auth, @Valid @RequestBody FeedbackRequest request) {
        CustomerUser cu = getCustomerUser(auth);
        if (feedbackRepository.existsByJobCardId(request.getJobCardId())) {
            return ResponseEntity.badRequest().body(ApiResponse.error("Feedback already submitted for this job card"));
        }
        JobCard jobCard = jobCardRepository.findById(request.getJobCardId())
                .orElseThrow(() -> new ResourceNotFoundException("Job card not found"));
        if (cu.getCustomer() == null || !jobCard.getCustomer().getId().equals(cu.getCustomer().getId())) {
            return ResponseEntity.status(403).body(ApiResponse.error("Access denied"));
        }
        Feedback feedback = Feedback.builder()
                .customerUser(cu)
                .jobCard(jobCard)
                .rating(request.getRating())
                .comments(request.getComments())
                .serviceQuality(request.getServiceQuality())
                .staffBehavior(request.getStaffBehavior())
                .overallExperience(request.getOverallExperience())
                .build();
        feedbackRepository.save(feedback);
        return ResponseEntity.ok(ApiResponse.success("Feedback submitted", feedback));
    }

    @GetMapping("/feedback")
    public ResponseEntity<ApiResponse<List<Feedback>>> getMyFeedback(Authentication auth) {
        CustomerUser cu = getCustomerUser(auth);
        return ResponseEntity.ok(ApiResponse.success("Feedback fetched",
                feedbackRepository.findByCustomerUserId(cu.getId())));
    }

    // ─── Modification Requests ────────────────────────────────────────────────
    @PostMapping("/modification-requests")
    public ResponseEntity<ApiResponse<ModificationRequest>> submitModificationRequest(
            Authentication auth, @Valid @RequestBody ModificationRequestDto request) {
        CustomerUser cu = getCustomerUser(auth);
        JobCard jobCard = jobCardRepository.findById(request.getJobCardId())
                .orElseThrow(() -> new ResourceNotFoundException("Job card not found"));
        if (cu.getCustomer() == null || !jobCard.getCustomer().getId().equals(cu.getCustomer().getId())) {
            return ResponseEntity.status(403).body(ApiResponse.error("Access denied"));
        }
        ModificationRequest mod = ModificationRequest.builder()
                .customerUser(cu)
                .jobCard(jobCard)
                .requestDetails(request.getRequestDetails())
                .additionalNotes(request.getAdditionalNotes())
                .status("PENDING")
                .build();
        modificationRequestRepository.save(mod);
        return ResponseEntity.ok(ApiResponse.success("Modification request submitted", mod));
    }

    @GetMapping("/modification-requests")
    public ResponseEntity<ApiResponse<List<ModificationRequest>>> getModificationRequests(Authentication auth) {
        CustomerUser cu = getCustomerUser(auth);
        return ResponseEntity.ok(ApiResponse.success("Requests fetched",
                modificationRequestRepository.findByCustomerUserId(cu.getId())));
    }

    // ─── Branches (public info for booking) ──────────────────────────────────
    @GetMapping("/branches")
    public ResponseEntity<ApiResponse<List<Branch>>> getActiveBranches() {
        return ResponseEntity.ok(ApiResponse.success("Branches fetched", branchRepository.findAll()));
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────
    private CustomerUser getCustomerUser(Authentication auth) {
        return customerUserRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new ResourceNotFoundException("Customer user not found"));
    }
}
