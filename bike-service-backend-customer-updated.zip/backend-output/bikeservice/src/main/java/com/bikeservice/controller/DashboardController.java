package com.bikeservice.controller;

import com.bikeservice.dto.ApiResponse;
import com.bikeservice.enums.JobCardStatus;
import com.bikeservice.repository.InvoiceRepository;
import com.bikeservice.repository.JobCardRepository;
import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/dashboard")
@RequiredArgsConstructor
public class DashboardController {

    private final JobCardRepository jobCardRepository;
    private final InvoiceRepository invoiceRepository;

    @GetMapping("/branch/{branchId}/summary")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getBranchSummary(
            @PathVariable Long branchId) {

        Map<String, Object> summary = new HashMap<>();
        summary.put("totalJobCards",    jobCardRepository.findByBranchId(branchId).size());
        summary.put("created",          jobCardRepository.countByBranchAndStatus(branchId, JobCardStatus.CREATED));
        summary.put("inProgress",       jobCardRepository.countByBranchAndStatus(branchId, JobCardStatus.IN_PROGRESS));
        summary.put("readyForDelivery", jobCardRepository.countByBranchAndStatus(branchId, JobCardStatus.READY_FOR_DELIVERY));
        summary.put("delivered",        jobCardRepository.countByBranchAndStatus(branchId, JobCardStatus.DELIVERED));
        summary.put("qcPending",        jobCardRepository.countByBranchAndStatus(branchId, JobCardStatus.QC_PENDING));

        return ResponseEntity.ok(ApiResponse.success(summary));
    }

    @GetMapping("/branch/{branchId}/revenue")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getRevenue(
            @PathVariable Long branchId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime to) {

        BigDecimal revenue = invoiceRepository.sumRevenueByBranchAndDateRange(branchId, from, to);
        long invoiceCount = invoiceRepository.findByBranchAndDateRange(branchId, from, to).size();

        Map<String, Object> result = new HashMap<>();
        result.put("totalRevenue", revenue != null ? revenue : BigDecimal.ZERO);
        result.put("invoiceCount", invoiceCount);
        result.put("from", from);
        result.put("to", to);

        return ResponseEntity.ok(ApiResponse.success(result));
    }
}
