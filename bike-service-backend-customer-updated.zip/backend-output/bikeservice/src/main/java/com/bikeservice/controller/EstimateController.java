package com.bikeservice.controller;

import com.bikeservice.dto.ApiResponse;
import com.bikeservice.dto.request.EstimateRequest;
import com.bikeservice.model.Estimate;
import com.bikeservice.service.EstimateService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/estimates")
@RequiredArgsConstructor
public class EstimateController {

    private final EstimateService estimateService;

    @PostMapping
    public ResponseEntity<ApiResponse<Estimate>> createEstimate(@Valid @RequestBody EstimateRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Estimate created", estimateService.createEstimate(request)));
    }

    @GetMapping("/job-card/{jobCardId}")
    public ResponseEntity<ApiResponse<Estimate>> getEstimateByJobCard(@PathVariable Long jobCardId) {
        return ResponseEntity.ok(ApiResponse.success(estimateService.getEstimateByJobCard(jobCardId)));
    }

    @PatchMapping("/job-card/{jobCardId}/approve")
    public ResponseEntity<ApiResponse<Estimate>> approveEstimate(@PathVariable Long jobCardId,
                                                                   @RequestParam String approvedBy) {
        return ResponseEntity.ok(ApiResponse.success("Estimate approved",
                estimateService.approveEstimate(jobCardId, approvedBy)));
    }

    @PatchMapping("/job-card/{jobCardId}/reject")
    public ResponseEntity<ApiResponse<Estimate>> rejectEstimate(@PathVariable Long jobCardId,
                                                                  @RequestParam String remarks) {
        return ResponseEntity.ok(ApiResponse.success("Estimate rejected",
                estimateService.rejectEstimate(jobCardId, remarks)));
    }
}
