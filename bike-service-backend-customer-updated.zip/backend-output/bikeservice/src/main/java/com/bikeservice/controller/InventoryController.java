package com.bikeservice.controller;

import com.bikeservice.dto.ApiResponse;
import com.bikeservice.dto.request.InventoryRequest;
import com.bikeservice.model.Inventory;
import com.bikeservice.service.InventoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/inventory")
@RequiredArgsConstructor
public class InventoryController {

    private final InventoryService inventoryService;

    @PostMapping
    public ResponseEntity<ApiResponse<Inventory>> addOrUpdateStock(@RequestBody InventoryRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Stock updated",
                inventoryService.addOrUpdateStock(request)));
    }

    @GetMapping("/branch/{branchId}")
    public ResponseEntity<ApiResponse<List<Inventory>>> getStockByBranch(@PathVariable Long branchId) {
        return ResponseEntity.ok(ApiResponse.success(inventoryService.getStockByBranch(branchId)));
    }

    @GetMapping("/branch/{branchId}/low-stock")
    public ResponseEntity<ApiResponse<List<Inventory>>> getLowStock(@PathVariable Long branchId) {
        return ResponseEntity.ok(ApiResponse.success(inventoryService.getLowStockAlerts(branchId)));
    }

    @GetMapping("/branch/{branchId}/part/{partId}")
    public ResponseEntity<ApiResponse<Inventory>> getStock(@PathVariable Long branchId,
                                                            @PathVariable Long partId) {
        return ResponseEntity.ok(ApiResponse.success(inventoryService.getStock(branchId, partId)));
    }

    @PatchMapping("/branch/{branchId}/part/{partId}/add")
    public ResponseEntity<ApiResponse<Void>> addStock(@PathVariable Long branchId,
                                                        @PathVariable Long partId,
                                                        @RequestParam int qty) {
        inventoryService.addStock(branchId, partId, qty);
        return ResponseEntity.ok(ApiResponse.success("Stock added", null));
    }
}
