package com.bikeservice.controller;

import com.bikeservice.dto.ApiResponse;
import com.bikeservice.dto.request.PaymentRequest;
import com.bikeservice.model.Invoice;
import com.bikeservice.model.Payment;
import com.bikeservice.service.InvoiceService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/invoices")
@RequiredArgsConstructor
public class InvoiceController {

    private final InvoiceService invoiceService;

    @PostMapping("/generate/{jobCardId}")
    public ResponseEntity<ApiResponse<Invoice>> generateInvoice(@PathVariable Long jobCardId) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Invoice generated", invoiceService.generateInvoice(jobCardId)));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<Invoice>> getInvoiceById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(invoiceService.getInvoiceById(id)));
    }

    @GetMapping("/job-card/{jobCardId}")
    public ResponseEntity<ApiResponse<Invoice>> getInvoiceByJobCard(@PathVariable Long jobCardId) {
        return ResponseEntity.ok(ApiResponse.success(invoiceService.getInvoiceByJobCard(jobCardId)));
    }

    @GetMapping("/customer/{customerId}")
    public ResponseEntity<ApiResponse<List<Invoice>>> getInvoicesByCustomer(@PathVariable Long customerId) {
        return ResponseEntity.ok(ApiResponse.success(invoiceService.getInvoicesByCustomer(customerId)));
    }

    @PostMapping("/payments")
    public ResponseEntity<ApiResponse<Payment>> recordPayment(@Valid @RequestBody PaymentRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Payment recorded", invoiceService.recordPayment(request)));
    }

    @GetMapping("/{invoiceId}/payments")
    public ResponseEntity<ApiResponse<List<Payment>>> getPayments(@PathVariable Long invoiceId) {
        return ResponseEntity.ok(ApiResponse.success(invoiceService.getPaymentsByInvoice(invoiceId)));
    }
}
