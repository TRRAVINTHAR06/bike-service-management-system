package com.bikeservice.controller;

import com.bikeservice.dto.ApiResponse;
import com.bikeservice.dto.request.JobCardRequest;
import com.bikeservice.dto.request.JobCardStatusRequest;
import com.bikeservice.enums.JobCardStatus;
import com.bikeservice.model.JobCard;
import com.bikeservice.service.JobCardService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/job-cards")
@RequiredArgsConstructor
public class JobCardController {

    private final JobCardService jobCardService;

    @PostMapping
    public ResponseEntity<ApiResponse<JobCard>> createJobCard(@Valid @RequestBody JobCardRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Job card created", jobCardService.createJobCard(request)));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<JobCard>> getJobCardById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(jobCardService.getJobCardById(id)));
    }

    @GetMapping("/no/{jobCardNo}")
    public ResponseEntity<ApiResponse<JobCard>> getJobCardByNo(@PathVariable String jobCardNo) {
        return ResponseEntity.ok(ApiResponse.success(jobCardService.getJobCardByNo(jobCardNo)));
    }

    @GetMapping("/branch/{branchId}")
    public ResponseEntity<ApiResponse<List<JobCard>>> getByBranch(@PathVariable Long branchId) {
        return ResponseEntity.ok(ApiResponse.success(jobCardService.getJobCardsByBranch(branchId)));
    }

    @GetMapping("/customer/{customerId}")
    public ResponseEntity<ApiResponse<List<JobCard>>> getByCustomer(@PathVariable Long customerId) {
        return ResponseEntity.ok(ApiResponse.success(jobCardService.getJobCardsByCustomer(customerId)));
    }

    @GetMapping("/vehicle/{vehicleId}")
    public ResponseEntity<ApiResponse<List<JobCard>>> getByVehicle(@PathVariable Long vehicleId) {
        return ResponseEntity.ok(ApiResponse.success(jobCardService.getJobCardsByVehicle(vehicleId)));
    }

    @GetMapping("/status/{status}")
    public ResponseEntity<ApiResponse<List<JobCard>>> getByStatus(@PathVariable JobCardStatus status) {
        return ResponseEntity.ok(ApiResponse.success(jobCardService.getJobCardsByStatus(status)));
    }

    @GetMapping("/branch/{branchId}/status/{status}")
    public ResponseEntity<ApiResponse<List<JobCard>>> getByBranchAndStatus(
            @PathVariable Long branchId, @PathVariable JobCardStatus status) {
        return ResponseEntity.ok(ApiResponse.success(
                jobCardService.getJobCardsByBranchAndStatus(branchId, status)));
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<ApiResponse<JobCard>> updateStatus(@PathVariable Long id,
                                                              @RequestBody JobCardStatusRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Status updated",
                jobCardService.updateStatus(id, request)));
    }

    @PatchMapping("/{id}/deliver")
    public ResponseEntity<ApiResponse<Void>> deliverJobCard(@PathVariable Long id,
                                                             @RequestParam(required = false) Integer odometerOut) {
        jobCardService.deliverJobCard(id, odometerOut);
        return ResponseEntity.ok(ApiResponse.success("Job card delivered", null));
    }
}
