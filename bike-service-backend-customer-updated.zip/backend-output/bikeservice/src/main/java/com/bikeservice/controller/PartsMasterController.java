package com.bikeservice.controller;

import com.bikeservice.dto.ApiResponse;
import com.bikeservice.dto.request.PartsMasterRequest;
import com.bikeservice.model.PartsMaster;
import com.bikeservice.service.PartsMasterService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/parts")
@RequiredArgsConstructor
public class PartsMasterController {

    private final PartsMasterService partsMasterService;

    @PostMapping
    public ResponseEntity<ApiResponse<PartsMaster>> createPart(@Valid @RequestBody PartsMasterRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Part created", partsMasterService.createPart(request)));
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<PartsMaster>>> getAllParts() {
        return ResponseEntity.ok(ApiResponse.success(partsMasterService.getAllActiveParts()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<PartsMaster>> getPartById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(partsMasterService.getPartById(id)));
    }

    @GetMapping("/search")
    public ResponseEntity<ApiResponse<List<PartsMaster>>> searchParts(@RequestParam String query) {
        return ResponseEntity.ok(ApiResponse.success(partsMasterService.searchParts(query)));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<PartsMaster>> updatePart(@PathVariable Long id,
                                                                @Valid @RequestBody PartsMasterRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Part updated", partsMasterService.updatePart(id, request)));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> deactivatePart(@PathVariable Long id) {
        partsMasterService.deactivatePart(id);
        return ResponseEntity.ok(ApiResponse.success("Part deactivated", null));
    }
}
