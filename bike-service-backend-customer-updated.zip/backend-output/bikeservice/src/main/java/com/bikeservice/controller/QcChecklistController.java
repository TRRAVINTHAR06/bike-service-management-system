package com.bikeservice.controller;

import com.bikeservice.dto.ApiResponse;
import com.bikeservice.dto.request.QcChecklistRequest;
import com.bikeservice.model.QcChecklist;
import com.bikeservice.service.QcChecklistService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/qc")
@RequiredArgsConstructor
public class QcChecklistController {

    private final QcChecklistService qcChecklistService;

    @PostMapping
    public ResponseEntity<ApiResponse<QcChecklist>> submitQc(@RequestBody QcChecklistRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("QC submitted", qcChecklistService.submitQc(request)));
    }

    @GetMapping("/job-card/{jobCardId}")
    public ResponseEntity<ApiResponse<QcChecklist>> getQcByJobCard(@PathVariable Long jobCardId) {
        return ResponseEntity.ok(ApiResponse.success(qcChecklistService.getQcByJobCard(jobCardId)));
    }
}
