package com.bikeservice.controller;

import com.bikeservice.dto.ApiResponse;
import com.bikeservice.dto.request.ServiceCatalogRequest;
import com.bikeservice.enums.ServiceType;
import com.bikeservice.model.ServiceCatalog;
import com.bikeservice.service.ServiceCatalogService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/services")
@RequiredArgsConstructor
public class ServiceCatalogController {

    private final ServiceCatalogService serviceCatalogService;

    @PostMapping
    public ResponseEntity<ApiResponse<ServiceCatalog>> createService(
            @Valid @RequestBody ServiceCatalogRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Service created",
                        serviceCatalogService.createService(request)));
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<ServiceCatalog>>> getAllServices() {
        return ResponseEntity.ok(ApiResponse.success(serviceCatalogService.getAllActiveServices()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<ServiceCatalog>> getServiceById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(serviceCatalogService.getServiceById(id)));
    }

    @GetMapping("/type/{type}")
    public ResponseEntity<ApiResponse<List<ServiceCatalog>>> getByType(@PathVariable ServiceType type) {
        return ResponseEntity.ok(ApiResponse.success(serviceCatalogService.getServicesByType(type)));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<ServiceCatalog>> updateService(@PathVariable Long id,
            @Valid @RequestBody ServiceCatalogRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Service updated",
                serviceCatalogService.updateService(id, request)));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> deactivateService(@PathVariable Long id) {
        serviceCatalogService.deactivateService(id);
        return ResponseEntity.ok(ApiResponse.success("Service deactivated", null));
    }
}
