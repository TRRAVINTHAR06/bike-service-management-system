package com.bikeservice.controller;

import com.bikeservice.dto.ApiResponse;
import com.bikeservice.dto.request.TechnicianAssignRequest;
import com.bikeservice.exception.ResourceNotFoundException;
import com.bikeservice.model.*;
import com.bikeservice.repository.*;
import com.bikeservice.service.JobCardService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/technician-assignments")
@RequiredArgsConstructor
public class TechnicianAssignmentController {

    private final TechnicianAssignmentRepository assignmentRepository;
    private final JobCardService jobCardService;
    private final UserRepository userRepository;
    private final BayRepository bayRepository;

    @PostMapping
    public ResponseEntity<ApiResponse<TechnicianAssignment>> assign(
            @RequestBody TechnicianAssignRequest request) {

        JobCard jobCard = jobCardService.getJobCardById(request.getJobCardId());
        User technician = userRepository.findById(request.getTechnicianId())
                .orElseThrow(() -> new ResourceNotFoundException("Technician not found"));

        Bay bay = null;
        if (request.getBayId() != null) {
            bay = bayRepository.findById(request.getBayId())
                    .orElseThrow(() -> new ResourceNotFoundException("Bay not found"));
            bay.setStatus("OCCUPIED");
            bayRepository.save(bay);
        }

        TechnicianAssignment assignment = TechnicianAssignment.builder()
                .jobCard(jobCard)
                .technician(technician)
                .bay(bay)
                .startTime(LocalDateTime.now())
                .stdMinutes(request.getStdMinutes())
                .status("ASSIGNED")
                .build();

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Technician assigned", assignmentRepository.save(assignment)));
    }

    @GetMapping("/job-card/{jobCardId}")
    public ResponseEntity<ApiResponse<List<TechnicianAssignment>>> getByJobCard(
            @PathVariable Long jobCardId) {
        return ResponseEntity.ok(ApiResponse.success(
                assignmentRepository.findByJobCardId(jobCardId)));
    }

    @GetMapping("/technician/{technicianId}")
    public ResponseEntity<ApiResponse<List<TechnicianAssignment>>> getByTechnician(
            @PathVariable Long technicianId) {
        return ResponseEntity.ok(ApiResponse.success(
                assignmentRepository.findByTechnicianId(technicianId)));
    }

    @PatchMapping("/{id}/complete")
    public ResponseEntity<ApiResponse<TechnicianAssignment>> completeAssignment(
            @PathVariable Long id, @RequestParam(required = false) Integer actualMinutes) {
        TechnicianAssignment assignment = assignmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Assignment not found: " + id));
        assignment.setStatus("COMPLETED");
        assignment.setEndTime(LocalDateTime.now());
        if (actualMinutes != null) assignment.setActualMinutes(actualMinutes);

        // Free up the bay
        if (assignment.getBay() != null) {
            assignment.getBay().setStatus("AVAILABLE");
            bayRepository.save(assignment.getBay());
        }
        return ResponseEntity.ok(ApiResponse.success("Assignment completed",
                assignmentRepository.save(assignment)));
    }
}
