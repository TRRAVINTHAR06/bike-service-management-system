package com.bikeservice.controller;

import com.bikeservice.dto.ApiResponse;
import com.bikeservice.dto.request.VehicleRequest;
import com.bikeservice.model.Vehicle;
import com.bikeservice.service.VehicleService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/vehicles")
@RequiredArgsConstructor
public class VehicleController {

    private final VehicleService vehicleService;

    @PostMapping
    public ResponseEntity<ApiResponse<Vehicle>> createVehicle(@Valid @RequestBody VehicleRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Vehicle registered", vehicleService.createVehicle(request)));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<Vehicle>> getVehicleById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(vehicleService.getVehicleById(id)));
    }

    @GetMapping("/customer/{customerId}")
    public ResponseEntity<ApiResponse<List<Vehicle>>> getVehiclesByCustomer(@PathVariable Long customerId) {
        return ResponseEntity.ok(ApiResponse.success(vehicleService.getVehiclesByCustomer(customerId)));
    }

    @GetMapping("/chassis/{chassisNo}")
    public ResponseEntity<ApiResponse<Vehicle>> getByChassisNo(@PathVariable String chassisNo) {
        return ResponseEntity.ok(ApiResponse.success(vehicleService.getVehicleByChassisNo(chassisNo)));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<Vehicle>> updateVehicle(@PathVariable Long id,
                                                               @Valid @RequestBody VehicleRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Vehicle updated", vehicleService.updateVehicle(id, request)));
    }
}
