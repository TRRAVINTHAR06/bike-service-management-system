package com.bikeservice.dto.request;

import jakarta.validation.constraints.NotNull;
import lombok.*;
import java.time.LocalDateTime;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class AppointmentRequest {
    @NotNull private Long branchId;
    @NotNull private Long customerId;
    @NotNull private Long vehicleId;
    @NotNull private LocalDateTime slotTime;
    private String serviceType;
    private String remarks;
    private boolean pickupRequired;
    private String pickupAddress;
}
