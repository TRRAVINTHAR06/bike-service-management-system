package com.bikeservice.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class BranchRequest {
    @NotBlank(message = "Branch name is required")
    private String name;
    @NotBlank(message = "Address is required")
    private String address;
    private String city;
    private String state;
    private String pincode;
    private String phone;
    private String email;
}
