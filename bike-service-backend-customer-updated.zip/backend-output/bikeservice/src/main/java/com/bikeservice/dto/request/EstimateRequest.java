package com.bikeservice.dto.request;

import lombok.*;
import java.math.BigDecimal;
import java.util.List;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class EstimateRequest {
    private Long jobCardId;
    private List<Long> serviceIds;
    private List<PartLineItem> parts;
    private BigDecimal discount;
    private BigDecimal taxPercent;

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor
    public static class PartLineItem {
        private Long partId;
        private Integer qty;
        private BigDecimal unitPrice;
    }
}
