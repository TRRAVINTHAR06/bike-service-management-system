package com.bikeservice.dto.request;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class FeedbackRequest {
    @NotNull private Long jobCardId;
    @NotNull @Min(1) @Max(5) private Integer rating;
    private String comments;
    private String serviceQuality;
    private String staffBehavior;
    private String overallExperience;
}
