package com.bikeservice.dto.request;

import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class InventoryRequest {
    private Long branchId;
    private Long partId;
    private Integer qtyAvailable;
    private Integer reorderLevel;
    private Integer maxStock;
    private String rackLocation;
}
