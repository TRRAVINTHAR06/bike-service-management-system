package com.bikeservice.dto.request;

import com.bikeservice.enums.ServiceType;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import java.util.List;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class JobCardRequest {
    @NotNull(message = "Branch ID is required")
    private Long branchId;
    @NotNull(message = "Customer ID is required")
    private Long customerId;
    @NotNull(message = "Vehicle ID is required")
    private Long vehicleId;
    private Long advisorId;
    private Long appointmentId;
    private ServiceType serviceType;
    private Integer odometerIn;
    private String customerInstructions;
    private boolean insuranceClaim;
    private String insuranceClaimNo;
    private List<String> complaints;
}
