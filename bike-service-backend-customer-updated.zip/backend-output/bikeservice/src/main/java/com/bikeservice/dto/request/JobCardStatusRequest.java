package com.bikeservice.dto.request;

import com.bikeservice.enums.JobCardStatus;
import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class JobCardStatusRequest {
    private JobCardStatus status;
    private String remarks;
    private Integer odometerOut;
}
