package com.bikeservice.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ModificationRequestDto {
    @NotNull private Long jobCardId;
    @NotBlank private String requestDetails;
    private String additionalNotes;
}
