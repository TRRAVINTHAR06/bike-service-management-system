package com.bikeservice.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.*;
import java.math.BigDecimal;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class PartsMasterRequest {
    @NotBlank private String partName;
    private String oemPartNo;
    private String partCategory;
    private String applicableModels;
    private String unit;
    private BigDecimal costPrice;
    private BigDecimal sellingPrice;
    private Integer warrantyMonths;
}
