package com.bikeservice.dto.request;

import com.bikeservice.enums.PaymentMode;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import java.math.BigDecimal;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class PaymentRequest {
    @NotNull
    private Long invoiceId;
    @NotNull
    private BigDecimal amount;
    @NotNull
    private PaymentMode mode;
    private String transactionRef;
    private String bankName;
    private String remarks;
}
