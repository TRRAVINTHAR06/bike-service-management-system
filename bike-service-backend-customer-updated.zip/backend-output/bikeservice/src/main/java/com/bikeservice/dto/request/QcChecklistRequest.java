package com.bikeservice.dto.request;

import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class QcChecklistRequest {
    private Long jobCardId;
    private Long inspectorId;
    private boolean engineCheck;
    private boolean brakeCheck;
    private boolean lightCheck;
    private boolean tiresCheck;
    private boolean cleanlinessCheck;
    private boolean roadTestDone;
    private String remarks;
}
