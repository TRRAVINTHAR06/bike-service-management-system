package com.bikeservice.dto.request;

import com.bikeservice.enums.ServiceType;
import jakarta.validation.constraints.NotBlank;
import lombok.*;
import java.math.BigDecimal;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ServiceCatalogRequest {
    @NotBlank private String serviceName;
    private ServiceType serviceType;
    private String description;
    private BigDecimal laborCharge;
    private Integer stdMinutes;
    private String applicableModels;
}
