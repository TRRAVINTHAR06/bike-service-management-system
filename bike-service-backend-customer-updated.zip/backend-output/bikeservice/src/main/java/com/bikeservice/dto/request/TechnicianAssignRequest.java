package com.bikeservice.dto.request;

import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class TechnicianAssignRequest {
    private Long jobCardId;
    private Long technicianId;
    private Long bayId;
    private Integer stdMinutes;
}
