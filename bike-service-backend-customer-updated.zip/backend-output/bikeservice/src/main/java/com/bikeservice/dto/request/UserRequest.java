package com.bikeservice.dto.request;

import com.bikeservice.enums.UserRole;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class UserRequest {
    private Long branchId;
    @NotBlank private String name;
    @NotBlank @Email private String email;
    @NotBlank private String password;
    private String phone;
    @NotNull private UserRole role;
}
