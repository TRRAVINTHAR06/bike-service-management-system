package com.bikeservice.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class VehicleRequest {
    private Long customerId;
    @NotBlank(message = "Chassis number is required")
    private String chassisNo;
    private String engineNo;
    private String regNo;
    @NotBlank(message = "Make is required")
    private String make;
    @NotBlank(message = "Model is required")
    private String model;
    private Integer year;
    private String color;
    private Integer odometer;
    private String fuelType;
}
