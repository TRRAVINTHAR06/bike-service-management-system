package com.bikeservice.enums;

public enum AppointmentStatus {
    BOOKED, CONFIRMED, ARRIVED, CANCELLED, NO_SHOW
}
