package com.bikeservice.enums;

public enum JobCardStatus {
    CREATED, INSPECTED, IN_PROGRESS, ON_HOLD, QC_PENDING, QC_PASSED, READY_FOR_DELIVERY, DELIVERED, CANCELLED
}
