package com.bikeservice.enums;

public enum PaymentMode {
    CASH, UPI, CARD, NET_BANKING, INSURANCE, CREDIT, ADVANCE
}
