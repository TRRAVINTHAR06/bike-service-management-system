package com.bikeservice.enums;

public enum ServiceType {
    FREE_SERVICE, PAID_SERVICE, RUNNING_REPAIR, ACCIDENTAL_REPAIR, AMC, EXPRESS_SERVICE, BREAKDOWN
}
