package com.bikeservice.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "bays")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Bay extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "branch_id", nullable = false)
    private Branch branch;

    @Column(nullable = false)
    private String bayNo;

    private String bayType;
    private String status = "AVAILABLE";
    private boolean active = true;
}
