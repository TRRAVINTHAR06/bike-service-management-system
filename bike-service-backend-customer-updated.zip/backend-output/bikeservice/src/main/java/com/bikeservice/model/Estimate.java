package com.bikeservice.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "estimates")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Estimate extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonIgnore
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "job_card_id", nullable = false)
    private JobCard jobCard;

    @Column(precision = 10, scale = 2)
    private BigDecimal partsTotal = BigDecimal.ZERO;

    @Column(precision = 10, scale = 2)
    private BigDecimal laborTotal = BigDecimal.ZERO;

    @Column(precision = 10, scale = 2)
    private BigDecimal discount = BigDecimal.ZERO;

    @Column(precision = 10, scale = 2)
    private BigDecimal taxAmount = BigDecimal.ZERO;

    @Column(precision = 10, scale = 2)
    private BigDecimal grandTotal = BigDecimal.ZERO;

    private String approvalStatus = "PENDING";

    private LocalDateTime sentAt;
    private LocalDateTime approvedAt;
    private String approvalRemarks;
    private String approvedBy;
}
