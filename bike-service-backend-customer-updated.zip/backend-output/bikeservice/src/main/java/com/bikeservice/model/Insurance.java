package com.bikeservice.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "insurance")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Insurance extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonIgnore
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vehicle_id", nullable = false)
    private Vehicle vehicle;

    private String policyNo;
    private String provider;
    private LocalDate startDate;
    private LocalDate expiryDate;
    private String claimNo;
    private boolean cashless = false;
    private String surveyorName;
    private String surveyorPhone;
}
