package com.bikeservice.model;

import com.bikeservice.enums.JobCardStatus;
import com.bikeservice.enums.ServiceType;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "job_cards")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class JobCard extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String jobCardNo;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "branch_id", nullable = false)
    private Branch branch;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vehicle_id", nullable = false)
    private Vehicle vehicle;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "advisor_id")
    private User advisor;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "appointment_id")
    private Appointment appointment;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private JobCardStatus status = JobCardStatus.CREATED;

    @Enumerated(EnumType.STRING)
    private ServiceType serviceType;

    private Integer odometerIn;
    private Integer odometerOut;

    private LocalDateTime checkInTime;
    private LocalDateTime checkOutTime;
    private LocalDateTime deliveryTime;

    private String customerInstructions;
    private String internalRemarks;
    private boolean insuranceClaim = false;
    private String insuranceClaimNo;

    @JsonIgnore
    @OneToMany(mappedBy = "jobCard", cascade = CascadeType.ALL)
    private List<JobCardComplaint> complaints;

    @JsonIgnore
    @OneToMany(mappedBy = "jobCard", cascade = CascadeType.ALL)
    private List<TechnicianAssignment> technicianAssignments;

    @JsonIgnore
    @OneToMany(mappedBy = "jobCard", cascade = CascadeType.ALL)
    private List<JobCardService> services;

    @JsonIgnore
    @OneToMany(mappedBy = "jobCard", cascade = CascadeType.ALL)
    private List<JobCardPart> parts;

    @JsonIgnore
    @OneToOne(mappedBy = "jobCard", cascade = CascadeType.ALL)
    private Estimate estimate;

    @JsonIgnore
    @OneToOne(mappedBy = "jobCard", cascade = CascadeType.ALL)
    private Invoice invoice;

    @JsonIgnore
    @OneToOne(mappedBy = "jobCard", cascade = CascadeType.ALL)
    private QcChecklist qcChecklist;
}
