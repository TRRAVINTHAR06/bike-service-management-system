package com.bikeservice.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "modification_requests")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ModificationRequest extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_user_id", nullable = false)
    private CustomerUser customerUser;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "job_card_id", nullable = false)
    private JobCard jobCard;

    @Column(nullable = false, length = 500)
    private String requestDetails;

    @Column(length = 500)
    private String additionalNotes;

    private String status = "PENDING"; // PENDING, APPROVED, REJECTED
    private String adminRemarks;
}
