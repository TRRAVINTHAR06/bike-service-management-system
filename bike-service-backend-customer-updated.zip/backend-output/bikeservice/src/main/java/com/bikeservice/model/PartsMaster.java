package com.bikeservice.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.util.List;

@Entity
@Table(name = "parts_master")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class PartsMaster extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String partName;

    @Column(unique = true)
    private String oemPartNo;

    private String partCategory;
    private String applicableModels;
    private String unit;

    @Column(precision = 10, scale = 2)
    private BigDecimal costPrice;

    @Column(precision = 10, scale = 2)
    private BigDecimal sellingPrice;

    private Integer warrantyMonths;
    private boolean active = true;

    @JsonIgnore
    @OneToMany(mappedBy = "part", cascade = CascadeType.ALL)
    private List<Inventory> inventories;
}
