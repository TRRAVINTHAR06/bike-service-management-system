package com.bikeservice.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "qc_checklists")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class QcChecklist extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonIgnore
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "job_card_id", nullable = false)
    private JobCard jobCard;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "inspector_id")
    private User inspector;

    private boolean engineCheck = false;
    private boolean brakeCheck = false;
    private boolean lightCheck = false;
    private boolean tiresCheck = false;
    private boolean cleanlinessCheck = false;
    private boolean roadTestDone = false;
    private boolean passed = false;
    private String remarks;
    private LocalDateTime checkedAt;
}
