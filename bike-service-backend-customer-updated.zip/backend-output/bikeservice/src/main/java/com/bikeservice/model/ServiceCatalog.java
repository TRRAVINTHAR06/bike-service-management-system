package com.bikeservice.model;

import com.bikeservice.enums.ServiceType;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;

@Entity
@Table(name = "service_catalog")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ServiceCatalog extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String serviceName;

    @Enumerated(EnumType.STRING)
    private ServiceType serviceType;

    private String description;

    @Column(precision = 10, scale = 2)
    private BigDecimal laborCharge;

    private Integer stdMinutes;
    private String applicableModels;
    private boolean active = true;
}
