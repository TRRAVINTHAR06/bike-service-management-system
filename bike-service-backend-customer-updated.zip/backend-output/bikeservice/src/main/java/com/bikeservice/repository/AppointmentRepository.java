package com.bikeservice.repository;

import com.bikeservice.enums.AppointmentStatus;
import com.bikeservice.model.Appointment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
    List<Appointment> findByBranchId(Long branchId);
    List<Appointment> findByCustomerId(Long customerId);
    List<Appointment> findByBranchIdAndStatus(Long branchId, AppointmentStatus status);
    List<Appointment> findByBranchIdAndSlotTimeBetween(Long branchId, LocalDateTime from, LocalDateTime to);
}
