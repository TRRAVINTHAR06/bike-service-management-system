package com.bikeservice.repository;

import com.bikeservice.model.Bay;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface BayRepository extends JpaRepository<Bay, Long> {
    List<Bay> findByBranchId(Long branchId);
    List<Bay> findByBranchIdAndStatus(Long branchId, String status);
    List<Bay> findByBranchIdAndActiveTrue(Long branchId);
}
