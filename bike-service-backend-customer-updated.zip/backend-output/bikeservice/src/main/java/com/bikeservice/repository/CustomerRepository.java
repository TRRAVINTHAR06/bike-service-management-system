package com.bikeservice.repository;

import com.bikeservice.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {
    Optional<Customer> findByPhone(String phone);
    boolean existsByPhone(String phone);
    List<Customer> findByBranchId(Long branchId);

    @Query("SELECT c FROM Customer c WHERE c.name LIKE %:query% OR c.phone LIKE %:query% OR c.email LIKE %:query%")
    List<Customer> searchCustomers(String query);
}
