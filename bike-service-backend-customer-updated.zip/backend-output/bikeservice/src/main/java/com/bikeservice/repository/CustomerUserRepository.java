package com.bikeservice.repository;

import com.bikeservice.model.CustomerUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface CustomerUserRepository extends JpaRepository<CustomerUser, Long> {
    Optional<CustomerUser> findByEmail(String email);
    boolean existsByEmail(String email);
    Optional<CustomerUser> findByCustomerId(Long customerId);
}
