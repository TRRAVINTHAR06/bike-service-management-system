package com.bikeservice.repository;

import com.bikeservice.model.Feedback;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface FeedbackRepository extends JpaRepository<Feedback, Long> {
    List<Feedback> findByCustomerUserId(Long customerUserId);
    Optional<Feedback> findByJobCardId(Long jobCardId);
    boolean existsByJobCardId(Long jobCardId);
}
