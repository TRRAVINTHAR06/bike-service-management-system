package com.bikeservice.repository;

import com.bikeservice.model.Insurance;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface InsuranceRepository extends JpaRepository<Insurance, Long> {
    Optional<Insurance> findByVehicleId(Long vehicleId);

    @Query("SELECT i FROM Insurance i WHERE i.expiryDate <= :date")
    List<Insurance> findExpiringSoon(LocalDate date);
}
