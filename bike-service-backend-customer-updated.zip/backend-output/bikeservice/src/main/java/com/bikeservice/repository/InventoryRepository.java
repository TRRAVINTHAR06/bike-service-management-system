package com.bikeservice.repository;

import com.bikeservice.model.Inventory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface InventoryRepository extends JpaRepository<Inventory, Long> {
    Optional<Inventory> findByBranchIdAndPartId(Long branchId, Long partId);
    List<Inventory> findByBranchId(Long branchId);

    @Query("SELECT i FROM Inventory i WHERE i.branch.id = :branchId AND i.qtyAvailable <= i.reorderLevel")
    List<Inventory> findLowStockByBranch(Long branchId);
}
