package com.bikeservice.repository;

import com.bikeservice.model.Invoice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface InvoiceRepository extends JpaRepository<Invoice, Long> {
    Optional<Invoice> findByJobCardId(Long jobCardId);
    Optional<Invoice> findByInvoiceNo(String invoiceNo);
    List<Invoice> findByCustomerId(Long customerId);

    @Query("SELECT i FROM Invoice i WHERE i.jobCard.branch.id = :branchId AND i.invoiceDate BETWEEN :from AND :to")
    List<Invoice> findByBranchAndDateRange(Long branchId, LocalDateTime from, LocalDateTime to);

    @Query("SELECT SUM(i.totalAmount) FROM Invoice i WHERE i.jobCard.branch.id = :branchId AND i.invoiceDate BETWEEN :from AND :to")
    java.math.BigDecimal sumRevenueByBranchAndDateRange(Long branchId, LocalDateTime from, LocalDateTime to);
}
