package com.bikeservice.repository;

import com.bikeservice.model.JobCardComplaint;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface JobCardComplaintRepository extends JpaRepository<JobCardComplaint, Long> {
    List<JobCardComplaint> findByJobCardId(Long jobCardId);
}
