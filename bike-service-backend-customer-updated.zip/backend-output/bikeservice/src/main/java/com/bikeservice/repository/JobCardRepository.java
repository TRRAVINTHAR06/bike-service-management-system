package com.bikeservice.repository;

import com.bikeservice.enums.JobCardStatus;
import com.bikeservice.model.JobCard;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface JobCardRepository extends JpaRepository<JobCard, Long> {
    Optional<JobCard> findByJobCardNo(String jobCardNo);
    List<JobCard> findByBranchId(Long branchId);
    List<JobCard> findByCustomerId(Long customerId);
    List<JobCard> findByVehicleId(Long vehicleId);
    List<JobCard> findByStatus(JobCardStatus status);
    List<JobCard> findByBranchIdAndStatus(Long branchId, JobCardStatus status);
    List<JobCard> findByAdvisorId(Long advisorId);

    @Query("SELECT j FROM JobCard j WHERE j.branch.id = :branchId AND j.createdAt BETWEEN :from AND :to")
    List<JobCard> findByBranchAndDateRange(Long branchId, LocalDateTime from, LocalDateTime to);

    @Query("SELECT COUNT(j) FROM JobCard j WHERE j.branch.id = :branchId AND j.status = :status")
    Long countByBranchAndStatus(Long branchId, JobCardStatus status);
}
