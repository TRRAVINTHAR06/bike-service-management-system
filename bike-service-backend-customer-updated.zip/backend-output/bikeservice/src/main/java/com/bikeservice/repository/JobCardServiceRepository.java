package com.bikeservice.repository;

import com.bikeservice.model.JobCardService;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface JobCardServiceRepository extends JpaRepository<JobCardService, Long> {
    List<JobCardService> findByJobCardId(Long jobCardId);

    @Modifying
    void deleteByJobCardId(Long jobCardId);
}
