package com.bikeservice.repository;

import com.bikeservice.model.ModificationRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ModificationRequestRepository extends JpaRepository<ModificationRequest, Long> {
    List<ModificationRequest> findByCustomerUserId(Long customerUserId);
    List<ModificationRequest> findByJobCardId(Long jobCardId);
}
