package com.bikeservice.repository;

import com.bikeservice.model.Notification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface NotificationRepository extends JpaRepository<Notification, Long> {
    List<Notification> findByCustomerId(Long customerId);
    List<Notification> findByJobCardId(Long jobCardId);
    List<Notification> findByDeliveredFalse();
}
