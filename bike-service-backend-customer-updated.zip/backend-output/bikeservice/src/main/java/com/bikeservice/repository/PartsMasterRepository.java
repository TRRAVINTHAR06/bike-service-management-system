package com.bikeservice.repository;

import com.bikeservice.model.PartsMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface PartsMasterRepository extends JpaRepository<PartsMaster, Long> {
    Optional<PartsMaster> findByOemPartNo(String oemPartNo);
    List<PartsMaster> findByActiveTrue();
    @Query("SELECT p FROM PartsMaster p WHERE p.partName LIKE %:query% OR p.oemPartNo LIKE %:query%")
    List<PartsMaster> searchParts(String query);
}
