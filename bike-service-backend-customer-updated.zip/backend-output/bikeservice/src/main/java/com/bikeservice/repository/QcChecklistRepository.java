package com.bikeservice.repository;

import com.bikeservice.model.QcChecklist;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface QcChecklistRepository extends JpaRepository<QcChecklist, Long> {
    Optional<QcChecklist> findByJobCardId(Long jobCardId);
}
