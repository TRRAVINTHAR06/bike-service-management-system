package com.bikeservice.repository;

import com.bikeservice.enums.ServiceType;
import com.bikeservice.model.ServiceCatalog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ServiceCatalogRepository extends JpaRepository<ServiceCatalog, Long> {
    List<ServiceCatalog> findByActiveTrue();
    List<ServiceCatalog> findByServiceTypeAndActiveTrue(ServiceType serviceType);
}
