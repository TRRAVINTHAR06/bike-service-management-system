package com.bikeservice.repository;

import com.bikeservice.model.TechnicianAssignment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface TechnicianAssignmentRepository extends JpaRepository<TechnicianAssignment, Long> {
    List<TechnicianAssignment> findByJobCardId(Long jobCardId);
    List<TechnicianAssignment> findByTechnicianId(Long technicianId);
    List<TechnicianAssignment> findByBayId(Long bayId);
}
