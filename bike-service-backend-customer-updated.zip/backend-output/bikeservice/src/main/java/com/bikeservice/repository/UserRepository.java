package com.bikeservice.repository;

import com.bikeservice.enums.UserRole;
import com.bikeservice.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
    boolean existsByEmail(String email);
    List<User> findByBranchIdAndActiveTrue(Long branchId);
    List<User> findByBranchIdAndRoleAndActiveTrue(Long branchId, UserRole role);
}
