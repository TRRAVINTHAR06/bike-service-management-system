package com.bikeservice.repository;

import com.bikeservice.model.Vehicle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface VehicleRepository extends JpaRepository<Vehicle, Long> {
    List<Vehicle> findByCustomerId(Long customerId);
    Optional<Vehicle> findByChassisNo(String chassisNo);
    Optional<Vehicle> findByRegNo(String regNo);
    boolean existsByChassisNo(String chassisNo);
}
