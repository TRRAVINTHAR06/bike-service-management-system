package com.bikeservice.service;

import com.bikeservice.dto.request.AppointmentRequest;
import com.bikeservice.enums.AppointmentStatus;
import com.bikeservice.model.Appointment;
import java.util.List;

public interface AppointmentService {
    Appointment createAppointment(AppointmentRequest request);
    Appointment updateStatus(Long id, AppointmentStatus status);
    Appointment getAppointmentById(Long id);
    List<Appointment> getAppointmentsByBranch(Long branchId);
    List<Appointment> getAppointmentsByCustomer(Long customerId);
}
