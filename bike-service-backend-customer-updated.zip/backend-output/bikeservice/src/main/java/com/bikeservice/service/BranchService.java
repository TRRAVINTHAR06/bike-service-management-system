package com.bikeservice.service;

import com.bikeservice.dto.request.BranchRequest;
import com.bikeservice.model.Branch;
import java.util.List;

public interface BranchService {
    Branch createBranch(BranchRequest request);
    Branch updateBranch(Long id, BranchRequest request);
    Branch getBranchById(Long id);
    List<Branch> getAllBranches();
    List<Branch> getActiveBranches();
    void deleteBranch(Long id);
}
