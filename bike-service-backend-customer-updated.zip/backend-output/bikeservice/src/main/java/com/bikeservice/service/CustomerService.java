package com.bikeservice.service;

import com.bikeservice.dto.request.CustomerRequest;
import com.bikeservice.model.Customer;
import java.util.List;

public interface CustomerService {
    Customer createCustomer(CustomerRequest request);
    Customer updateCustomer(Long id, CustomerRequest request);
    Customer getCustomerById(Long id);
    Customer getCustomerByPhone(String phone);
    List<Customer> getAllCustomers();
    List<Customer> getCustomersByBranch(Long branchId);
    List<Customer> searchCustomers(String query);
    void addLoyaltyPoints(Long customerId, int points);
}
