package com.bikeservice.service;

import com.bikeservice.dto.request.EstimateRequest;
import com.bikeservice.model.Estimate;

public interface EstimateService {
    Estimate createEstimate(EstimateRequest request);
    Estimate getEstimateByJobCard(Long jobCardId);
    Estimate approveEstimate(Long jobCardId, String approvedBy);
    Estimate rejectEstimate(Long jobCardId, String remarks);
}
