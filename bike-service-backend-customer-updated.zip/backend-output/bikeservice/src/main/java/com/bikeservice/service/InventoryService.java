package com.bikeservice.service;

import com.bikeservice.dto.request.InventoryRequest;
import com.bikeservice.model.Inventory;
import java.util.List;

public interface InventoryService {
    Inventory addOrUpdateStock(InventoryRequest request);
    Inventory getStock(Long branchId, Long partId);
    List<Inventory> getStockByBranch(Long branchId);
    List<Inventory> getLowStockAlerts(Long branchId);
    void deductStock(Long branchId, Long partId, int qty);
    void addStock(Long branchId, Long partId, int qty);
}
