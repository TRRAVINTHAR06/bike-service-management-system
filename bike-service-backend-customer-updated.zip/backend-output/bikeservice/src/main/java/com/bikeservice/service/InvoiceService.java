package com.bikeservice.service;

import com.bikeservice.dto.request.PaymentRequest;
import com.bikeservice.model.Invoice;
import com.bikeservice.model.Payment;
import java.util.List;

public interface InvoiceService {
    Invoice generateInvoice(Long jobCardId);
    Invoice getInvoiceByJobCard(Long jobCardId);
    Invoice getInvoiceById(Long id);
    List<Invoice> getInvoicesByCustomer(Long customerId);
    Payment recordPayment(PaymentRequest request);
    List<Payment> getPaymentsByInvoice(Long invoiceId);
}
