package com.bikeservice.service;

import com.bikeservice.dto.request.JobCardRequest;
import com.bikeservice.dto.request.JobCardStatusRequest;
import com.bikeservice.enums.JobCardStatus;
import com.bikeservice.model.JobCard;
import java.util.List;

public interface JobCardService {
    JobCard createJobCard(JobCardRequest request);
    JobCard updateStatus(Long id, JobCardStatusRequest request);
    JobCard getJobCardById(Long id);
    JobCard getJobCardByNo(String jobCardNo);
    List<JobCard> getJobCardsByBranch(Long branchId);
    List<JobCard> getJobCardsByCustomer(Long customerId);
    List<JobCard> getJobCardsByVehicle(Long vehicleId);
    List<JobCard> getJobCardsByStatus(JobCardStatus status);
    List<JobCard> getJobCardsByBranchAndStatus(Long branchId, JobCardStatus status);
    void deliverJobCard(Long id, Integer odometerOut);
}
