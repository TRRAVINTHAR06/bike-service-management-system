package com.bikeservice.service;

import com.bikeservice.dto.request.PartsMasterRequest;
import com.bikeservice.model.PartsMaster;
import java.util.List;

public interface PartsMasterService {
    PartsMaster createPart(PartsMasterRequest request);
    PartsMaster updatePart(Long id, PartsMasterRequest request);
    PartsMaster getPartById(Long id);
    List<PartsMaster> getAllActiveParts();
    List<PartsMaster> searchParts(String query);
    void deactivatePart(Long id);
}
