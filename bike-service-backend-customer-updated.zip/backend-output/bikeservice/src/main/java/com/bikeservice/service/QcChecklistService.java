package com.bikeservice.service;

import com.bikeservice.dto.request.QcChecklistRequest;
import com.bikeservice.model.QcChecklist;

public interface QcChecklistService {
    QcChecklist submitQc(QcChecklistRequest request);
    QcChecklist getQcByJobCard(Long jobCardId);
}
