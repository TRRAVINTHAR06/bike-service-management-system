package com.bikeservice.service;

import com.bikeservice.dto.request.ServiceCatalogRequest;
import com.bikeservice.enums.ServiceType;
import com.bikeservice.model.ServiceCatalog;
import java.util.List;

public interface ServiceCatalogService {
    ServiceCatalog createService(ServiceCatalogRequest request);
    ServiceCatalog updateService(Long id, ServiceCatalogRequest request);
    ServiceCatalog getServiceById(Long id);
    List<ServiceCatalog> getAllActiveServices();
    List<ServiceCatalog> getServicesByType(ServiceType type);
    void deactivateService(Long id);
}
