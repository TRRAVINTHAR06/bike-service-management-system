package com.bikeservice.service;

import com.bikeservice.dto.request.VehicleRequest;
import com.bikeservice.model.Vehicle;
import java.util.List;

public interface VehicleService {
    Vehicle createVehicle(VehicleRequest request);
    Vehicle updateVehicle(Long id, VehicleRequest request);
    Vehicle getVehicleById(Long id);
    List<Vehicle> getVehiclesByCustomer(Long customerId);
    Vehicle getVehicleByChassisNo(String chassisNo);
}
