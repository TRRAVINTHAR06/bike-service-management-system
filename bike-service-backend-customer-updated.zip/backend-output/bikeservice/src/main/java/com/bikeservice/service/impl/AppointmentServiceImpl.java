package com.bikeservice.service.impl;

import com.bikeservice.dto.request.AppointmentRequest;
import com.bikeservice.enums.AppointmentStatus;
import com.bikeservice.exception.ResourceNotFoundException;
import com.bikeservice.model.*;
import com.bikeservice.repository.AppointmentRepository;
import com.bikeservice.service.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class AppointmentServiceImpl implements AppointmentService {

    private final AppointmentRepository appointmentRepository;
    private final BranchService branchService;
    private final CustomerService customerService;
    private final VehicleService vehicleService;

    @Override
    public Appointment createAppointment(AppointmentRequest request) {
        Branch branch = branchService.getBranchById(request.getBranchId());
        Customer customer = customerService.getCustomerById(request.getCustomerId());
        Vehicle vehicle = vehicleService.getVehicleById(request.getVehicleId());

        Appointment appointment = Appointment.builder()
                .branch(branch)
                .customer(customer)
                .vehicle(vehicle)
                .slotTime(request.getSlotTime())
                .serviceType(request.getServiceType())
                .remarks(request.getRemarks())
                .pickupRequired(request.isPickupRequired())
                .pickupAddress(request.getPickupAddress())
                .status(AppointmentStatus.BOOKED)
                .build();

        return appointmentRepository.save(appointment);
    }

    @Override
    public Appointment updateStatus(Long id, AppointmentStatus status) {
        Appointment appointment = getAppointmentById(id);
        appointment.setStatus(status);
        return appointmentRepository.save(appointment);
    }

    @Override
    @Transactional(readOnly = true)
    public Appointment getAppointmentById(Long id) {
        return appointmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Appointment not found: " + id));
    }

    @Override
    @Transactional(readOnly = true)
    public List<Appointment> getAppointmentsByBranch(Long branchId) {
        return appointmentRepository.findByBranchId(branchId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Appointment> getAppointmentsByCustomer(Long customerId) {
        return appointmentRepository.findByCustomerId(customerId);
    }
}
