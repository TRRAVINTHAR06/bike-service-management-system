package com.bikeservice.service.impl;

import com.bikeservice.dto.request.BranchRequest;
import com.bikeservice.exception.ResourceNotFoundException;
import com.bikeservice.model.Branch;
import com.bikeservice.repository.BranchRepository;
import com.bikeservice.service.BranchService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class BranchServiceImpl implements BranchService {

    private final BranchRepository branchRepository;

    @Override
    public Branch createBranch(BranchRequest request) {
        Branch branch = Branch.builder()
                .name(request.getName())
                .address(request.getAddress())
                .city(request.getCity())
                .state(request.getState())
                .pincode(request.getPincode())
                .phone(request.getPhone())
                .email(request.getEmail())
                .active(true)
                .build();
        return branchRepository.save(branch);
    }

    @Override
    public Branch updateBranch(Long id, BranchRequest request) {
        Branch branch = getBranchById(id);
        branch.setName(request.getName());
        branch.setAddress(request.getAddress());
        branch.setCity(request.getCity());
        branch.setState(request.getState());
        branch.setPincode(request.getPincode());
        branch.setPhone(request.getPhone());
        branch.setEmail(request.getEmail());
        return branchRepository.save(branch);
    }

    @Override
    @Transactional(readOnly = true)
    public Branch getBranchById(Long id) {
        return branchRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Branch not found with id: " + id));
    }

    @Override
    @Transactional(readOnly = true)
    public List<Branch> getAllBranches() {
        return branchRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public List<Branch> getActiveBranches() {
        return branchRepository.findByActiveTrue();
    }

    @Override
    public void deleteBranch(Long id) {
        Branch branch = getBranchById(id);
        branch.setActive(false);
        branchRepository.save(branch);
    }
}
