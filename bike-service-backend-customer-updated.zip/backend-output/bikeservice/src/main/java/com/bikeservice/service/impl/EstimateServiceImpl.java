package com.bikeservice.service.impl;

import com.bikeservice.dto.request.EstimateRequest;
import com.bikeservice.exception.BusinessException;
import com.bikeservice.exception.ResourceNotFoundException;
import com.bikeservice.model.Estimate;
import com.bikeservice.model.JobCard;
import com.bikeservice.model.JobCardPart;
import com.bikeservice.model.PartsMaster;
import com.bikeservice.model.ServiceCatalog;
import com.bikeservice.repository.EstimateRepository;
import com.bikeservice.repository.JobCardPartRepository;
import com.bikeservice.repository.JobCardServiceRepository;
import com.bikeservice.repository.PartsMasterRepository;
import com.bikeservice.repository.ServiceCatalogRepository;
import com.bikeservice.service.EstimateService;
import com.bikeservice.service.InventoryService;
import com.bikeservice.service.JobCardService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class EstimateServiceImpl implements EstimateService {

    private final EstimateRepository estimateRepository;
    private final JobCardService jobCardService;
    private final ServiceCatalogRepository serviceCatalogRepository;
    private final PartsMasterRepository partsMasterRepository;
    private final JobCardPartRepository jobCardPartRepository;
    private final JobCardServiceRepository jobCardServiceRepository;
    private final InventoryService inventoryService;

    @Override
    public Estimate createEstimate(EstimateRequest request) {
        // BUG FIX 1: Prevent duplicate estimates for the same job card
        if (estimateRepository.findByJobCardId(request.getJobCardId()).isPresent()) {
            throw new BusinessException(
                "Estimate already exists for job card: " + request.getJobCardId()
                + ". Use update instead.");
        }

        JobCard jobCard = jobCardService.getJobCardById(request.getJobCardId());

        BigDecimal laborTotal = BigDecimal.ZERO;
        BigDecimal partsTotal = BigDecimal.ZERO;

        // Add services — use fully qualified model class to avoid conflict with service interface
        if (request.getServiceIds() != null) {
            for (Long serviceId : request.getServiceIds()) {
                ServiceCatalog catalog = serviceCatalogRepository.findById(serviceId)
                        .orElseThrow(() -> new ResourceNotFoundException("Service not found: " + serviceId));
                com.bikeservice.model.JobCardService jcs = com.bikeservice.model.JobCardService.builder()
                        .jobCard(jobCard)
                        .service(catalog)
                        .laborCharge(catalog.getLaborCharge())
                        .status("PENDING")
                        .build();
                jobCardServiceRepository.save(jcs);
                laborTotal = laborTotal.add(catalog.getLaborCharge() != null ? catalog.getLaborCharge() : BigDecimal.ZERO);
            }
        }

        // Add parts — BUG FIX 2: Do NOT deduct inventory here.
        // Stock is only deducted after estimate is approved to avoid permanent
        // stock loss when estimates are rejected.
        if (request.getParts() != null) {
            for (EstimateRequest.PartLineItem item : request.getParts()) {
                PartsMaster part = partsMasterRepository.findById(item.getPartId())
                        .orElseThrow(() -> new ResourceNotFoundException("Part not found: " + item.getPartId()));
                BigDecimal lineTotal = item.getUnitPrice().multiply(BigDecimal.valueOf(item.getQty()));
                JobCardPart jcp = JobCardPart.builder()
                        .jobCard(jobCard)
                        .part(part)
                        .qtyUsed(item.getQty())
                        .unitPrice(item.getUnitPrice())
                        .totalPrice(lineTotal)
                        .build();
                jobCardPartRepository.save(jcp);
                partsTotal = partsTotal.add(lineTotal);
                // NOTE: inventoryService.deductStock() intentionally NOT called here
            }
        }

        BigDecimal discount = request.getDiscount() != null ? request.getDiscount() : BigDecimal.ZERO;
        BigDecimal taxPercent = request.getTaxPercent() != null ? request.getTaxPercent() : new BigDecimal("18");
        BigDecimal subtotal = partsTotal.add(laborTotal).subtract(discount);
        BigDecimal taxAmount = subtotal.multiply(taxPercent).divide(new BigDecimal("100"), 2, RoundingMode.HALF_UP);
        BigDecimal grandTotal = subtotal.add(taxAmount);

        Estimate estimate = Estimate.builder()
                .jobCard(jobCard)
                .partsTotal(partsTotal)
                .laborTotal(laborTotal)
                .discount(discount)
                .taxAmount(taxAmount)
                .grandTotal(grandTotal)
                .approvalStatus("PENDING")
                .sentAt(LocalDateTime.now())
                .build();

        return estimateRepository.save(estimate);
    }

    @Override
    @Transactional(readOnly = true)
    public Estimate getEstimateByJobCard(Long jobCardId) {
        return estimateRepository.findByJobCardId(jobCardId)
                .orElseThrow(() -> new ResourceNotFoundException("Estimate not found for job card: " + jobCardId));
    }

    @Override
    public Estimate approveEstimate(Long jobCardId, String approvedBy) {
        Estimate estimate = getEstimateByJobCard(jobCardId);

        // BUG FIX 3: Guard against double-approval or approving a rejected estimate
        if ("APPROVED".equals(estimate.getApprovalStatus())) {
            throw new BusinessException("Estimate is already approved for job card: " + jobCardId);
        }
        if ("REJECTED".equals(estimate.getApprovalStatus())) {
            throw new BusinessException("Cannot approve a rejected estimate for job card: " + jobCardId);
        }

        estimate.setApprovalStatus("APPROVED");
        estimate.setApprovedBy(approvedBy);
        estimate.setApprovedAt(LocalDateTime.now());
        Estimate saved = estimateRepository.save(estimate);

        // BUG FIX 2 (continued): Deduct inventory ONLY after approval
        JobCard jobCard = estimate.getJobCard();
        List<JobCardPart> parts = jobCardPartRepository.findByJobCardId(jobCard.getId());
        for (JobCardPart jcp : parts) {
            inventoryService.deductStock(
                jobCard.getBranch().getId(),
                jcp.getPart().getId(),
                jcp.getQtyUsed()
            );
        }

        return saved;
    }

    @Override
    public Estimate rejectEstimate(Long jobCardId, String remarks) {
        Estimate estimate = getEstimateByJobCard(jobCardId);

        // BUG FIX 3: Guard against rejecting an already-approved or rejected estimate
        if ("APPROVED".equals(estimate.getApprovalStatus())) {
            throw new BusinessException("Cannot reject an already approved estimate for job card: " + jobCardId);
        }
        if ("REJECTED".equals(estimate.getApprovalStatus())) {
            throw new BusinessException("Estimate is already rejected for job card: " + jobCardId);
        }

        estimate.setApprovalStatus("REJECTED");
        estimate.setApprovalRemarks(remarks);
        return estimateRepository.save(estimate);
    }
}
