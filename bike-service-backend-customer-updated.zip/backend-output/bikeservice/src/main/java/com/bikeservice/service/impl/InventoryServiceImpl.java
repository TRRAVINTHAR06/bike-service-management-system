package com.bikeservice.service.impl;

import com.bikeservice.dto.request.InventoryRequest;
import com.bikeservice.exception.BusinessException;
import com.bikeservice.exception.ResourceNotFoundException;
import com.bikeservice.model.Branch;
import com.bikeservice.model.Inventory;
import com.bikeservice.model.PartsMaster;
import com.bikeservice.repository.InventoryRepository;
import com.bikeservice.repository.PartsMasterRepository;
import com.bikeservice.service.BranchService;
import com.bikeservice.service.InventoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class InventoryServiceImpl implements InventoryService {

    private final InventoryRepository inventoryRepository;
    private final PartsMasterRepository partsMasterRepository;
    private final BranchService branchService;

    @Override
    public Inventory addOrUpdateStock(InventoryRequest request) {
        Branch branch = branchService.getBranchById(request.getBranchId());
        PartsMaster part = partsMasterRepository.findById(request.getPartId())
                .orElseThrow(() -> new ResourceNotFoundException("Part not found: " + request.getPartId()));

        Inventory inventory = inventoryRepository
                .findByBranchIdAndPartId(request.getBranchId(), request.getPartId())
                .orElse(Inventory.builder().branch(branch).part(part).build());

        inventory.setQtyAvailable(request.getQtyAvailable());
        inventory.setReorderLevel(request.getReorderLevel() != null ? request.getReorderLevel() : 5);
        inventory.setMaxStock(request.getMaxStock() != null ? request.getMaxStock() : 100);
        inventory.setRackLocation(request.getRackLocation());
        return inventoryRepository.save(inventory);
    }

    @Override
    @Transactional(readOnly = true)
    public Inventory getStock(Long branchId, Long partId) {
        return inventoryRepository.findByBranchIdAndPartId(branchId, partId)
                .orElseThrow(() -> new ResourceNotFoundException("Stock entry not found for branch/part"));
    }

    @Override
    @Transactional(readOnly = true)
    public List<Inventory> getStockByBranch(Long branchId) {
        return inventoryRepository.findByBranchId(branchId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Inventory> getLowStockAlerts(Long branchId) {
        return inventoryRepository.findLowStockByBranch(branchId);
    }

    @Override
    public void deductStock(Long branchId, Long partId, int qty) {
        Inventory inventory = getStock(branchId, partId);
        if (inventory.getQtyAvailable() < qty) {
            throw new BusinessException("Insufficient stock for part id: " + partId
                    + ". Available: " + inventory.getQtyAvailable() + ", Required: " + qty);
        }
        inventory.setQtyAvailable(inventory.getQtyAvailable() - qty);
        inventoryRepository.save(inventory);
    }

    @Override
    public void addStock(Long branchId, Long partId, int qty) {
        Inventory inventory = getStock(branchId, partId);
        inventory.setQtyAvailable(inventory.getQtyAvailable() + qty);
        inventoryRepository.save(inventory);
    }
}
