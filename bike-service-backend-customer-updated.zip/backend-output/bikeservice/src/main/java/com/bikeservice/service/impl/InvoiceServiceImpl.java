package com.bikeservice.service.impl;

import com.bikeservice.dto.request.PaymentRequest;
import com.bikeservice.exception.BusinessException;
import com.bikeservice.exception.ResourceNotFoundException;
import com.bikeservice.model.*;
import com.bikeservice.repository.*;
import com.bikeservice.service.EstimateService;
import com.bikeservice.service.InvoiceService;
import com.bikeservice.service.JobCardService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class InvoiceServiceImpl implements InvoiceService {

    private final InvoiceRepository invoiceRepository;
    private final PaymentRepository paymentRepository;
    private final JobCardService jobCardService;
    private final EstimateService estimateService;
    private final CustomerRepository customerRepository;   // BUG FIX 7: avoid LazyInitializationException

    @Override
    public Invoice generateInvoice(Long jobCardId) {
        if (invoiceRepository.findByJobCardId(jobCardId).isPresent()) {
            throw new BusinessException("Invoice already generated for job card: " + jobCardId);
        }
        JobCard jobCard = jobCardService.getJobCardById(jobCardId);
        Estimate estimate = estimateService.getEstimateByJobCard(jobCardId);

        if (!"APPROVED".equals(estimate.getApprovalStatus())) {
            throw new BusinessException("Estimate must be approved before generating invoice");
        }

        // BUG FIX 7: Fetch customer explicitly to prevent LazyInitializationException
        // when jobCard.getCustomer() triggers lazy proxy outside Hibernate session.
        Customer customer = customerRepository.findById(jobCard.getCustomer().getId())
                .orElseThrow(() -> new ResourceNotFoundException(
                    "Customer not found for job card: " + jobCardId));

        String invoiceNo = "INV-" + jobCard.getBranch().getId() + "-"
                + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));

        Invoice invoice = Invoice.builder()
                .invoiceNo(invoiceNo)
                .jobCard(jobCard)
                .customer(customer)
                .partsTotal(estimate.getPartsTotal())
                .laborTotal(estimate.getLaborTotal())
                .discount(estimate.getDiscount())
                .taxAmount(estimate.getTaxAmount())
                .totalAmount(estimate.getGrandTotal())
                .paidAmount(BigDecimal.ZERO)
                .balanceAmount(estimate.getGrandTotal())
                .paymentStatus("PENDING")
                .invoiceDate(LocalDateTime.now())
                .build();

        return invoiceRepository.save(invoice);
    }

    @Override
    @Transactional(readOnly = true)
    public Invoice getInvoiceByJobCard(Long jobCardId) {
        return invoiceRepository.findByJobCardId(jobCardId)
                .orElseThrow(() -> new ResourceNotFoundException("Invoice not found for job card: " + jobCardId));
    }

    @Override
    @Transactional(readOnly = true)
    public Invoice getInvoiceById(Long id) {
        return invoiceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Invoice not found: " + id));
    }

    @Override
    @Transactional(readOnly = true)
    public List<Invoice> getInvoicesByCustomer(Long customerId) {
        return invoiceRepository.findByCustomerId(customerId);
    }

    @Override
    public Payment recordPayment(PaymentRequest request) {
        Invoice invoice = getInvoiceById(request.getInvoiceId());

        if ("PAID".equals(invoice.getPaymentStatus())) {
            throw new BusinessException("Invoice is already fully paid");
        }
        if (request.getAmount().compareTo(invoice.getBalanceAmount()) > 0) {
            throw new BusinessException("Payment amount exceeds balance: " + invoice.getBalanceAmount());
        }

        Payment payment = Payment.builder()
                .invoice(invoice)
                .amount(request.getAmount())
                .mode(request.getMode())
                .transactionRef(request.getTransactionRef())
                .bankName(request.getBankName())
                .remarks(request.getRemarks())
                .paidAt(LocalDateTime.now())
                .build();
        paymentRepository.save(payment);

        invoice.setPaidAmount(invoice.getPaidAmount().add(request.getAmount()));
        invoice.setBalanceAmount(invoice.getTotalAmount().subtract(invoice.getPaidAmount()));
        if (invoice.getBalanceAmount().compareTo(BigDecimal.ZERO) <= 0) {
            invoice.setPaymentStatus("PAID");
        } else {
            invoice.setPaymentStatus("PARTIAL");
        }
        invoiceRepository.save(invoice);

        return payment;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Payment> getPaymentsByInvoice(Long invoiceId) {
        return paymentRepository.findByInvoiceId(invoiceId);
    }
}
