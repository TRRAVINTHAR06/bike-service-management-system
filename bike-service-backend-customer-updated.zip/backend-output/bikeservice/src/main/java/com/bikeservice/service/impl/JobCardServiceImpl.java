package com.bikeservice.service.impl;

import com.bikeservice.dto.request.JobCardRequest;
import com.bikeservice.dto.request.JobCardStatusRequest;
import com.bikeservice.enums.JobCardStatus;
import com.bikeservice.exception.BusinessException;
import com.bikeservice.exception.ResourceNotFoundException;
import com.bikeservice.model.Appointment;
import com.bikeservice.model.Branch;
import com.bikeservice.model.Customer;
import com.bikeservice.model.JobCard;
import com.bikeservice.model.JobCardComplaint;
import com.bikeservice.model.User;
import com.bikeservice.model.Vehicle;
import com.bikeservice.repository.AppointmentRepository;
import com.bikeservice.repository.JobCardComplaintRepository;
import com.bikeservice.repository.JobCardRepository;
import com.bikeservice.repository.UserRepository;
import com.bikeservice.repository.VehicleRepository;
import com.bikeservice.service.BranchService;
import com.bikeservice.service.CustomerService;
import com.bikeservice.service.VehicleService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

// NOTE: This class implements com.bikeservice.service.JobCardService (the interface).
// The model class com.bikeservice.model.JobCardService is a different type (job_card_services table).
// We do NOT import com.bikeservice.service.JobCardService here to avoid ambiguity —
// the interface is referenced only via the implements clause using the simple name,
// which resolves correctly because we import no conflicting type from the service package.
@Service
@RequiredArgsConstructor
@Transactional
public class JobCardServiceImpl implements com.bikeservice.service.JobCardService {

    private final JobCardRepository jobCardRepository;
    private final BranchService branchService;
    private final CustomerService customerService;
    private final VehicleService vehicleService;
    private final VehicleRepository vehicleRepository;       // BUG FIX 4: persist odometer update
    private final UserRepository userRepository;
    private final AppointmentRepository appointmentRepository;
    private final JobCardComplaintRepository jobCardComplaintRepository;

    @Override
    public JobCard createJobCard(JobCardRequest request) {
        Branch branch = branchService.getBranchById(request.getBranchId());
        Customer customer = customerService.getCustomerById(request.getCustomerId());
        Vehicle vehicle = vehicleService.getVehicleById(request.getVehicleId());

        // BUG FIX 5: Validate that the vehicle belongs to the customer
        if (!vehicle.getCustomer().getId().equals(customer.getId())) {
            throw new BusinessException(
                "Vehicle " + vehicle.getId() + " does not belong to customer " + customer.getId());
        }

        User advisor = null;
        if (request.getAdvisorId() != null) {
            advisor = userRepository.findById(request.getAdvisorId())
                    .orElseThrow(() -> new ResourceNotFoundException("Advisor not found"));
        }

        Appointment appointment = null;
        if (request.getAppointmentId() != null) {
            appointment = appointmentRepository.findById(request.getAppointmentId())
                    .orElseThrow(() -> new ResourceNotFoundException("Appointment not found"));
        }

        String jobCardNo = generateJobCardNo(branch);

        JobCard jobCard = JobCard.builder()
                .jobCardNo(jobCardNo)
                .branch(branch)
                .customer(customer)
                .vehicle(vehicle)
                .advisor(advisor)
                .appointment(appointment)
                .status(JobCardStatus.CREATED)
                .serviceType(request.getServiceType())
                .odometerIn(request.getOdometerIn())
                .customerInstructions(request.getCustomerInstructions())
                .insuranceClaim(request.isInsuranceClaim())
                .insuranceClaimNo(request.getInsuranceClaimNo())
                .checkInTime(LocalDateTime.now())
                .build();

        JobCard saved = jobCardRepository.save(jobCard);

        // Save complaints
        if (request.getComplaints() != null) {
            request.getComplaints().forEach(c -> {
                JobCardComplaint complaint = JobCardComplaint.builder()
                        .jobCard(saved)
                        .complaintText(c)
                        .build();
                jobCardComplaintRepository.save(complaint);
            });
        }

        // BUG FIX 4: Persist updated odometer to DB — was silently discarded before
        if (request.getOdometerIn() != null) {
            vehicle.setOdometer(request.getOdometerIn());
            vehicleRepository.save(vehicle);
        }

        return saved;
    }

    @Override
    public JobCard updateStatus(Long id, JobCardStatusRequest request) {
        JobCard jobCard = getJobCardById(id);
        validateStatusTransition(jobCard.getStatus(), request.getStatus());
        jobCard.setStatus(request.getStatus());
        jobCard.setInternalRemarks(request.getRemarks());
        if (request.getOdometerOut() != null) {
            jobCard.setOdometerOut(request.getOdometerOut());
        }
        return jobCardRepository.save(jobCard);
    }

    @Override
    @Transactional(readOnly = true)
    public JobCard getJobCardById(Long id) {
        return jobCardRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Job card not found with id: " + id));
    }

    @Override
    @Transactional(readOnly = true)
    public JobCard getJobCardByNo(String jobCardNo) {
        return jobCardRepository.findByJobCardNo(jobCardNo)
                .orElseThrow(() -> new ResourceNotFoundException("Job card not found: " + jobCardNo));
    }

    @Override
    @Transactional(readOnly = true)
    public List<JobCard> getJobCardsByBranch(Long branchId) {
        return jobCardRepository.findByBranchId(branchId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<JobCard> getJobCardsByCustomer(Long customerId) {
        return jobCardRepository.findByCustomerId(customerId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<JobCard> getJobCardsByVehicle(Long vehicleId) {
        return jobCardRepository.findByVehicleId(vehicleId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<JobCard> getJobCardsByStatus(JobCardStatus status) {
        return jobCardRepository.findByStatus(status);
    }

    @Override
    @Transactional(readOnly = true)
    public List<JobCard> getJobCardsByBranchAndStatus(Long branchId, JobCardStatus status) {
        return jobCardRepository.findByBranchIdAndStatus(branchId, status);
    }

    @Override
    public void deliverJobCard(Long id, Integer odometerOut) {
        JobCard jobCard = getJobCardById(id);
        if (jobCard.getStatus() != JobCardStatus.READY_FOR_DELIVERY) {
            throw new BusinessException("Job card must be in READY_FOR_DELIVERY status before delivery");
        }
        jobCard.setStatus(JobCardStatus.DELIVERED);
        jobCard.setOdometerOut(odometerOut);
        jobCard.setDeliveryTime(LocalDateTime.now());
        jobCardRepository.save(jobCard);
    }

    private String generateJobCardNo(Branch branch) {
        String prefix = "JC-" + branch.getId() + "-";
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
        return prefix + timestamp;
    }

    private void validateStatusTransition(JobCardStatus current, JobCardStatus next) {
        boolean valid = switch (current) {
            case CREATED -> next == JobCardStatus.INSPECTED || next == JobCardStatus.CANCELLED;
            case INSPECTED -> next == JobCardStatus.IN_PROGRESS || next == JobCardStatus.CANCELLED;
            case IN_PROGRESS -> next == JobCardStatus.ON_HOLD || next == JobCardStatus.QC_PENDING;
            case ON_HOLD -> next == JobCardStatus.IN_PROGRESS || next == JobCardStatus.CANCELLED;
            case QC_PENDING -> next == JobCardStatus.QC_PASSED || next == JobCardStatus.IN_PROGRESS;
            case QC_PASSED -> next == JobCardStatus.READY_FOR_DELIVERY;
            case READY_FOR_DELIVERY -> next == JobCardStatus.DELIVERED;
            default -> false;
        };
        if (!valid) {
            throw new BusinessException("Invalid status transition from " + current + " to " + next);
        }
    }
}
