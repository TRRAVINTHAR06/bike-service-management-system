package com.bikeservice.service.impl;

import com.bikeservice.dto.request.PartsMasterRequest;
import com.bikeservice.exception.ResourceNotFoundException;
import com.bikeservice.model.PartsMaster;
import com.bikeservice.repository.PartsMasterRepository;
import com.bikeservice.service.PartsMasterService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class PartsMasterServiceImpl implements PartsMasterService {

    private final PartsMasterRepository partsMasterRepository;

    @Override
    public PartsMaster createPart(PartsMasterRequest request) {
        PartsMaster part = PartsMaster.builder()
                .partName(request.getPartName())
                .oemPartNo(request.getOemPartNo())
                .partCategory(request.getPartCategory())
                .applicableModels(request.getApplicableModels())
                .unit(request.getUnit())
                .costPrice(request.getCostPrice())
                .sellingPrice(request.getSellingPrice())
                .warrantyMonths(request.getWarrantyMonths())
                .active(true)
                .build();
        return partsMasterRepository.save(part);
    }

    @Override
    public PartsMaster updatePart(Long id, PartsMasterRequest request) {
        PartsMaster part = getPartById(id);
        part.setPartName(request.getPartName());
        part.setPartCategory(request.getPartCategory());
        part.setApplicableModels(request.getApplicableModels());
        part.setCostPrice(request.getCostPrice());
        part.setSellingPrice(request.getSellingPrice());
        part.setWarrantyMonths(request.getWarrantyMonths());
        return partsMasterRepository.save(part);
    }

    @Override
    @Transactional(readOnly = true)
    public PartsMaster getPartById(Long id) {
        return partsMasterRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Part not found: " + id));
    }

    @Override
    @Transactional(readOnly = true)
    public List<PartsMaster> getAllActiveParts() {
        return partsMasterRepository.findByActiveTrue();
    }

    @Override
    @Transactional(readOnly = true)
    public List<PartsMaster> searchParts(String query) {
        return partsMasterRepository.searchParts(query);
    }

    @Override
    public void deactivatePart(Long id) {
        PartsMaster part = getPartById(id);
        part.setActive(false);
        partsMasterRepository.save(part);
    }
}
