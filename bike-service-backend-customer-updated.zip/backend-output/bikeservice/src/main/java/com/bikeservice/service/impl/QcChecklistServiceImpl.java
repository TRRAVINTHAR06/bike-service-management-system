package com.bikeservice.service.impl;

import com.bikeservice.dto.request.QcChecklistRequest;
import com.bikeservice.enums.JobCardStatus;
import com.bikeservice.exception.BusinessException;
import com.bikeservice.exception.ResourceNotFoundException;
import com.bikeservice.model.JobCard;
import com.bikeservice.model.QcChecklist;
import com.bikeservice.model.User;
import com.bikeservice.repository.JobCardRepository;
import com.bikeservice.repository.QcChecklistRepository;
import com.bikeservice.repository.UserRepository;
import com.bikeservice.service.JobCardService;
import com.bikeservice.service.QcChecklistService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Transactional
public class QcChecklistServiceImpl implements QcChecklistService {

    private final QcChecklistRepository qcChecklistRepository;
    private final JobCardService jobCardService;
    private final JobCardRepository jobCardRepository;   // BUG FIX 6: needed for explicit save
    private final UserRepository userRepository;

    @Override
    public QcChecklist submitQc(QcChecklistRequest request) {
        JobCard jobCard = jobCardService.getJobCardById(request.getJobCardId());

        // BUG FIX 6: Job card must be in QC_PENDING before QC can be submitted
        if (jobCard.getStatus() != JobCardStatus.QC_PENDING) {
            throw new BusinessException(
                "Job card must be in QC_PENDING status to submit QC. Current status: " + jobCard.getStatus());
        }

        User inspector = null;
        if (request.getInspectorId() != null) {
            inspector = userRepository.findById(request.getInspectorId())
                    .orElseThrow(() -> new ResourceNotFoundException("Inspector not found"));
        }

        boolean allPassed = request.isEngineCheck() && request.isBrakeCheck()
                && request.isLightCheck() && request.isTiresCheck()
                && request.isCleanlinessCheck() && request.isRoadTestDone();

        QcChecklist qc = qcChecklistRepository.findByJobCardId(request.getJobCardId())
                .orElse(QcChecklist.builder().jobCard(jobCard).build());

        qc.setInspector(inspector);
        qc.setEngineCheck(request.isEngineCheck());
        qc.setBrakeCheck(request.isBrakeCheck());
        qc.setLightCheck(request.isLightCheck());
        qc.setTiresCheck(request.isTiresCheck());
        qc.setCleanlinessCheck(request.isCleanlinessCheck());
        qc.setRoadTestDone(request.isRoadTestDone());
        qc.setPassed(allPassed);
        qc.setRemarks(request.getRemarks());
        qc.setCheckedAt(LocalDateTime.now());

        QcChecklist saved = qcChecklistRepository.save(qc);

        // BUG FIX 6: Explicitly save jobCard status — don't rely on dirty-checking
        // which may not flush if session closes before transaction commits.
        if (allPassed) {
            jobCard.setStatus(JobCardStatus.QC_PASSED);
        } else {
            jobCard.setStatus(JobCardStatus.IN_PROGRESS);
        }
        jobCardRepository.save(jobCard);   // was missing — status change was silently lost

        return saved;
    }

    @Override
    @Transactional(readOnly = true)
    public QcChecklist getQcByJobCard(Long jobCardId) {
        return qcChecklistRepository.findByJobCardId(jobCardId)
                .orElseThrow(() -> new ResourceNotFoundException("QC checklist not found for job card: " + jobCardId));
    }
}
