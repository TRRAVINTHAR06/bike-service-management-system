package com.bikeservice.service.impl;

import com.bikeservice.dto.request.ServiceCatalogRequest;
import com.bikeservice.enums.ServiceType;
import com.bikeservice.exception.ResourceNotFoundException;
import com.bikeservice.model.ServiceCatalog;
import com.bikeservice.repository.ServiceCatalogRepository;
import com.bikeservice.service.ServiceCatalogService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class ServiceCatalogServiceImpl implements ServiceCatalogService {

    private final ServiceCatalogRepository serviceCatalogRepository;

    @Override
    public ServiceCatalog createService(ServiceCatalogRequest request) {
        ServiceCatalog catalog = ServiceCatalog.builder()
                .serviceName(request.getServiceName())
                .serviceType(request.getServiceType())
                .description(request.getDescription())
                .laborCharge(request.getLaborCharge())
                .stdMinutes(request.getStdMinutes())
                .applicableModels(request.getApplicableModels())
                .active(true)
                .build();
        return serviceCatalogRepository.save(catalog);
    }

    @Override
    public ServiceCatalog updateService(Long id, ServiceCatalogRequest request) {
        ServiceCatalog catalog = getServiceById(id);
        catalog.setServiceName(request.getServiceName());
        catalog.setDescription(request.getDescription());
        catalog.setLaborCharge(request.getLaborCharge());
        catalog.setStdMinutes(request.getStdMinutes());
        catalog.setApplicableModels(request.getApplicableModels());
        return serviceCatalogRepository.save(catalog);
    }

    @Override
    @Transactional(readOnly = true)
    public ServiceCatalog getServiceById(Long id) {
        return serviceCatalogRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Service not found: " + id));
    }

    @Override
    @Transactional(readOnly = true)
    public List<ServiceCatalog> getAllActiveServices() {
        return serviceCatalogRepository.findByActiveTrue();
    }

    @Override
    @Transactional(readOnly = true)
    public List<ServiceCatalog> getServicesByType(ServiceType type) {
        return serviceCatalogRepository.findByServiceTypeAndActiveTrue(type);
    }

    @Override
    public void deactivateService(Long id) {
        ServiceCatalog catalog = getServiceById(id);
        catalog.setActive(false);
        serviceCatalogRepository.save(catalog);
    }
}
