package com.bikeservice.service.impl;

import com.bikeservice.dto.request.VehicleRequest;
import com.bikeservice.exception.DuplicateResourceException;
import com.bikeservice.exception.ResourceNotFoundException;
import com.bikeservice.model.Customer;
import com.bikeservice.model.Vehicle;
import com.bikeservice.repository.VehicleRepository;
import com.bikeservice.service.CustomerService;
import com.bikeservice.service.VehicleService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class VehicleServiceImpl implements VehicleService {

    private final VehicleRepository vehicleRepository;
    private final CustomerService customerService;

    @Override
    public Vehicle createVehicle(VehicleRequest request) {
        if (vehicleRepository.existsByChassisNo(request.getChassisNo())) {
            throw new DuplicateResourceException("Vehicle already registered with chassis: " + request.getChassisNo());
        }
        Customer customer = customerService.getCustomerById(request.getCustomerId());
        Vehicle vehicle = Vehicle.builder()
                .customer(customer)
                .chassisNo(request.getChassisNo())
                .engineNo(request.getEngineNo())
                .regNo(request.getRegNo())
                .make(request.getMake())
                .model(request.getModel())
                .year(request.getYear())
                .color(request.getColor())
                .odometer(request.getOdometer())
                .fuelType(request.getFuelType())
                .build();
        return vehicleRepository.save(vehicle);
    }

    @Override
    public Vehicle updateVehicle(Long id, VehicleRequest request) {
        Vehicle vehicle = getVehicleById(id);
        vehicle.setRegNo(request.getRegNo());
        vehicle.setColor(request.getColor());
        vehicle.setOdometer(request.getOdometer());
        return vehicleRepository.save(vehicle);
    }

    @Override
    @Transactional(readOnly = true)
    public Vehicle getVehicleById(Long id) {
        return vehicleRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Vehicle not found with id: " + id));
    }

    @Override
    @Transactional(readOnly = true)
    public List<Vehicle> getVehiclesByCustomer(Long customerId) {
        return vehicleRepository.findByCustomerId(customerId);
    }

    @Override
    @Transactional(readOnly = true)
    public Vehicle getVehicleByChassisNo(String chassisNo) {
        return vehicleRepository.findByChassisNo(chassisNo)
                .orElseThrow(() -> new ResourceNotFoundException("Vehicle not found with chassis: " + chassisNo));
    }
}
