# BikeService Management — React Frontend

## Prerequisites
- Node.js 16+ and npm
- Backend running at http://localhost:8080

## Setup & Run

```bash
# Install dependencies
npm install

# Start development server
npm start
```

App runs at: http://localhost:3000

## First Login

1. Register a user via the backend first:
   POST http://localhost:8080/api/auth/register
   {
     "name": "Admin User",
     "email": "admin@bikeservice.com",
     "password": "admin123",
     "role": "ADMIN"
   }

2. Then log in at http://localhost:3000/login

## Pages

| Route                | Description                        |
|---------------------|------------------------------------|
| /dashboard          | Summary stats + recent job cards   |
| /customers          | Customer list, search, create      |
| /customers/:id      | Customer detail + vehicle + history|
| /vehicles           | Vehicle registration                |
| /job-cards          | Job card list with status filter    |
| /job-cards/:id      | Full detail: status, estimate, QC, invoice, payment |
| /appointments       | Book and manage appointments        |
| /inventory          | Branch stock + low stock alerts     |
| /parts              | Parts master CRUD                   |
| /service-catalog    | Service catalog CRUD                |
| /branches           | Branch management                   |
| /reports            | Revenue and job card charts         |

## Backend Connection

Edit `src/services/api.js` line 3 to change the backend URL:
```js
const API_BASE = 'http://localhost:8080/api';
```

## Tech Stack
- React 18 + React Router 6
- Axios (with JWT interceptor)
- Recharts (charts)
- Syne + JetBrains Mono (fonts)
- Industrial dark theme with orange accent
