import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import Sidebar from './components/layout/Sidebar';
import LoginPage from './pages/auth/LoginPage';
import DashboardPage from './pages/dashboard/DashboardPage';
import CustomersPage from './pages/customers/CustomersPage';
import CustomerDetailPage from './pages/customers/CustomerDetailPage';
import JobCardsPage from './pages/jobcards/JobCardsPage';
import JobCardDetailPage from './pages/jobcards/JobCardDetailPage';
import InventoryPage from './pages/inventory/InventoryPage';
import PartsPage from './pages/parts/PartsPage';
import ReportsPage from './pages/reports/ReportsPage';
import { AppointmentsPage } from './pages/appointments/AppointmentsPage';
import { InvoicesPage, BranchesPage, ServiceCatalogPage, VehiclesPage } from './pages/misc/MiscPages';
import CustomerPortal from './pages/customer/CustomerPortal';
import './index.css';

function PrivateLayout({ children }) {
  return (
    <div className="app-layout">
      <Sidebar />
      <div className="main-area">{children}</div>
    </div>
  );
}

function ProtectedRoute({ children, staffOnly }) {
  const { user, loading, isCustomer } = useAuth();
  if (loading) return null;
  if (!user) return <Navigate to="/login" replace />;
  if (staffOnly && isCustomer()) return <Navigate to="/customer" replace />;
  return <PrivateLayout>{children}</PrivateLayout>;
}

function CustomerRoute({ children }) {
  const { user, loading, isCustomer } = useAuth();
  if (loading) return null;
  if (!user) return <Navigate to="/login" replace />;
  if (!isCustomer()) return <Navigate to="/dashboard" replace />;
  return children;
}

function AppRoutes() {
  const { user, isCustomer } = useAuth();
  return (
    <Routes>
      <Route path="/login" element={
        user ? (isCustomer() ? <Navigate to="/customer" /> : <Navigate to="/dashboard" />) : <LoginPage />
      } />

      {/* Customer Portal */}
      <Route path="/customer/*" element={
        <CustomerRoute><CustomerPortal /></CustomerRoute>
      } />

      {/* Staff Routes */}
      <Route path="/dashboard" element={<ProtectedRoute staffOnly><DashboardPage /></ProtectedRoute>} />
      <Route path="/customers" element={<ProtectedRoute staffOnly><CustomersPage /></ProtectedRoute>} />
      <Route path="/customers/:id" element={<ProtectedRoute staffOnly><CustomerDetailPage /></ProtectedRoute>} />
      <Route path="/vehicles" element={<ProtectedRoute staffOnly><VehiclesPage /></ProtectedRoute>} />
      <Route path="/job-cards" element={<ProtectedRoute staffOnly><JobCardsPage /></ProtectedRoute>} />
      <Route path="/job-cards/:id" element={<ProtectedRoute staffOnly><JobCardDetailPage /></ProtectedRoute>} />
      <Route path="/appointments" element={<ProtectedRoute staffOnly><AppointmentsPage /></ProtectedRoute>} />
      <Route path="/inventory" element={<ProtectedRoute staffOnly><InventoryPage /></ProtectedRoute>} />
      <Route path="/parts" element={<ProtectedRoute staffOnly><PartsPage /></ProtectedRoute>} />
      <Route path="/service-catalog" element={<ProtectedRoute staffOnly><ServiceCatalogPage /></ProtectedRoute>} />
      <Route path="/invoices" element={<ProtectedRoute staffOnly><InvoicesPage /></ProtectedRoute>} />
      <Route path="/branches" element={<ProtectedRoute staffOnly><BranchesPage /></ProtectedRoute>} />
      <Route path="/reports" element={<ProtectedRoute staffOnly><ReportsPage /></ProtectedRoute>} />
      <Route path="/qc" element={<ProtectedRoute staffOnly><div style={{padding:24,color:'var(--text-muted)'}}>QC is accessed from a Job Card detail page → QC tab.</div></ProtectedRoute>} />
      <Route path="/estimates" element={<ProtectedRoute staffOnly><div style={{padding:24,color:'var(--text-muted)'}}>Estimates are accessed from a Job Card detail page → Estimate tab.</div></ProtectedRoute>} />

      <Route path="/" element={
        user ? (isCustomer() ? <Navigate to="/customer" /> : <Navigate to="/dashboard" />) : <Navigate to="/login" />
      } />
      <Route path="*" element={
        user ? (isCustomer() ? <Navigate to="/customer" /> : <Navigate to="/dashboard" />) : <Navigate to="/login" />
      } />
    </Routes>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
    </AuthProvider>
  );
}
