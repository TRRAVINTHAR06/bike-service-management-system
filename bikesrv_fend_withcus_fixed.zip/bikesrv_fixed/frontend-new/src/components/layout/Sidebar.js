import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { getInitials } from '../../utils/helpers';

const ALL_NAV = [
  { section: 'Overview', roles: ['ADMIN','BRANCH_MANAGER','SERVICE_ADVISOR','TECHNICIAN','QC_INSPECTOR','ACCOUNTS','STORE_INCHARGE'], items: [
    { label: 'Dashboard', path: '/dashboard', icon: '▦', roles: ['ADMIN','BRANCH_MANAGER','ACCOUNTS'] },
  ]},
  { section: 'Operations', roles: null, items: [
    { label: 'Job Cards', path: '/job-cards', icon: '◈', roles: ['ADMIN','BRANCH_MANAGER','SERVICE_ADVISOR','TECHNICIAN','QC_INSPECTOR','ACCOUNTS','STORE_INCHARGE'] },
    { label: 'Appointments', path: '/appointments', icon: '◷', roles: null },
    { label: 'QC Checklist', path: '/qc', icon: '✓', roles: ['ADMIN','BRANCH_MANAGER','QC_INSPECTOR'] },
  ]},
  { section: 'Customers', roles: null, items: [
    { label: 'Customers', path: '/customers', icon: '◉', roles: null },
    { label: 'Vehicles', path: '/vehicles', icon: '◎', roles: null },
  ]},
  { section: 'Finance', roles: null, items: [
    { label: 'Invoices', path: '/invoices', icon: '◫', roles: ['ADMIN','BRANCH_MANAGER','ACCOUNTS'] },
    { label: 'Estimates', path: '/estimates', icon: '◧', roles: ['ADMIN','BRANCH_MANAGER','SERVICE_ADVISOR','ACCOUNTS'] },
  ]},
  { section: 'Inventory', roles: null, items: [
    { label: 'Parts Master', path: '/parts', icon: '⬡', roles: ['ADMIN','BRANCH_MANAGER','STORE_INCHARGE','SERVICE_ADVISOR'] },
    { label: 'Stock', path: '/inventory', icon: '⬢', roles: ['ADMIN','BRANCH_MANAGER','STORE_INCHARGE','ACCOUNTS'] },
    { label: 'Services', path: '/service-catalog', icon: '◆', roles: null },
  ]},
  { section: 'Admin', roles: ['ADMIN','BRANCH_MANAGER'], items: [
    { label: 'Branches', path: '/branches', icon: '◼', roles: ['ADMIN','BRANCH_MANAGER'] },
    { label: 'Reports', path: '/reports', icon: '◈', roles: ['ADMIN','BRANCH_MANAGER','ACCOUNTS'] },
  ]},
];

export default function Sidebar() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, logout } = useAuth();
  const role = user?.role;

  const canAccess = (roles) => !roles || roles.includes(role);

  return (
    <div className="sidebar">
      <div className="sidebar-logo">
        <div className="logo-mark">
          <div className="logo-icon">BS</div>
          <div>
            <div className="logo-text">BikeService</div>
            <div className="logo-sub">mgmt system</div>
          </div>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', paddingBottom: 8 }}>
        {ALL_NAV.map(section => {
          if (!canAccess(section.roles)) return null;
          const visibleItems = section.items.filter(item => canAccess(item.roles));
          if (visibleItems.length === 0) return null;
          return (
            <div className="sidebar-section" key={section.section}>
              <div className="sidebar-section-label">{section.section}</div>
              {visibleItems.map(item => (
                <button
                  key={item.path}
                  className={`nav-item ${location.pathname.startsWith(item.path) ? 'active' : ''}`}
                  onClick={() => navigate(item.path)}>
                  <span style={{ fontSize: 13, opacity: 0.8 }}>{item.icon}</span>
                  {item.label}
                  {item.badge && <span className="nav-badge">{item.badge}</span>}
                </button>
              ))}
            </div>
          );
        })}
      </div>

      <div className="sidebar-footer">
        <div className="user-card">
          <div className="user-avatar">{getInitials(user?.name || 'User')}</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div className="user-name" style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{user?.name || 'User'}</div>
            <div className="user-role">{user?.role?.replace(/_/g,' ').toLowerCase()}</div>
          </div>
          <button className="btn-ghost btn" style={{ padding: '4px 6px', fontSize: 16 }} onClick={logout} title="Logout">⏻</button>
        </div>
      </div>
    </div>
  );
}
