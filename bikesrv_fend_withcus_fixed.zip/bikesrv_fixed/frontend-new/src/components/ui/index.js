import React from 'react';
import { statusColor } from '../../utils/helpers';

export function Modal({ title, onClose, children, footer, size }) {
  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className={`modal ${size === 'lg' ? 'modal-lg' : ''}`}>
        <div className="modal-header">
          <span className="modal-title">{title}</span>
          <button className="btn btn-ghost btn-sm" onClick={onClose} style={{ fontSize: 18, padding: '2px 6px' }}>×</button>
        </div>
        {children}
        {footer && <div className="modal-footer">{footer}</div>}
      </div>
    </div>
  );
}

export function Badge({ status, text }) {
  const cls = statusColor(status || text);
  return <span className={`badge badge-${cls}`}>{(text || status || '').replace(/_/g, ' ')}</span>;
}

export function Loading() {
  return <div className="loading"><div className="spinner" />Loading...</div>;
}

export function EmptyState({ message = 'No records found', icon = '◫' }) {
  return (
    <div className="empty-state">
      <div className="empty-icon">{icon}</div>
      <p>{message}</p>
    </div>
  );
}

export function StatCard({ label, value, sub, color }) {
  return (
    <div className="stat-card" style={{ '--accent-color': color || 'var(--accent)' }}>
      <div className="stat-label">{label}</div>
      <div className="stat-value">{value}</div>
      {sub && <div className="stat-sub">{sub}</div>}
    </div>
  );
}

export function FormGroup({ label, children }) {
  return (
    <div className="form-group">
      <label className="form-label">{label}</label>
      {children}
    </div>
  );
}

export function Topbar({ title, subtitle, actions }) {
  return (
    <div className="topbar">
      <div>
        <div className="topbar-title">{title}</div>
        {subtitle && <div style={{ fontSize: 11, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>{subtitle}</div>}
      </div>
      {actions && <div className="topbar-right">{actions}</div>}
    </div>
  );
}

export function Alert({ type = 'error', children }) {
  return <div className={`alert alert-${type}`}>{children}</div>;
}
