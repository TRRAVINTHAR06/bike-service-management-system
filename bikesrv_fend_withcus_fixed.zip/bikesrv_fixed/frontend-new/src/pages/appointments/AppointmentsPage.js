import React, { useState, useEffect, useCallback } from 'react';
import { appointmentAPI, customerAPI, vehicleAPI, branchAPI } from '../../services/api';
import { Loading, EmptyState, Modal, FormGroup, Alert, Topbar, Badge } from '../../components/ui';
import { formatDateTime } from '../../utils/helpers';

function AppointmentForm({ onSave, onClose }) {
  const [form, setForm] = useState({ branchId:1, customerId:'', vehicleId:'', slotTime:'', serviceType:'PAID_SERVICE', remarks:'', pickupRequired:false });
  const [vehicles, setVehicles] = useState([]);
  const [phone, setPhone] = useState('');
  const [customer, setCustomer] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const findCustomer = async () => {
    try {
      const res = await customerAPI.getByPhone(phone);
      setCustomer(res.data);
      setForm(p => ({ ...p, customerId: res.data.id }));
      const vRes = await vehicleAPI.getByCustomer(res.data.id);
      setVehicles(vRes.data || []);
    } catch { setError('Customer not found'); }
  };

  const submit = async (e) => {
    e.preventDefault(); setLoading(true); setError('');
    try {
      await appointmentAPI.create({ ...form, customerId: Number(form.customerId), vehicleId: Number(form.vehicleId) });
      onSave();
    } catch (err) { setError(err?.message || 'Failed'); }
    finally { setLoading(false); }
  };

  return (
    <form onSubmit={submit}>
      {error && <Alert type="error">{error}</Alert>}
      <div style={{ display:'flex', gap:8, marginBottom:14 }}>
        <input placeholder="Customer phone" value={phone} onChange={e => setPhone(e.target.value)} />
        <button type="button" className="btn btn-secondary" onClick={findCustomer}>Find</button>
      </div>
      {customer && <div style={{ padding:'10px 12px', background:'var(--bg-elevated)', borderRadius:'var(--radius)', marginBottom:14, fontSize:13 }}>{customer.name} · {customer.phone}</div>}
      {vehicles.length > 0 && (
        <FormGroup label="Vehicle *">
          <select value={form.vehicleId} onChange={e => setForm(p => ({ ...p, vehicleId: e.target.value }))} required>
            <option value="">-- select --</option>
            {vehicles.map(v => <option key={v.id} value={v.id}>{v.make} {v.model} ({v.regNo || v.chassisNo})</option>)}
          </select>
        </FormGroup>
      )}
      <div className="form-row">
        <FormGroup label="Slot Date & Time *"><input type="datetime-local" value={form.slotTime} onChange={e => setForm(p => ({ ...p, slotTime: e.target.value }))} required /></FormGroup>
        <FormGroup label="Service Type">
          <select value={form.serviceType} onChange={e => setForm(p => ({ ...p, serviceType: e.target.value }))}>
            {['FREE_SERVICE','PAID_SERVICE','RUNNING_REPAIR','ACCIDENTAL_REPAIR','EXPRESS_SERVICE'].map(t => <option key={t}>{t.replace(/_/g,' ')}</option>)}
          </select>
        </FormGroup>
      </div>
      <FormGroup label="Remarks"><textarea rows={2} value={form.remarks} onChange={e => setForm(p => ({ ...p, remarks: e.target.value }))} /></FormGroup>
      <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:14 }}>
        <input type="checkbox" id="pickup" checked={form.pickupRequired} onChange={e => setForm(p => ({ ...p, pickupRequired: e.target.checked }))} style={{ width:'auto' }} />
        <label htmlFor="pickup" style={{ fontSize:13 }}>Pickup Required</label>
      </div>
      <div className="modal-footer">
        <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
        <button type="submit" className="btn btn-primary" disabled={loading || !form.vehicleId}>{loading ? 'Booking...' : 'Book Appointment'}</button>
      </div>
    </form>
  );
}

export function AppointmentsPage() {
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);

  const load = async () => {
    setLoading(true);
    try { const res = await appointmentAPI.getByBranch(1); setAppointments(res.data || []); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, []);

  return (
    <>
      <Topbar title="Appointments" subtitle={`${appointments.length} scheduled`}
        actions={<button className="btn btn-primary" onClick={() => setShowModal(true)}>+ Book Appointment</button>}
      />
      <div className="page-content">
        <div className="card">
          {loading ? <Loading /> : (
            <div className="table-wrap">
              <table>
                <thead><tr><th>Customer</th><th>Vehicle</th><th>Slot Time</th><th>Service</th><th>Pickup</th><th>Status</th><th>Actions</th></tr></thead>
                <tbody>
                  {appointments.length === 0 ? <tr><td colSpan={7}><EmptyState message="No appointments" icon="◷" /></td></tr>
                  : appointments.map(a => (
                    <tr key={a.id}>
                      <td style={{ fontWeight:500 }}>{a.customer?.name}</td>
                      <td style={{ fontSize:12 }}>{a.vehicle?.make} {a.vehicle?.model}</td>
                      <td className="mono" style={{ fontSize:11 }}>{formatDateTime(a.slotTime)}</td>
                      <td style={{ fontSize:11 }}>{a.serviceType?.replace(/_/g,' ')}</td>
                      <td>{a.pickupRequired ? <span className="badge badge-in_progress">Yes</span> : '—'}</td>
                      <td><span className={`badge badge-${a.status?.toLowerCase()}`}>{a.status}</span></td>
                      <td>
                        <select className="btn btn-ghost btn-sm" style={{ padding:'4px 8px', cursor:'pointer' }}
                          onChange={e => appointmentAPI.updateStatus(a.id, e.target.value).then(load)}>
                          <option value="">Change status</option>
                          {['BOOKED','CONFIRMED','ARRIVED','CANCELLED','NO_SHOW'].map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
      {showModal && (
        <Modal title="Book Appointment" size="lg" onClose={() => setShowModal(false)}>
          <AppointmentForm onSave={() => { setShowModal(false); load(); }} onClose={() => setShowModal(false)} />
        </Modal>
      )}
    </>
  );
}
