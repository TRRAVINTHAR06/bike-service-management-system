import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { authAPI, customerAuthAPI } from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import { Alert } from '../../components/ui';

function BrandHeader({ sub }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20 }}>
      <div className="logo-icon" style={{ width: 40, height: 40, fontSize: 18 }}>BS</div>
      <div>
        <div style={{ fontSize: 18, fontWeight: 800 }}>BikeService</div>
        <div style={{ fontSize: 11, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>{sub || 'management system'}</div>
      </div>
    </div>
  );
}

function AuthFooter({ children }) {
  return (
    <p style={{ marginTop: 20, textAlign: 'center', fontSize: 12, color: 'var(--text-muted)' }}>{children}</p>
  );
}

// ─── Staff Sign In ────────────────────────────────────────────────────────────
function StaffSignInForm({ onSwitch }) {
  const [form, setForm] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showPw, setShowPw] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true); setError('');
    try {
      const res = await authAPI.login(form);
      if (res.success) {
        login(res.data.token, { name: res.data.name, email: res.data.email, role: res.data.role });
        navigate(location.state?.from?.pathname || '/dashboard', { replace: true });
      }
    } catch (err) {
      setError(err?.message || 'Invalid email or password');
    } finally { setLoading(false); }
  };

  return (
    <>
      <BrandHeader sub="staff portal" />
      <h2 style={{ fontSize: 22, fontWeight: 800, letterSpacing: '-0.5px', marginBottom: 4 }}>Staff Sign in</h2>
      <p style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 20 }}>Welcome back — enter your credentials to continue</p>
      {error && <Alert type="error">{error}</Alert>}
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label className="form-label">Email</label>
          <input type="email" placeholder="you@bikeservice.com" value={form.email}
            onChange={e => setForm({ ...form, email: e.target.value })} required autoFocus />
        </div>
        <div className="form-group">
          <label className="form-label" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span>Password</span>
            <button type="button" className="auth-link" style={{ fontSize: 11 }} onClick={() => onSwitch('forgot')}>Forgot password?</button>
          </label>
          <div style={{ position: 'relative' }}>
            <input type={showPw ? 'text' : 'password'} placeholder="••••••••" value={form.password}
              onChange={e => setForm({ ...form, password: e.target.value })} required style={{ paddingRight: 42 }} />
            <button type="button" onClick={() => setShowPw(p => !p)}
              style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', fontSize: 11 }}>
              {showPw ? 'hide' : 'show'}
            </button>
          </div>
        </div>
        <button className="btn btn-primary" type="submit" disabled={loading}
          style={{ width: '100%', justifyContent: 'center', padding: '11px', marginTop: 4 }}>
          {loading ? 'Signing in…' : 'Sign in →'}
        </button>
      </form>
      <AuthFooter>
        Don't have an account?{' '}
        <button type="button" className="auth-link" onClick={() => onSwitch('register')}>Create account</button>
      </AuthFooter>
    </>
  );
}

// ─── Staff Register ───────────────────────────────────────────────────────────
const STAFF_ROLES = ['ADMIN', 'BRANCH_MANAGER', 'SERVICE_ADVISOR', 'TECHNICIAN', 'QC_INSPECTOR', 'ACCOUNTS', 'STORE_INCHARGE'];

function StaffRegisterForm({ onSwitch }) {
  const [form, setForm] = useState({ name: '', email: '', password: '', phone: '', role: 'SERVICE_ADVISOR' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [showPw, setShowPw] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (form.password.length < 6) { setError('Password must be at least 6 characters'); return; }
    setLoading(true); setError(''); setSuccess('');
    try {
      const res = await authAPI.register(form);
      if (res.success) { setSuccess('Account created successfully!'); setForm({ name: '', email: '', password: '', phone: '', role: 'SERVICE_ADVISOR' }); }
    } catch (err) {
      setError(err?.message || 'Registration failed. Try again.');
    } finally { setLoading(false); }
  };

  return (
    <>
      <BrandHeader sub="staff portal" />
      <h2 style={{ fontSize: 22, fontWeight: 800, letterSpacing: '-0.5px', marginBottom: 4 }}>Create staff account</h2>
      <p style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 20 }}>Register a new team member</p>
      {error && <Alert type="error">{error}</Alert>}
      {success && (
        <div style={{ padding: '12px 14px', background: 'var(--success-dim)', border: '1px solid rgba(34,197,94,0.2)', borderRadius: 'var(--radius)', color: 'var(--success)', fontSize: 12, marginBottom: 16 }}>
          ✓ {success}{' '}
          <button type="button" className="auth-link" style={{ color: 'var(--success)' }} onClick={() => onSwitch('login')}>Sign in →</button>
        </div>
      )}
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label className="form-label">Full name</label>
          <input type="text" placeholder="Jane Doe" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required autoFocus />
        </div>
        <div className="grid-2">
          <div className="form-group">
            <label className="form-label">Email</label>
            <input type="email" placeholder="jane@bikeservice.com" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} required />
          </div>
          <div className="form-group">
            <label className="form-label">Phone</label>
            <input type="tel" placeholder="+91 98765 43210" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} />
          </div>
        </div>
        <div className="form-group">
          <label className="form-label">Password</label>
          <div style={{ position: 'relative' }}>
            <input type={showPw ? 'text' : 'password'} placeholder="Min. 6 characters" value={form.password}
              onChange={e => setForm({ ...form, password: e.target.value })} required style={{ paddingRight: 42 }} />
            <button type="button" onClick={() => setShowPw(p => !p)}
              style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', fontSize: 11 }}>
              {showPw ? 'hide' : 'show'}
            </button>
          </div>
        </div>
        <div className="form-group">
          <label className="form-label">Role</label>
          <select value={form.role} onChange={e => setForm({ ...form, role: e.target.value })}>
            {STAFF_ROLES.map(r => <option key={r} value={r}>{r.replace(/_/g,' ')}</option>)}
          </select>
        </div>
        <button className="btn btn-primary" type="submit" disabled={loading}
          style={{ width: '100%', justifyContent: 'center', padding: '11px', marginTop: 4 }}>
          {loading ? 'Creating account…' : 'Create account →'}
        </button>
      </form>
      <AuthFooter>
        Already have an account?{' '}
        <button type="button" className="auth-link" onClick={() => onSwitch('login')}>Sign in</button>
      </AuthFooter>
    </>
  );
}

// ─── Customer Sign In ─────────────────────────────────────────────────────────
function CustomerSignInForm({ onSwitch }) {
  const [form, setForm] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showPw, setShowPw] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true); setError('');
    try {
      const res = await customerAuthAPI.login(form);
      if (res.success) {
        login(res.data.token, {
          name: res.data.name,
          email: res.data.email,
          role: 'CUSTOMER',
          customerUserId: res.data.customerUserId,
          customerId: res.data.customerId,
        });
        navigate('/customer', { replace: true });
      }
    } catch (err) {
      setError(err?.message || 'Invalid email or password');
    } finally { setLoading(false); }
  };

  return (
    <>
      <BrandHeader sub="customer portal" />
      <h2 style={{ fontSize: 22, fontWeight: 800, letterSpacing: '-0.5px', marginBottom: 4 }}>Customer Sign in</h2>
      <p style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 20 }}>Track your bike service, view invoices & more</p>
      {error && <Alert type="error">{error}</Alert>}
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label className="form-label">Email</label>
          <input type="email" placeholder="you@example.com" value={form.email}
            onChange={e => setForm({ ...form, email: e.target.value })} required autoFocus />
        </div>
        <div className="form-group">
          <label className="form-label">Password</label>
          <div style={{ position: 'relative' }}>
            <input type={showPw ? 'text' : 'password'} placeholder="••••••••" value={form.password}
              onChange={e => setForm({ ...form, password: e.target.value })} required style={{ paddingRight: 42 }} />
            <button type="button" onClick={() => setShowPw(p => !p)}
              style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', fontSize: 11 }}>
              {showPw ? 'hide' : 'show'}
            </button>
          </div>
        </div>
        <button className="btn btn-primary" type="submit" disabled={loading}
          style={{ width: '100%', justifyContent: 'center', padding: '11px', marginTop: 4 }}>
          {loading ? 'Signing in…' : 'Sign in →'}
        </button>
      </form>
      <AuthFooter>
        New customer?{' '}
        <button type="button" className="auth-link" onClick={() => onSwitch('customer-register')}>Create account</button>
      </AuthFooter>
    </>
  );
}

// ─── Customer Register ────────────────────────────────────────────────────────
function CustomerRegisterForm({ onSwitch }) {
  const [form, setForm] = useState({ name:'', email:'', password:'', phone:'', address:'', city:'', role:'CUSTOMER' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [showPw, setShowPw] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (form.password.length < 6) { setError('Password must be at least 6 characters'); return; }
    setLoading(true); setError(''); setSuccess('');
    try {
      const res = await customerAuthAPI.register(form);
      if (res.success) {
        setSuccess(res.message || 'Registration successful! Please login.');
        setForm({ name:'', email:'', password:'', phone:'', address:'', city:'', role:'CUSTOMER' });
      }
    } catch (err) {
      setError(err?.message || 'Registration failed. Try again.');
    } finally { setLoading(false); }
  };

  return (
    <>
      <BrandHeader sub="customer portal" />
      <h2 style={{ fontSize: 22, fontWeight: 800, letterSpacing: '-0.5px', marginBottom: 4 }}>Create customer account</h2>
      <p style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 20 }}>Get access to track your bike's service status</p>
      {error && <Alert type="error">{error}</Alert>}
      {success && (
        <div style={{ padding: '12px 14px', background: 'var(--success-dim)', border: '1px solid rgba(34,197,94,0.2)', borderRadius: 'var(--radius)', color: 'var(--success)', fontSize: 12, marginBottom: 16 }}>
          ✓ {success}{' '}
          <button type="button" className="auth-link" style={{ color: 'var(--success)' }} onClick={() => onSwitch('customer-login')}>Sign in →</button>
        </div>
      )}
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label className="form-label">Full Name *</label>
          <input type="text" placeholder="Raj Kumar" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required autoFocus />
        </div>
        <div className="grid-2">
          <div className="form-group">
            <label className="form-label">Email *</label>
            <input type="email" placeholder="raj@example.com" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} required />
          </div>
          <div className="form-group">
            <label className="form-label">Phone</label>
            <input type="tel" placeholder="+91 98765 43210" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} />
          </div>
        </div>
        <div className="grid-2">
          <div className="form-group">
            <label className="form-label">City</label>
            <input type="text" placeholder="Chennai" value={form.city} onChange={e => setForm({ ...form, city: e.target.value })} />
          </div>
          <div className="form-group">
            <label className="form-label">Address</label>
            <input type="text" placeholder="Street, Area" value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} />
          </div>
        </div>
        <div className="form-group">
          <label className="form-label">Password *</label>
          <div style={{ position: 'relative' }}>
            <input type={showPw ? 'text' : 'password'} placeholder="Min. 6 characters" value={form.password}
              onChange={e => setForm({ ...form, password: e.target.value })} required style={{ paddingRight: 42 }} />
            <button type="button" onClick={() => setShowPw(p => !p)}
              style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', fontSize: 11 }}>
              {showPw ? 'hide' : 'show'}
            </button>
          </div>
        </div>
        <button className="btn btn-primary" type="submit" disabled={loading}
          style={{ width: '100%', justifyContent: 'center', padding: '11px', marginTop: 4 }}>
          {loading ? 'Creating account…' : 'Create account →'}
        </button>
      </form>
      <AuthFooter>
        Already have an account?{' '}
        <button type="button" className="auth-link" onClick={() => onSwitch('customer-login')}>Sign in</button>
      </AuthFooter>
    </>
  );
}

// ─── Forgot Password ──────────────────────────────────────────────────────────
function ForgotPasswordForm({ onSwitch, initialToken }) {
  const [step, setStep] = useState(initialToken ? 'reset' : 'request');
  const [email, setEmail] = useState('');
  const [token, setToken] = useState(initialToken || '');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleRequest = async (e) => {
    e.preventDefault(); setLoading(true); setError('');
    try { await authAPI.forgotPassword({ email }); setStep('sent'); }
    catch (err) { setError(err?.message || 'Could not send reset email.'); }
    finally { setLoading(false); }
  };

  const handleReset = async (e) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) { setError('Passwords do not match'); return; }
    if (newPassword.length < 6) { setError('Password must be at least 6 characters'); return; }
    setLoading(true); setError('');
    try { await authAPI.resetPassword({ token, newPassword }); setSuccess('Password reset successfully! You can now sign in.'); }
    catch (err) { setError(err?.message || 'Reset failed. The link may have expired.'); }
    finally { setLoading(false); }
  };

  return (
    <>
      <BrandHeader />
      {step === 'request' && (
        <>
          <h2 style={{ fontSize: 22, fontWeight: 800, letterSpacing: '-0.5px', marginBottom: 4 }}>Forgot password</h2>
          <p style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 20 }}>Enter your email and we'll send a reset link</p>
          {error && <Alert type="error">{error}</Alert>}
          <form onSubmit={handleRequest}>
            <div className="form-group">
              <label className="form-label">Email address</label>
              <input type="email" placeholder="you@bikeservice.com" value={email} onChange={e => setEmail(e.target.value)} required autoFocus />
            </div>
            <button className="btn btn-primary" type="submit" disabled={loading}
              style={{ width: '100%', justifyContent: 'center', padding: '11px', marginTop: 4 }}>
              {loading ? 'Sending…' : 'Send reset link →'}
            </button>
          </form>
        </>
      )}
      {step === 'sent' && (
        <>
          <h2 style={{ fontSize: 22, fontWeight: 800, letterSpacing: '-0.5px', marginBottom: 4 }}>Check your inbox</h2>
          <p style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 20 }}>A reset link has been sent to <strong>{email}</strong></p>
          <div style={{ padding: '16px 14px', background: 'var(--success-dim)', border: '1px solid rgba(34,197,94,0.2)', borderRadius: 'var(--radius)', color: 'var(--success)', fontSize: 13, marginBottom: 16 }}>
            ✓ Reset link sent. Check your inbox (and spam folder).
          </div>
          <button className="btn" type="button" onClick={() => setStep('request')} style={{ width: '100%', justifyContent: 'center', padding: '11px', background: 'var(--bg-elevated)', color: 'var(--text-secondary)', border: '1px solid var(--border)' }}>Resend link</button>
        </>
      )}
      {step === 'reset' && (
        <>
          <h2 style={{ fontSize: 22, fontWeight: 800, letterSpacing: '-0.5px', marginBottom: 4 }}>Reset password</h2>
          <p style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 20 }}>Choose a new password for your account</p>
          {error && <Alert type="error">{error}</Alert>}
          {success ? (
            <div style={{ padding: '16px 14px', background: 'var(--success-dim)', border: '1px solid rgba(34,197,94,0.2)', borderRadius: 'var(--radius)', color: 'var(--success)', fontSize: 13, marginBottom: 16 }}>
              ✓ {success}{' '}
              <button type="button" className="auth-link" style={{ color: 'var(--success)' }} onClick={() => onSwitch('login')}>Sign in →</button>
            </div>
          ) : (
            <form onSubmit={handleReset}>
              <div className="form-group">
                <label className="form-label">New password</label>
                <div style={{ position: 'relative' }}>
                  <input type={showPw ? 'text' : 'password'} placeholder="Min. 6 characters" value={newPassword}
                    onChange={e => setNewPassword(e.target.value)} required autoFocus style={{ paddingRight: 42 }} />
                  <button type="button" onClick={() => setShowPw(p => !p)}
                    style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', fontSize: 11 }}>
                    {showPw ? 'hide' : 'show'}
                  </button>
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Confirm password</label>
                <input type={showPw ? 'text' : 'password'} placeholder="Repeat password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} required />
              </div>
              <button className="btn btn-primary" type="submit" disabled={loading}
                style={{ width: '100%', justifyContent: 'center', padding: '11px', marginTop: 4 }}>
                {loading ? 'Resetting…' : 'Reset password →'}
              </button>
            </form>
          )}
        </>
      )}
      <AuthFooter>
        Remember your password?{' '}
        <button type="button" className="auth-link" onClick={() => onSwitch('login')}>Back to sign in</button>
      </AuthFooter>
    </>
  );
}

// ─── Main LoginPage ───────────────────────────────────────────────────────────
export default function LoginPage() {
  const location = useLocation();
  const [portalType, setPortalType] = useState('staff'); // 'staff' | 'customer'
  const [view, setView] = useState('login'); // login | register | forgot | customer-login | customer-register
  const [resetToken, setResetToken] = useState(null);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const action = params.get('action');
    const token = params.get('token');
    if (action === 'reset' && token) { setResetToken(token); setView('forgot'); }
    if (params.get('portal') === 'customer') { setPortalType('customer'); setView('customer-login'); }
  }, [location.search]);

  const switchPortal = (type) => {
    setPortalType(type);
    setView(type === 'customer' ? 'customer-login' : 'login');
  };

  return (
    <div className="login-page">
      <div className="login-box" style={{ width: 440 }}>
        {/* Portal toggle */}
        {view !== 'forgot' && (
          <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
            <button onClick={() => switchPortal('staff')} style={{
              flex: 1, padding: '8px', borderRadius: 'var(--radius)',
              background: portalType === 'staff' ? 'var(--accent)' : 'var(--bg-elevated)',
              color: portalType === 'staff' ? '#fff' : 'var(--text-muted)',
              border: portalType === 'staff' ? 'none' : '1px solid var(--border)',
              fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 12, cursor: 'pointer',
            }}>🔧 Staff Portal</button>
            <button onClick={() => switchPortal('customer')} style={{
              flex: 1, padding: '8px', borderRadius: 'var(--radius)',
              background: portalType === 'customer' ? 'var(--accent)' : 'var(--bg-elevated)',
              color: portalType === 'customer' ? '#fff' : 'var(--text-muted)',
              border: portalType === 'customer' ? 'none' : '1px solid var(--border)',
              fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 12, cursor: 'pointer',
            }}>🏍️ Customer Portal</button>
          </div>
        )}

        {/* Tab strip for current portal */}
        {view !== 'forgot' && (
          <div style={{ display: 'flex', borderBottom: '1px solid var(--border)', marginBottom: 24 }}>
            {portalType === 'staff' ? (
              [{ key: 'login', label: 'Sign in' }, { key: 'register', label: 'Register' }].map(tab => (
                <button key={tab.key} onClick={() => setView(tab.key)} style={{
                  flex: 1, background: 'none', border: 'none',
                  borderBottom: view === tab.key ? '2px solid var(--accent)' : '2px solid transparent',
                  color: view === tab.key ? 'var(--text-primary)' : 'var(--text-muted)',
                  fontFamily: 'var(--font-display)', fontWeight: view === tab.key ? 700 : 500,
                  fontSize: 13, padding: '10px 0', cursor: 'pointer', marginBottom: '-1px',
                }}>{tab.label}</button>
              ))
            ) : (
              [{ key: 'customer-login', label: 'Sign in' }, { key: 'customer-register', label: 'Register' }].map(tab => (
                <button key={tab.key} onClick={() => setView(tab.key)} style={{
                  flex: 1, background: 'none', border: 'none',
                  borderBottom: view === tab.key ? '2px solid var(--accent)' : '2px solid transparent',
                  color: view === tab.key ? 'var(--text-primary)' : 'var(--text-muted)',
                  fontFamily: 'var(--font-display)', fontWeight: view === tab.key ? 700 : 500,
                  fontSize: 13, padding: '10px 0', cursor: 'pointer', marginBottom: '-1px',
                }}>{tab.label}</button>
              ))
            )}
          </div>
        )}

        {view === 'login'             && <StaffSignInForm onSwitch={setView} />}
        {view === 'register'          && <StaffRegisterForm onSwitch={setView} />}
        {view === 'forgot'            && <ForgotPasswordForm onSwitch={setView} initialToken={resetToken} />}
        {view === 'customer-login'    && <CustomerSignInForm onSwitch={setView} />}
        {view === 'customer-register' && <CustomerRegisterForm onSwitch={setView} />}
      </div>
      <style>{`
        .auth-link { background:none; border:none; color:var(--accent); font-family:var(--font-display); font-size:inherit; cursor:pointer; padding:0; text-decoration:underline; text-underline-offset:2px; }
        .auth-link:hover { opacity:0.8; }
      `}</style>
    </div>
  );
}
