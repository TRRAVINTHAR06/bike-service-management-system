import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { customerPortalAPI } from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import { Alert } from '../../components/ui';

// ─── Status Badge ─────────────────────────────────────────────────────────────
function StatusBadge({ status }) {
  const colors = {
    PENDING: '#f59e0b', CONFIRMED: '#3b82f6', CANCELLED: '#ef4444',
    CREATED: '#6366f1', IN_PROGRESS: '#f59e0b', QC_PENDING: '#8b5cf6',
    READY_FOR_DELIVERY: '#10b981', DELIVERED: '#6b7280', CLOSED: '#374151',
    APPROVED: '#10b981', REJECTED: '#ef4444',
  };
  const c = colors[status] || '#6b7280';
  return (
    <span style={{ background: c + '22', color: c, border: `1px solid ${c}44`,
      padding: '2px 8px', borderRadius: 20, fontSize: 11, fontWeight: 600, whiteSpace: 'nowrap' }}>
      {status?.replace(/_/g, ' ')}
    </span>
  );
}

// ─── Star Rating ──────────────────────────────────────────────────────────────
function StarRating({ value, onChange, readOnly }) {
  return (
    <div style={{ display: 'flex', gap: 4 }}>
      {[1,2,3,4,5].map(n => (
        <span key={n} onClick={() => !readOnly && onChange(n)}
          style={{ fontSize: 22, cursor: readOnly ? 'default' : 'pointer',
            color: n <= value ? '#f59e0b' : 'var(--border)', transition: 'color 0.1s' }}>
          ★
        </span>
      ))}
    </div>
  );
}

// ─── Dashboard / Home ─────────────────────────────────────────────────────────
function CustomerHome({ user }) {
  const [statuses, setStatuses] = useState([]);
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([customerPortalAPI.trackStatus(), customerPortalAPI.getAppointments()])
      .then(([s, a]) => {
        setStatuses(s.data || []);
        setAppointments(a.data || []);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const upcoming = appointments.filter(a => a.status !== 'CANCELLED' && a.status !== 'COMPLETED').slice(0, 3);
  const active = statuses.filter(s => s.status !== 'DELIVERED' && s.status !== 'CLOSED').slice(0, 3);

  return (
    <div>
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontSize: 24, fontWeight: 800, margin: 0 }}>
          Welcome back, {user?.name?.split(' ')[0]} 👋
        </h1>
        <p style={{ color: 'var(--text-muted)', marginTop: 4, fontSize: 13 }}>
          Here's what's happening with your bikes
        </p>
      </div>

      {loading ? <div style={{ color: 'var(--text-muted)' }}>Loading…</div> : (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
          {/* Active Services */}
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">🔧 Active Services</h3>
            </div>
            {active.length === 0
              ? <p style={{ color: 'var(--text-muted)', fontSize: 13 }}>No active service jobs</p>
              : active.map(s => (
                <div key={s.jobCardId} style={{ padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div>
                      <div style={{ fontWeight: 600, fontSize: 13 }}>{s.vehicleMake} {s.vehicleModel}</div>
                      <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>#{s.jobCardNo}</div>
                    </div>
                    <StatusBadge status={s.status} />
                  </div>
                </div>
              ))
            }
          </div>

          {/* Upcoming Appointments */}
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">📅 Upcoming Appointments</h3>
            </div>
            {upcoming.length === 0
              ? <p style={{ color: 'var(--text-muted)', fontSize: 13 }}>No upcoming appointments</p>
              : upcoming.map(a => (
                <div key={a.id} style={{ padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div>
                      <div style={{ fontWeight: 600, fontSize: 13 }}>{a.serviceType?.replace(/_/g, ' ')}</div>
                      <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>
                        {a.slotTime ? new Date(a.slotTime).toLocaleString() : '—'}
                      </div>
                    </div>
                    <StatusBadge status={a.status} />
                  </div>
                </div>
              ))
            }
          </div>
        </div>
      )}
    </div>
  );
}

// ─── My Bikes ─────────────────────────────────────────────────────────────────
function MyBikes() {
  const [bikes, setBikes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ make:'', model:'', year:'', regNo:'', chassisNo:'', engineNo:'', color:'', fuelType:'PETROL', odometer:'' });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const load = () => {
    setLoading(true);
    customerPortalAPI.getBikes().then(r => setBikes(r.data || [])).catch(() => setBikes([])).finally(() => setLoading(false));
  };
  useEffect(load, []);

  const openAdd = () => { setEditing(null); setForm({ make:'', model:'', year:'', regNo:'', chassisNo:'', engineNo:'', color:'', fuelType:'PETROL', odometer:'' }); setShowForm(true); setError(''); };
  const openEdit = (b) => { setEditing(b); setForm({ make:b.make||'', model:b.model||'', year:b.year||'', regNo:b.regNo||'', chassisNo:b.chassisNo||'', engineNo:b.engineNo||'', color:b.color||'', fuelType:b.fuelType||'PETROL', odometer:b.odometer||'' }); setShowForm(true); setError(''); };

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true); setError(''); setSuccess('');
    try {
      if (editing) {
        await customerPortalAPI.updateBike(editing.id, form);
        setSuccess('Bike updated!');
      } else {
        await customerPortalAPI.addBike(form);
        setSuccess('Bike added!');
      }
      setShowForm(false); load();
    } catch (err) {
      setError(err?.message || 'Failed to save');
    } finally { setSaving(false); }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Remove this bike?')) return;
    try { await customerPortalAPI.deleteBike(id); load(); } catch (err) { alert(err?.message || 'Error'); }
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <h2 style={{ fontSize: 20, fontWeight: 800, margin: 0 }}>🏍️ My Bikes</h2>
        <button className="btn btn-primary" onClick={openAdd}>+ Add Bike</button>
      </div>
      {success && <Alert type="success">{success}</Alert>}
      {error && <Alert type="error">{error}</Alert>}

      {showForm && (
        <div className="card" style={{ marginBottom: 20 }}>
          <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 16 }}>{editing ? 'Edit Bike' : 'Add New Bike'}</h3>
          <form onSubmit={handleSave}>
            <div className="grid-2">
              {[['Make', 'make', 'Honda'], ['Model', 'model', 'CB300R'], ['Year', 'year', '2022'], ['Reg No', 'regNo', 'TN01AB1234']].map(([lbl, key, ph]) => (
                <div className="form-group" key={key}>
                  <label className="form-label">{lbl}</label>
                  <input value={form[key]} onChange={e => setForm({...form, [key]: e.target.value})} placeholder={ph} required={key==='make'||key==='model'} />
                </div>
              ))}
              {!editing && (
                <>
                  <div className="form-group">
                    <label className="form-label">Chassis No *</label>
                    <input value={form.chassisNo} onChange={e => setForm({...form, chassisNo: e.target.value})} required />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Engine No</label>
                    <input value={form.engineNo} onChange={e => setForm({...form, engineNo: e.target.value})} />
                  </div>
                </>
              )}
              <div className="form-group">
                <label className="form-label">Color</label>
                <input value={form.color} onChange={e => setForm({...form, color: e.target.value})} />
              </div>
              <div className="form-group">
                <label className="form-label">Fuel Type</label>
                <select value={form.fuelType} onChange={e => setForm({...form, fuelType: e.target.value})}>
                  {['PETROL','DIESEL','ELECTRIC','CNG'].map(f => <option key={f}>{f}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Odometer (km)</label>
                <input type="number" value={form.odometer} onChange={e => setForm({...form, odometer: e.target.value})} />
              </div>
            </div>
            <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
              <button className="btn btn-primary" type="submit" disabled={saving}>{saving ? 'Saving…' : editing ? 'Update Bike' : 'Add Bike'}</button>
              <button className="btn" type="button" onClick={() => setShowForm(false)}>Cancel</button>
            </div>
          </form>
        </div>
      )}

      {loading ? <div style={{ color: 'var(--text-muted)' }}>Loading…</div> : bikes.length === 0
        ? <div className="card" style={{ textAlign: 'center', padding: 40, color: 'var(--text-muted)' }}>No bikes registered yet. Click "Add Bike" to get started.</div>
        : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 16 }}>
            {bikes.map(b => (
              <div key={b.id} className="card" style={{ position: 'relative' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div>
                    <div style={{ fontSize: 16, fontWeight: 700 }}>{b.make} {b.model}</div>
                    <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>{b.regNo || '—'} · {b.year || '—'}</div>
                  </div>
                  <div style={{ display: 'flex', gap: 6 }}>
                    <button className="btn btn-ghost" style={{ padding: '4px 8px', fontSize: 12 }} onClick={() => openEdit(b)}>Edit</button>
                    <button className="btn btn-ghost" style={{ padding: '4px 8px', fontSize: 12, color: 'var(--error)' }} onClick={() => handleDelete(b.id)}>✕</button>
                  </div>
                </div>
                <div style={{ marginTop: 12, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
                  {[['Chassis', b.chassisNo], ['Engine', b.engineNo], ['Color', b.color], ['Fuel', b.fuelType], ['Odometer', b.odometer ? `${b.odometer} km` : '—']].map(([k,v]) => (
                    <div key={k}>
                      <div style={{ fontSize: 10, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: 0.5 }}>{k}</div>
                      <div style={{ fontSize: 12, fontWeight: 600 }}>{v || '—'}</div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )
      }
    </div>
  );
}

// ─── Book Appointment ─────────────────────────────────────────────────────────
function MyAppointments() {
  const [appointments, setAppointments] = useState([]);
  const [bikes, setBikes] = useState([]);
  const [branches, setBranches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ vehicleId:'', branchId:'', slotTime:'', serviceType:'GENERAL_SERVICE', remarks:'', pickupRequired: false, pickupAddress:'' });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const load = () => {
    setLoading(true);
    Promise.all([customerPortalAPI.getAppointments(), customerPortalAPI.getBikes(), customerPortalAPI.getBranches()])
      .then(([a, b, br]) => { setAppointments(a.data || []); setBikes(b.data || []); setBranches(br.data || []); })
      .catch(() => {})
      .finally(() => setLoading(false));
  };
  useEffect(load, []);

  const handleBook = async (e) => {
    e.preventDefault();
    setSaving(true); setError('');
    try {
      await customerPortalAPI.bookAppointment(form);
      setShowForm(false); load();
    } catch (err) {
      setError(err?.message || 'Failed to book appointment');
    } finally { setSaving(false); }
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <h2 style={{ fontSize: 20, fontWeight: 800, margin: 0 }}>📅 My Appointments</h2>
        <button className="btn btn-primary" onClick={() => { setShowForm(true); setError(''); }}>+ Book Appointment</button>
      </div>

      {showForm && (
        <div className="card" style={{ marginBottom: 20 }}>
          <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 16 }}>Book New Appointment</h3>
          {error && <Alert type="error">{error}</Alert>}
          <form onSubmit={handleBook}>
            <div className="grid-2">
              <div className="form-group">
                <label className="form-label">Select Bike *</label>
                <select value={form.vehicleId} onChange={e => setForm({...form, vehicleId: e.target.value})} required>
                  <option value="">— Select Bike —</option>
                  {bikes.map(b => <option key={b.id} value={b.id}>{b.make} {b.model} ({b.regNo || b.chassisNo})</option>)}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Branch *</label>
                <select value={form.branchId} onChange={e => setForm({...form, branchId: e.target.value})} required>
                  <option value="">— Select Branch —</option>
                  {branches.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Service Type *</label>
                <select value={form.serviceType} onChange={e => setForm({...form, serviceType: e.target.value})}>
                  {['GENERAL_SERVICE','ACCIDENT_REPAIR','RUNNING_REPAIR','FREE_SERVICE','PAID_SERVICE','WARRANTY'].map(t => (
                    <option key={t} value={t}>{t.replace(/_/g,' ')}</option>
                  ))}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Preferred Slot *</label>
                <input type="datetime-local" value={form.slotTime} onChange={e => setForm({...form, slotTime: e.target.value})} required />
              </div>
              <div className="form-group" style={{ gridColumn: '1/-1' }}>
                <label className="form-label">Remarks</label>
                <input value={form.remarks} onChange={e => setForm({...form, remarks: e.target.value})} placeholder="Describe the issue or request…" />
              </div>
              <div className="form-group">
                <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer' }}>
                  <input type="checkbox" checked={form.pickupRequired} onChange={e => setForm({...form, pickupRequired: e.target.checked})} />
                  <span className="form-label" style={{ margin: 0 }}>Pickup Required</span>
                </label>
              </div>
              {form.pickupRequired && (
                <div className="form-group">
                  <label className="form-label">Pickup Address</label>
                  <input value={form.pickupAddress} onChange={e => setForm({...form, pickupAddress: e.target.value})} placeholder="Enter pickup address" />
                </div>
              )}
            </div>
            <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
              <button className="btn btn-primary" type="submit" disabled={saving}>{saving ? 'Booking…' : 'Book Appointment'}</button>
              <button className="btn" type="button" onClick={() => setShowForm(false)}>Cancel</button>
            </div>
          </form>
        </div>
      )}

      {loading ? <div style={{ color: 'var(--text-muted)' }}>Loading…</div> : appointments.length === 0
        ? <div className="card" style={{ textAlign: 'center', padding: 40, color: 'var(--text-muted)' }}>No appointments yet.</div>
        : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {appointments.map(a => (
              <div key={a.id} className="card">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 14 }}>{a.serviceType?.replace(/_/g,' ')}</div>
                    <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 4 }}>
                      {a.slotTime ? new Date(a.slotTime).toLocaleString() : '—'}
                      {a.branch && ` · ${a.branch.name}`}
                    </div>
                    {a.remarks && <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginTop: 4 }}>"{a.remarks}"</div>}
                    {a.pickupRequired && <div style={{ fontSize: 11, color: 'var(--accent)', marginTop: 4 }}>🚚 Pickup: {a.pickupAddress}</div>}
                  </div>
                  <StatusBadge status={a.status} />
                </div>
              </div>
            ))}
          </div>
        )
      }
    </div>
  );
}

// ─── Service History ──────────────────────────────────────────────────────────
function ServiceHistory() {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(null);
  const [feedbacks, setFeedbacks] = useState([]);
  const [showFeedback, setShowFeedback] = useState(false);
  const [fbForm, setFbForm] = useState({ jobCardId:'', rating: 5, comments:'', serviceQuality:'', staffBehavior:'', overallExperience:'' });
  const [fbSaving, setFbSaving] = useState(false);
  const [fbError, setFbError] = useState('');
  const [fbSuccess, setFbSuccess] = useState('');
  const [showMod, setShowMod] = useState(false);
  const [modForm, setModForm] = useState({ jobCardId:'', requestDetails:'', additionalNotes:'' });
  const [modSaving, setModSaving] = useState(false);
  const [modError, setModError] = useState('');
  const [modSuccess, setModSuccess] = useState('');

  useEffect(() => {
    Promise.all([customerPortalAPI.getServiceHistory(), customerPortalAPI.getMyFeedback()])
      .then(([h, f]) => { setHistory(h.data || []); setFeedbacks(f.data || []); })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const hasFeedback = (jobCardId) => feedbacks.some(f => f.jobCard?.id === jobCardId);

  const openFeedback = (jc) => { setFbForm({ jobCardId: jc.id, rating: 5, comments:'', serviceQuality:'', staffBehavior:'', overallExperience:'' }); setShowFeedback(true); setShowMod(false); setFbError(''); setFbSuccess(''); };
  const openMod = (jc) => { setModForm({ jobCardId: jc.id, requestDetails:'', additionalNotes:'' }); setShowMod(true); setShowFeedback(false); setModError(''); setModSuccess(''); };

  const submitFeedback = async (e) => {
    e.preventDefault(); setFbSaving(true); setFbError('');
    try {
      await customerPortalAPI.submitFeedback(fbForm);
      setFbSuccess('Thank you for your feedback!');
      const f = await customerPortalAPI.getMyFeedback(); setFeedbacks(f.data || []);
    } catch (err) { setFbError(err?.message || 'Failed to submit feedback'); }
    finally { setFbSaving(false); }
  };

  const submitMod = async (e) => {
    e.preventDefault(); setModSaving(true); setModError('');
    try {
      await customerPortalAPI.submitModificationRequest(modForm);
      setModSuccess('Modification request submitted! Our team will review it.');
    } catch (err) { setModError(err?.message || 'Failed to submit'); }
    finally { setModSaving(false); }
  };

  return (
    <div>
      <h2 style={{ fontSize: 20, fontWeight: 800, marginBottom: 20 }}>🔩 Service History</h2>
      {loading ? <div style={{ color: 'var(--text-muted)' }}>Loading…</div> : history.length === 0
        ? <div className="card" style={{ textAlign:'center', padding:40, color:'var(--text-muted)' }}>No service history yet.</div>
        : (
          <div style={{ display: 'flex', gap: 20 }}>
            <div style={{ flex: 1 }}>
              {history.map(jc => (
                <div key={jc.id} className="card" style={{ marginBottom: 12, cursor: 'pointer', border: selected?.id === jc.id ? '1px solid var(--accent)' : undefined }}
                  onClick={() => setSelected(jc)}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div>
                      <div style={{ fontWeight: 700, fontSize: 14 }}>#{jc.jobCardNo}</div>
                      <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>
                        {jc.vehicle?.make} {jc.vehicle?.model}
                        {jc.checkInTime && ` · ${new Date(jc.checkInTime).toLocaleDateString()}`}
                      </div>
                    </div>
                    <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                      <StatusBadge status={jc.status} />
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {selected && (
              <div style={{ width: 360 }}>
                <div className="card">
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
                    <h3 style={{ fontSize: 15, fontWeight: 700, margin: 0 }}>#{selected.jobCardNo}</h3>
                    <StatusBadge status={selected.status} />
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 16 }}>
                    {[['Vehicle', `${selected.vehicle?.make} ${selected.vehicle?.model}`],
                      ['Reg No', selected.vehicle?.regNo],
                      ['Check-In', selected.checkInTime ? new Date(selected.checkInTime).toLocaleDateString() : '—'],
                      ['Check-Out', selected.checkOutTime ? new Date(selected.checkOutTime).toLocaleDateString() : '—'],
                      ['Service Type', selected.serviceType?.replace(/_/g,' ')],
                      ['Branch', selected.branch?.name]].map(([k,v]) => (
                      <div key={k}>
                        <div style={{ fontSize: 10, color: 'var(--text-muted)', textTransform: 'uppercase' }}>{k}</div>
                        <div style={{ fontSize: 13, fontWeight: 600 }}>{v || '—'}</div>
                      </div>
                    ))}
                  </div>
                  {selected.customerComplaints && (
                    <div style={{ marginBottom: 12 }}>
                      <div style={{ fontSize: 10, color: 'var(--text-muted)', textTransform: 'uppercase', marginBottom: 4 }}>Complaints</div>
                      <div style={{ fontSize: 12, background: 'var(--bg-elevated)', padding: 8, borderRadius: 6 }}>{selected.customerComplaints}</div>
                    </div>
                  )}
                  <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                    {!hasFeedback(selected.id) && selected.status === 'DELIVERED' && (
                      <button className="btn btn-primary" style={{ fontSize: 12 }} onClick={() => openFeedback(selected)}>⭐ Give Feedback</button>
                    )}
                    {selected.status !== 'DELIVERED' && selected.status !== 'CLOSED' && (
                      <button className="btn" style={{ fontSize: 12 }} onClick={() => openMod(selected)}>✏️ Request Modification</button>
                    )}
                    {hasFeedback(selected.id) && (
                      <span style={{ fontSize: 11, color: 'var(--success)', padding: '6px 0' }}>✓ Feedback submitted</span>
                    )}
                  </div>
                </div>

                {showFeedback && fbForm.jobCardId === selected.id && (
                  <div className="card" style={{ marginTop: 12 }}>
                    <h4 style={{ fontSize: 14, fontWeight: 700, marginBottom: 12 }}>⭐ Rate Your Experience</h4>
                    {fbError && <Alert type="error">{fbError}</Alert>}
                    {fbSuccess ? <Alert type="success">{fbSuccess}</Alert> : (
                      <form onSubmit={submitFeedback}>
                        <div className="form-group">
                          <label className="form-label">Overall Rating *</label>
                          <StarRating value={fbForm.rating} onChange={v => setFbForm({...fbForm, rating: v})} />
                        </div>
                        {[['Service Quality', 'serviceQuality'], ['Staff Behaviour', 'staffBehavior'], ['Overall Experience', 'overallExperience']].map(([lbl, key]) => (
                          <div className="form-group" key={key}>
                            <label className="form-label">{lbl}</label>
                            <input value={fbForm[key]} onChange={e => setFbForm({...fbForm, [key]: e.target.value})} placeholder="Your experience…" />
                          </div>
                        ))}
                        <div className="form-group">
                          <label className="form-label">Comments</label>
                          <textarea value={fbForm.comments} onChange={e => setFbForm({...fbForm, comments: e.target.value})} rows={3} placeholder="Any additional comments?" style={{ width: '100%', background: 'var(--bg-elevated)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', padding: 8, color: 'var(--text-primary)', fontFamily: 'var(--font-display)', fontSize: 13, resize: 'vertical' }} />
                        </div>
                        <div style={{ display: 'flex', gap: 8 }}>
                          <button className="btn btn-primary" style={{ fontSize: 12 }} type="submit" disabled={fbSaving}>{fbSaving ? 'Submitting…' : 'Submit Feedback'}</button>
                          <button className="btn" style={{ fontSize: 12 }} type="button" onClick={() => setShowFeedback(false)}>Cancel</button>
                        </div>
                      </form>
                    )}
                  </div>
                )}

                {showMod && modForm.jobCardId === selected.id && (
                  <div className="card" style={{ marginTop: 12 }}>
                    <h4 style={{ fontSize: 14, fontWeight: 700, marginBottom: 12 }}>✏️ Request Modification</h4>
                    {modError && <Alert type="error">{modError}</Alert>}
                    {modSuccess ? <Alert type="success">{modSuccess}</Alert> : (
                      <form onSubmit={submitMod}>
                        <div className="form-group">
                          <label className="form-label">Request Details *</label>
                          <textarea value={modForm.requestDetails} onChange={e => setModForm({...modForm, requestDetails: e.target.value})} rows={3} required placeholder="Describe what modification you need…" style={{ width: '100%', background: 'var(--bg-elevated)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', padding: 8, color: 'var(--text-primary)', fontFamily: 'var(--font-display)', fontSize: 13, resize: 'vertical' }} />
                        </div>
                        <div className="form-group">
                          <label className="form-label">Additional Notes</label>
                          <input value={modForm.additionalNotes} onChange={e => setModForm({...modForm, additionalNotes: e.target.value})} placeholder="Any extra info…" />
                        </div>
                        <div style={{ display: 'flex', gap: 8 }}>
                          <button className="btn btn-primary" style={{ fontSize: 12 }} type="submit" disabled={modSaving}>{modSaving ? 'Submitting…' : 'Submit Request'}</button>
                          <button className="btn" style={{ fontSize: 12 }} type="button" onClick={() => setShowMod(false)}>Cancel</button>
                        </div>
                      </form>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        )
      }
    </div>
  );
}

// ─── Invoices & Billing ───────────────────────────────────────────────────────
function MyInvoices() {
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(null);
  const [payments, setPayments] = useState([]);

  useEffect(() => {
    customerPortalAPI.getInvoices().then(r => setInvoices(r.data || [])).catch(() => {}).finally(() => setLoading(false));
  }, []);

  const selectInvoice = async (inv) => {
    setSelected(inv);
    try { const r = await customerPortalAPI.getInvoicePayments(inv.id); setPayments(r.data || []); } catch { setPayments([]); }
  };

  return (
    <div>
      <h2 style={{ fontSize: 20, fontWeight: 800, marginBottom: 20 }}>💳 My Invoices</h2>
      {loading ? <div style={{ color: 'var(--text-muted)' }}>Loading…</div> : invoices.length === 0
        ? <div className="card" style={{ textAlign: 'center', padding: 40, color: 'var(--text-muted)' }}>No invoices yet.</div>
        : (
          <div style={{ display: 'flex', gap: 20 }}>
            <div style={{ flex: 1 }}>
              {invoices.map(inv => (
                <div key={inv.id} className="card" style={{ marginBottom: 12, cursor: 'pointer', border: selected?.id === inv.id ? '1px solid var(--accent)' : undefined }}
                  onClick={() => selectInvoice(inv)}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div>
                      <div style={{ fontWeight: 700, fontSize: 14 }}>#{inv.invoiceNo || inv.id}</div>
                      <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>
                        {inv.createdAt ? new Date(inv.createdAt).toLocaleDateString() : '—'}
                      </div>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <div style={{ fontWeight: 700, fontSize: 15 }}>₹{inv.grandTotal?.toLocaleString() || '0'}</div>
                      <StatusBadge status={inv.paymentStatus || (inv.paidAmount >= inv.grandTotal ? 'PAID' : 'PENDING')} />
                    </div>
                  </div>
                </div>
              ))}
            </div>
            {selected && (
              <div style={{ width: 340 }} className="card">
                <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 16 }}>Invoice #{selected.invoiceNo || selected.id}</h3>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 16 }}>
                  {[['Labour', `₹${selected.labourCharge?.toLocaleString() || 0}`],
                    ['Parts', `₹${selected.partsTotal?.toLocaleString() || 0}`],
                    ['Tax', `₹${selected.tax?.toLocaleString() || 0}`],
                    ['Discount', `₹${selected.discount?.toLocaleString() || 0}`],
                    ['Grand Total', `₹${selected.grandTotal?.toLocaleString() || 0}`],
                    ['Paid', `₹${selected.paidAmount?.toLocaleString() || 0}`],
                    ['Balance', `₹${((selected.grandTotal || 0) - (selected.paidAmount || 0)).toLocaleString()}`]
                  ].map(([k,v]) => (
                    <div key={k}>
                      <div style={{ fontSize: 10, color: 'var(--text-muted)', textTransform: 'uppercase' }}>{k}</div>
                      <div style={{ fontSize: 13, fontWeight: 600 }}>{v}</div>
                    </div>
                  ))}
                </div>
                {payments.length > 0 && (
                  <div>
                    <div style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase', marginBottom: 8 }}>Payment History</div>
                    {payments.map(p => (
                      <div key={p.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: '1px solid var(--border)', fontSize: 13 }}>
                        <span>{p.paymentMode} · {new Date(p.createdAt).toLocaleDateString()}</span>
                        <span style={{ fontWeight: 600 }}>₹{p.amount?.toLocaleString()}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )
      }
    </div>
  );
}

// ─── Track Status ─────────────────────────────────────────────────────────────
function TrackStatus() {
  const [statuses, setStatuses] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    customerPortalAPI.trackStatus().then(r => setStatuses(r.data || [])).catch(() => {}).finally(() => setLoading(false));
  }, []);

  const STEPS = ['CREATED','IN_PROGRESS','QC_PENDING','READY_FOR_DELIVERY','DELIVERED'];

  return (
    <div>
      <h2 style={{ fontSize: 20, fontWeight: 800, marginBottom: 20 }}>📍 Track Service Status</h2>
      {loading ? <div style={{ color: 'var(--text-muted)' }}>Loading…</div> : statuses.length === 0
        ? <div className="card" style={{ textAlign: 'center', padding: 40, color: 'var(--text-muted)' }}>No active service jobs found.</div>
        : statuses.map(s => {
          const idx = STEPS.indexOf(s.status);
          return (
            <div key={s.jobCardId} className="card" style={{ marginBottom: 16 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 15 }}>{s.vehicleMake} {s.vehicleModel}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>Job Card #{s.jobCardNo}</div>
                </div>
                <StatusBadge status={s.status} />
              </div>
              <div style={{ position: 'relative', display: 'flex', justifyContent: 'space-between', padding: '0 8px' }}>
                <div style={{ position: 'absolute', top: 10, left: 8, right: 8, height: 3, background: 'var(--border)' }} />
                <div style={{ position: 'absolute', top: 10, left: 8, height: 3, background: 'var(--accent)', width: `${Math.max(0, (idx / (STEPS.length - 1)) * 100)}%`, transition: 'width 0.5s' }} />
                {STEPS.map((step, i) => (
                  <div key={step} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, position: 'relative', zIndex: 1 }}>
                    <div style={{ width: 22, height: 22, borderRadius: '50%', background: i <= idx ? 'var(--accent)' : 'var(--bg-elevated)', border: `2px solid ${i <= idx ? 'var(--accent)' : 'var(--border)'}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, color: i <= idx ? '#fff' : 'var(--text-muted)' }}>
                      {i < idx ? '✓' : i === idx ? '●' : '○'}
                    </div>
                    <div style={{ fontSize: 9, textAlign: 'center', color: i <= idx ? 'var(--text-primary)' : 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: 0.3, maxWidth: 60 }}>
                      {step.replace(/_/g,' ')}
                    </div>
                  </div>
                ))}
              </div>
              {s.checkInTime && (
                <div style={{ marginTop: 16, fontSize: 11, color: 'var(--text-muted)' }}>
                  Check-in: {new Date(s.checkInTime).toLocaleString()}
                </div>
              )}
            </div>
          );
        })
      }
    </div>
  );
}

// ─── Profile ──────────────────────────────────────────────────────────────────
function MyProfile() {
  const { user } = useAuth();
  const [form, setForm] = useState({ name:'', phone:'', address:'', city:'' });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    customerPortalAPI.getProfile().then(r => {
      const d = r.data;
      setForm({ name: d.name||'', phone: d.phone||'', address: d.address||'', city: d.city||'' });
    }).catch(() => {}).finally(() => setLoading(false));
  }, []);

  const handleSave = async (e) => {
    e.preventDefault(); setSaving(true); setError(''); setSuccess('');
    try {
      await customerPortalAPI.updateProfile(form);
      setSuccess('Profile updated successfully!');
    } catch (err) {
      setError(err?.message || 'Failed to update profile');
    } finally { setSaving(false); }
  };

  return (
    <div style={{ maxWidth: 520 }}>
      <h2 style={{ fontSize: 20, fontWeight: 800, marginBottom: 20 }}>👤 My Profile</h2>
      <div className="card">
        <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 24 }}>
          <div style={{ width: 52, height: 52, borderRadius: '50%', background: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, fontWeight: 800, color: '#fff' }}>
            {user?.name?.charAt(0)?.toUpperCase()}
          </div>
          <div>
            <div style={{ fontWeight: 700, fontSize: 16 }}>{user?.name}</div>
            <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{user?.email}</div>
            <div style={{ fontSize: 11, color: 'var(--accent)', marginTop: 2 }}>Customer Account</div>
          </div>
        </div>
        {success && <Alert type="success">{success}</Alert>}
        {error && <Alert type="error">{error}</Alert>}
        {loading ? <div style={{ color: 'var(--text-muted)' }}>Loading…</div> : (
          <form onSubmit={handleSave}>
            {[['Full Name', 'name', 'text'], ['Phone', 'phone', 'tel'], ['Address', 'address', 'text'], ['City', 'city', 'text']].map(([lbl, key, type]) => (
              <div className="form-group" key={key}>
                <label className="form-label">{lbl}</label>
                <input type={type} value={form[key]} onChange={e => setForm({...form, [key]: e.target.value})} placeholder={lbl} />
              </div>
            ))}
            <button className="btn btn-primary" type="submit" disabled={saving}>{saving ? 'Saving…' : 'Save Changes'}</button>
          </form>
        )}
      </div>
    </div>
  );
}

// ─── Modification Requests ────────────────────────────────────────────────────
function MyModificationRequests() {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    customerPortalAPI.getModificationRequests().then(r => setRequests(r.data || [])).catch(() => {}).finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <h2 style={{ fontSize: 20, fontWeight: 800, marginBottom: 20 }}>✏️ Modification Requests</h2>
      {loading ? <div style={{ color: 'var(--text-muted)' }}>Loading…</div> : requests.length === 0
        ? <div className="card" style={{ textAlign: 'center', padding: 40, color: 'var(--text-muted)' }}>No modification requests. Submit one from Service History.</div>
        : requests.map(r => (
          <div key={r.id} className="card" style={{ marginBottom: 12 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 4 }}>Job Card #{r.jobCard?.jobCardNo}</div>
                <div style={{ fontSize: 13, marginBottom: 4 }}>{r.requestDetails}</div>
                {r.additionalNotes && <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>Note: {r.additionalNotes}</div>}
                {r.adminRemarks && <div style={{ fontSize: 12, color: 'var(--accent)', marginTop: 4 }}>Admin: {r.adminRemarks}</div>}
              </div>
              <StatusBadge status={r.status} />
            </div>
          </div>
        ))
      }
    </div>
  );
}

// ─── Customer Portal Layout ───────────────────────────────────────────────────
const PORTAL_NAV = [
  { key: 'home', label: 'Home', icon: '⌂' },
  { key: 'bikes', label: 'My Bikes', icon: '🏍️' },
  { key: 'appointments', label: 'Appointments', icon: '📅' },
  { key: 'status', label: 'Track Status', icon: '📍' },
  { key: 'history', label: 'Service History', icon: '🔩' },
  { key: 'invoices', label: 'Invoices', icon: '💳' },
  { key: 'modifications', label: 'Requests', icon: '✏️' },
  { key: 'profile', label: 'My Profile', icon: '👤' },
];

export default function CustomerPortal() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [tab, setTab] = useState('home');

  // allow deep link via ?tab=xxx
  useEffect(() => {
    const p = new URLSearchParams(location.search);
    const t = p.get('tab');
    if (t) setTab(t);
  }, [location.search]);

  const renderContent = () => {
    switch (tab) {
      case 'home': return <CustomerHome user={user} />;
      case 'bikes': return <MyBikes />;
      case 'appointments': return <MyAppointments />;
      case 'status': return <TrackStatus />;
      case 'history': return <ServiceHistory />;
      case 'invoices': return <MyInvoices />;
      case 'modifications': return <MyModificationRequests />;
      case 'profile': return <MyProfile />;
      default: return <CustomerHome user={user} />;
    }
  };

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: 'var(--bg-primary)' }}>
      {/* Sidebar */}
      <div className="sidebar">
        <div className="sidebar-logo">
          <div className="logo-mark">
            <div className="logo-icon">BS</div>
            <div>
              <div className="logo-text">BikeService</div>
              <div className="logo-sub">customer portal</div>
            </div>
          </div>
        </div>
        <div style={{ flex: 1, overflowY: 'auto', paddingBottom: 8 }}>
          {PORTAL_NAV.map(item => (
            <button key={item.key}
              className={`nav-item ${tab === item.key ? 'active' : ''}`}
              onClick={() => setTab(item.key)}>
              <span style={{ fontSize: 14 }}>{item.icon}</span>
              {item.label}
            </button>
          ))}
        </div>
        <div className="sidebar-footer">
          <div className="user-card">
            <div className="user-avatar">{user?.name?.charAt(0)?.toUpperCase()}</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="user-name" style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{user?.name}</div>
              <div className="user-role">customer</div>
            </div>
            <button className="btn-ghost btn" style={{ padding: '4px 6px', fontSize: 16 }} onClick={logout} title="Logout">⏻</button>
          </div>
        </div>
      </div>

      {/* Main */}
      <div className="main-area">
        <div style={{ padding: '24px 28px', maxWidth: 1100 }}>
          {renderContent()}
        </div>
      </div>
    </div>
  );
}
