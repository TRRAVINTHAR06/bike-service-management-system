import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { customerAPI, vehicleAPI, jobCardAPI } from '../../services/api';
import { Loading, Badge, Topbar, FormGroup, Modal, Alert } from '../../components/ui';
import { formatDate, formatDateTime, getInitials } from '../../utils/helpers';

export default function CustomerDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [customer, setCustomer] = useState(null);
  const [vehicles, setVehicles] = useState([]);
  const [jobCards, setJobCards] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('vehicles');

  useEffect(() => {
    async function load() {
      setLoading(true);
      try {
        const [cr, vr, jr] = await Promise.all([
          customerAPI.getById(id),
          vehicleAPI.getByCustomer(id),
          jobCardAPI.getByCustomer(id),
        ]);
        setCustomer(cr.data);
        setVehicles(vr.data || []);
        setJobCards(jr.data || []);
      } finally { setLoading(false); }
    }
    load();
  }, [id]);

  if (loading) return <Loading />;
  if (!customer) return <div className="page-content">Customer not found</div>;

  return (
    <>
      <Topbar
        title={customer.name}
        subtitle={`${customer.phone} · ${customer.email || 'no email'}`}
        actions={<button className="btn btn-secondary btn-sm" onClick={() => navigate('/customers')}>← Back</button>}
      />
      <div className="page-content">
        <div className="grid-2" style={{ gap: 16 }}>
          {/* Left - Profile */}
          <div>
            <div className="card" style={{ marginBottom: 16 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 20 }}>
                <div style={{
                  width: 56, height: 56, borderRadius: '50%',
                  background: 'var(--accent-dim)', border: '2px solid var(--accent-border)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 20, fontWeight: 800, color: 'var(--accent)'
                }}>{getInitials(customer.name)}</div>
                <div>
                  <div style={{ fontSize: 18, fontWeight: 800 }}>{customer.name}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>
                    Customer #{customer.id}
                  </div>
                </div>
                {customer.blacklisted && <span className="badge badge-cancelled" style={{ marginLeft: 'auto' }}>Blacklisted</span>}
              </div>
              <div className="info-grid">
                <div className="info-item">
                  <div className="info-label">Phone</div>
                  <div className="info-value mono">{customer.phone}</div>
                </div>
                <div className="info-item">
                  <div className="info-label">Email</div>
                  <div className="info-value">{customer.email || '—'}</div>
                </div>
                <div className="info-item">
                  <div className="info-label">City</div>
                  <div className="info-value">{customer.city || '—'}</div>
                </div>
                <div className="info-item">
                  <div className="info-label">Loyalty Points</div>
                  <div className="info-value" style={{ color: 'var(--accent)', fontWeight: 800 }}>
                    {customer.loyaltyPoints || 0} pts
                  </div>
                </div>
                <div className="info-item">
                  <div className="info-label">Total Vehicles</div>
                  <div className="info-value">{vehicles.length}</div>
                </div>
                <div className="info-item">
                  <div className="info-label">Total Visits</div>
                  <div className="info-value">{jobCards.length}</div>
                </div>
                <div className="info-item">
                  <div className="info-label">Registered</div>
                  <div className="info-value" style={{ fontSize: 12 }}>{formatDate(customer.createdAt)}</div>
                </div>
              </div>
              {customer.address && (
                <div style={{ marginTop: 14, padding: '10px 12px', background: 'var(--bg-elevated)', borderRadius: 'var(--radius)', fontSize: 12, color: 'var(--text-secondary)' }}>
                  <div style={{ fontSize: 10, fontFamily: 'var(--font-mono)', color: 'var(--text-muted)', marginBottom: 4 }}>ADDRESS</div>
                  {customer.address}
                </div>
              )}
            </div>
          </div>

          {/* Right - Tabs */}
          <div>
            <div className="card">
              <div className="tab-row" style={{ marginBottom: 16 }}>
                <button className={`tab ${tab === 'vehicles' ? 'active' : ''}`} onClick={() => setTab('vehicles')}>
                  Vehicles ({vehicles.length})
                </button>
                <button className={`tab ${tab === 'history' ? 'active' : ''}`} onClick={() => setTab('history')}>
                  Service History ({jobCards.length})
                </button>
              </div>

              {tab === 'vehicles' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                  {vehicles.length === 0 ? (
                    <div style={{ textAlign: 'center', padding: '30px', color: 'var(--text-muted)', fontSize: 13 }}>No vehicles registered</div>
                  ) : vehicles.map(v => (
                    <div key={v.id} style={{ background: 'var(--bg-elevated)', borderRadius: 'var(--radius)', padding: '12px 14px', border: '1px solid var(--border)' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                        <div style={{ fontWeight: 700 }}>{v.make} {v.model} {v.year}</div>
                        <span style={{ fontSize: 11, color: 'var(--accent)', fontFamily: 'var(--font-mono)' }}>{v.regNo || 'No Reg'}</span>
                      </div>
                      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 4, fontSize: 11, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>
                        <span>Chassis: {v.chassisNo}</span>
                        <span>Engine: {v.engineNo || '—'}</span>
                        <span>Color: {v.color || '—'}</span>
                        <span>Fuel: {v.fuelType || '—'}</span>
                        <span>Odometer: {v.odometer ? `${v.odometer} km` : '—'}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {tab === 'history' && (
                <div>
                  {jobCards.length === 0 ? (
                    <div style={{ textAlign: 'center', padding: '30px', color: 'var(--text-muted)', fontSize: 13 }}>No service history</div>
                  ) : jobCards.map(jc => (
                    <div key={jc.id}
                      style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 0', borderBottom: '1px solid var(--border)', cursor: 'pointer' }}
                      onClick={() => navigate(`/job-cards/${jc.id}`)}
                    >
                      <div style={{ flex: 1 }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                          <span style={{ fontSize: 12, fontFamily: 'var(--font-mono)', color: 'var(--accent)' }}>{jc.jobCardNo}</span>
                          <span className={`badge badge-${jc.status?.toLowerCase()}`} style={{ fontSize: 9 }}>{jc.status?.replace(/_/g,' ')}</span>
                        </div>
                        <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>
                          {jc.vehicle?.make} {jc.vehicle?.model} · {jc.serviceType?.replace(/_/g,' ')}
                        </div>
                      </div>
                      <div style={{ fontSize: 11, color: 'var(--text-muted)', textAlign: 'right' }}>
                        {formatDate(jc.createdAt)}
                      </div>
                      <span style={{ color: 'var(--text-muted)', fontSize: 14 }}>→</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
