import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { customerAPI } from '../../services/api';
import { Modal, Badge, Loading, EmptyState, FormGroup, Topbar, Alert } from '../../components/ui';
import { formatDate, getInitials } from '../../utils/helpers';

function CustomerForm({ initial, onSave, onClose }) {
  const [form, setForm] = useState(initial || { name:'', phone:'', email:'', address:'', city:'', branchId: 1 });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const f = k => e => setForm(p => ({ ...p, [k]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault(); setLoading(true); setError('');
    try {
      if (initial?.id) await customerAPI.update(initial.id, form);
      else await customerAPI.create(form);
      onSave();
    } catch (err) { setError(err?.message || 'Failed to save'); }
    finally { setLoading(false); }
  };

  return (
    <form onSubmit={submit}>
      {error && <Alert type="error">{error}</Alert>}
      <div className="form-row">
        <FormGroup label="Full Name *"><input value={form.name} onChange={f('name')} required /></FormGroup>
        <FormGroup label="Phone *"><input value={form.phone} onChange={f('phone')} required /></FormGroup>
      </div>
      <div className="form-row">
        <FormGroup label="Email"><input type="email" value={form.email} onChange={f('email')} /></FormGroup>
        <FormGroup label="City"><input value={form.city} onChange={f('city')} /></FormGroup>
      </div>
      <FormGroup label="Address"><textarea rows={2} value={form.address} onChange={f('address')} /></FormGroup>
      <div className="modal-footer">
        <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
        <button type="submit" className="btn btn-primary" disabled={loading}>{loading ? 'Saving...' : 'Save Customer'}</button>
      </div>
    </form>
  );
}

export default function CustomersPage() {
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState(null);
  const navigate = useNavigate();

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = search.length > 2
        ? await customerAPI.search(search)
        : await customerAPI.getAll();
      setCustomers(res.data || []);
    } finally { setLoading(false); }
  }, [search]);

  useEffect(() => { const t = setTimeout(load, 300); return () => clearTimeout(t); }, [load]);

  const handleSave = () => { setShowModal(false); setEditing(null); load(); };

  return (
    <>
      <Topbar title="Customers" subtitle={`${customers.length} registered`}
        actions={
          <button className="btn btn-primary" onClick={() => { setEditing(null); setShowModal(true); }}>
            + New Customer
          </button>
        }
      />
      <div className="page-content">
        <div className="card">
          <div className="card-header">
            <div className="search-bar">
              <span style={{ color: 'var(--text-muted)', fontSize: 14 }}>⌕</span>
              <input placeholder="Search by name, phone, email..." value={search}
                onChange={e => setSearch(e.target.value)} />
            </div>
          </div>

          {loading ? <Loading /> : (
            <div className="table-wrap">
              <table>
                <thead><tr>
                  <th>Customer</th><th>Phone</th><th>Email</th><th>City</th>
                  <th>Loyalty Pts</th><th>Registered</th><th>Actions</th>
                </tr></thead>
                <tbody>
                  {customers.length === 0 ? (
                    <tr><td colSpan={7}><EmptyState message="No customers found" /></td></tr>
                  ) : customers.map(c => (
                    <tr key={c.id}>
                      <td>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                          <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'var(--accent-dim)', border: '1px solid var(--accent-border)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700, color: 'var(--accent)', flexShrink: 0 }}>
                            {getInitials(c.name)}
                          </div>
                          <div>
                            <div style={{ fontWeight: 600 }}>{c.name}</div>
                            {c.blacklisted && <span className="badge badge-cancelled">Blacklisted</span>}
                          </div>
                        </div>
                      </td>
                      <td className="mono" style={{ fontSize: 12 }}>{c.phone}</td>
                      <td style={{ color: 'var(--text-muted)', fontSize: 12 }}>{c.email || '—'}</td>
                      <td>{c.city || '—'}</td>
                      <td><span className="mono" style={{ color: 'var(--accent)' }}>{c.loyaltyPoints || 0}</span></td>
                      <td style={{ fontSize: 12, color: 'var(--text-muted)' }}>{formatDate(c.createdAt)}</td>
                      <td>
                        <div className="action-menu">
                          <button className="btn btn-ghost btn-sm" onClick={() => navigate(`/customers/${c.id}`)}>View</button>
                          <button className="btn btn-ghost btn-sm" onClick={() => { setEditing(c); setShowModal(true); }}>Edit</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {showModal && (
        <Modal title={editing ? 'Edit Customer' : 'New Customer'} onClose={() => { setShowModal(false); setEditing(null); }}>
          <CustomerForm initial={editing} onSave={handleSave} onClose={() => { setShowModal(false); setEditing(null); }} />
        </Modal>
      )}
    </>
  );
}
