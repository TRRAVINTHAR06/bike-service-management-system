import React, { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { dashboardAPI, jobCardAPI, invoiceAPI } from '../../services/api';
import { StatCard, Loading, Topbar } from '../../components/ui';
import { formatCurrency, formatDate } from '../../utils/helpers';
import { useNavigate } from 'react-router-dom';

const STATUS_COLORS = {
  CREATED: '#3b82f6', IN_PROGRESS: '#f97316', QC_PENDING: '#a855f7',
  READY_FOR_DELIVERY: '#22c55e', DELIVERED: '#6b7280', CANCELLED: '#ef4444'
};

export default function DashboardPage() {
  const [summary, setSummary] = useState(null);
  const [recentJobs, setRecentJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const branchId = 1;

  useEffect(() => {
    async function load() {
      try {
        const [sumRes, jobsRes] = await Promise.all([
          dashboardAPI.getSummary(branchId),
          jobCardAPI.getByBranch(branchId),
        ]);
        setSummary(sumRes.data);
        setRecentJobs((jobsRes.data || []).slice(0, 8));
      } catch (e) { console.error(e); }
      finally { setLoading(false); }
    }
    load();
  }, []);

  const chartData = summary ? [
    { name: 'Created', value: summary.created || 0, color: STATUS_COLORS.CREATED },
    { name: 'In Progress', value: summary.inProgress || 0, color: STATUS_COLORS.IN_PROGRESS },
    { name: 'QC Pending', value: summary.qcPending || 0, color: STATUS_COLORS.QC_PENDING },
    { name: 'Ready', value: summary.readyForDelivery || 0, color: STATUS_COLORS.READY_FOR_DELIVERY },
    { name: 'Delivered', value: summary.delivered || 0, color: STATUS_COLORS.DELIVERED },
  ] : [];

  if (loading) return <Loading />;

  return (
    <>
      <Topbar title="Dashboard" subtitle={`Branch ${branchId} · ${new Date().toDateString()}`} />
      <div className="page-content">

        <div className="grid-4" style={{ marginBottom: 24 }}>
          <StatCard label="Total Job Cards" value={summary?.totalJobCards || 0} sub="All time" color="var(--accent)" />
          <StatCard label="In Progress" value={summary?.inProgress || 0} sub="Active now" color="#f97316" />
          <StatCard label="Ready for Delivery" value={summary?.readyForDelivery || 0} sub="Awaiting pickup" color="#22c55e" />
          <StatCard label="Delivered Today" value={summary?.delivered || 0} sub="Completed" color="#6b7280" />
        </div>

        <div className="grid-2" style={{ gap: 16, marginBottom: 24 }}>
          <div className="card">
            <div className="card-header">
              <span className="card-title">Job Card Status Distribution</span>
            </div>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={chartData} barSize={32}>
                <XAxis dataKey="name" tick={{ fill: '#9a9a98', fontSize: 11, fontFamily: 'JetBrains Mono' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: '#9a9a98', fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ background: '#1c1f22', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 6, fontSize: 12 }}
                  cursor={{ fill: 'rgba(255,255,255,0.03)' }}
                />
                <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                  {chartData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="card">
            <div className="card-header">
              <span className="card-title">Quick Actions</span>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              {[
                { label: 'New Job Card', path: '/job-cards', icon: '◈' },
                { label: 'New Customer', path: '/customers', icon: '◉' },
                { label: 'New Appointment', path: '/appointments', icon: '◷' },
                { label: 'Check Inventory', path: '/inventory', icon: '⬢' },
                { label: 'Parts Master', path: '/parts', icon: '⬡' },
                { label: 'Invoices', path: '/invoices', icon: '◫' },
              ].map(a => (
                <button key={a.path} className="btn btn-secondary" style={{ justifyContent: 'flex-start', gap: 8 }}
                  onClick={() => navigate(a.path)}>
                  <span>{a.icon}</span>{a.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-header">
            <span className="card-title">Recent Job Cards</span>
            <button className="btn btn-ghost btn-sm" onClick={() => navigate('/job-cards')}>View all →</button>
          </div>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Job Card No</th>
                  <th>Customer</th>
                  <th>Vehicle</th>
                  <th>Service Type</th>
                  <th>Status</th>
                  <th>Created</th>
                </tr>
              </thead>
              <tbody>
                {recentJobs.length === 0 ? (
                  <tr><td colSpan={6} style={{ textAlign: 'center', color: 'var(--text-muted)', padding: 32 }}>No job cards yet</td></tr>
                ) : recentJobs.map(jc => (
                  <tr key={jc.id} style={{ cursor: 'pointer' }} onClick={() => navigate(`/job-cards/${jc.id}`)}>
                    <td><span className="mono" style={{ color: 'var(--accent)', fontSize: 12 }}>{jc.jobCardNo}</span></td>
                    <td>{jc.customer?.name || '—'}</td>
                    <td>{jc.vehicle ? `${jc.vehicle.make} ${jc.vehicle.model}` : '—'}</td>
                    <td>{jc.serviceType?.replace(/_/g, ' ') || '—'}</td>
                    <td><span className={`badge badge-${jc.status?.toLowerCase()}`}>{jc.status?.replace(/_/g, ' ')}</span></td>
                    <td style={{ color: 'var(--text-muted)', fontSize: 12 }}>{formatDate(jc.createdAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  );
}
