import React, { useState, useEffect, useCallback } from 'react';
import { inventoryAPI, partsAPI, branchAPI } from '../../services/api';
import { Loading, EmptyState, Modal, FormGroup, Alert, Topbar, StatCard } from '../../components/ui';
import { formatCurrency } from '../../utils/helpers';

export default function InventoryPage() {
  const [inventory, setInventory] = useState([]);
  const [lowStock, setLowStock] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('all');
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ branchId: 1, partId: '', qtyAvailable: '', reorderLevel: 5 });
  const [parts, setParts] = useState([]);
  const [addQtyModal, setAddQtyModal] = useState(null);
  const [addQty, setAddQty] = useState('');
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [invRes, lowRes, partsRes] = await Promise.all([
        inventoryAPI.getByBranch(1),
        inventoryAPI.getLowStock(1),
        partsAPI.getAll(),
      ]);
      setInventory(invRes.data || []);
      setLowStock(lowRes.data || []);
      setParts(partsRes.data || []);
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const saveStock = async (e) => {
    e.preventDefault();
    try {
      await inventoryAPI.addOrUpdate({ ...form, partId: Number(form.partId), qtyAvailable: Number(form.qtyAvailable), reorderLevel: Number(form.reorderLevel) });
      setShowModal(false); load();
    } catch (err) { setError(err?.message || 'Failed'); }
  };

  const handleAddQty = async () => {
    if (!addQty) return;
    await inventoryAPI.addStock(1, addQtyModal.part.id, Number(addQty));
    setAddQtyModal(null); setAddQty(''); load();
  };

  const displayed = tab === 'low' ? lowStock : inventory;

  return (
    <>
      <Topbar title="Stock Inventory" subtitle={`Branch 1 · ${inventory.length} items`}
        actions={<button className="btn btn-primary" onClick={() => setShowModal(true)}>+ Add / Update Stock</button>}
      />
      <div className="page-content">
        <div className="grid-3" style={{ marginBottom: 20 }}>
          <StatCard label="Total Items" value={inventory.length} color="var(--accent)" />
          <StatCard label="Low Stock Alerts" value={lowStock.length} color="var(--danger)" />
          <StatCard label="Total SKUs" value={parts.length} color="var(--info)" />
        </div>

        <div className="tab-row" style={{ marginBottom: 16 }}>
          <button className={`tab ${tab === 'all' ? 'active' : ''}`} onClick={() => setTab('all')}>All Stock</button>
          <button className={`tab ${tab === 'low' ? 'active' : ''}`} onClick={() => setTab('low')}>
            Low Stock {lowStock.length > 0 && <span style={{ background: 'var(--danger)', color: '#fff', borderRadius: 10, padding: '0 5px', fontSize: 9, marginLeft: 4 }}>{lowStock.length}</span>}
          </button>
        </div>

        <div className="card">
          {loading ? <Loading /> : (
            <div className="table-wrap">
              <table>
                <thead><tr>
                  <th>Part Name</th><th>OEM Part No</th><th>Category</th>
                  <th>Qty Available</th><th>Reorder Level</th><th>Rack</th><th>Actions</th>
                </tr></thead>
                <tbody>
                  {displayed.length === 0 ? <tr><td colSpan={7}><EmptyState message="No stock records" /></td></tr>
                  : displayed.map(inv => (
                    <tr key={inv.id}>
                      <td style={{ fontWeight: 500 }}>{inv.part?.partName}</td>
                      <td className="mono" style={{ fontSize: 11, color: 'var(--text-muted)' }}>{inv.part?.oemPartNo || '—'}</td>
                      <td style={{ fontSize: 12 }}>{inv.part?.partCategory || '—'}</td>
                      <td>
                        <span style={{ fontWeight: 700, color: inv.qtyAvailable <= inv.reorderLevel ? 'var(--danger)' : 'var(--success)', fontFamily: 'var(--font-mono)' }}>
                          {inv.qtyAvailable}
                        </span>
                        {inv.qtyAvailable <= inv.reorderLevel && <span className="badge badge-cancelled" style={{ marginLeft: 6, fontSize: 9 }}>LOW</span>}
                      </td>
                      <td className="mono" style={{ fontSize: 12 }}>{inv.reorderLevel}</td>
                      <td style={{ fontSize: 12 }}>{inv.rackLocation || '—'}</td>
                      <td>
                        <button className="btn btn-ghost btn-sm" onClick={() => setAddQtyModal(inv)}>+ Add Stock</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {showModal && (
        <Modal title="Add / Update Stock" onClose={() => setShowModal(false)}>
          {error && <Alert type="error">{error}</Alert>}
          <form onSubmit={saveStock}>
            <FormGroup label="Part *">
              <select value={form.partId} onChange={e => setForm(p => ({ ...p, partId: e.target.value }))} required>
                <option value="">-- select part --</option>
                {parts.map(p => <option key={p.id} value={p.id}>{p.partName} ({p.oemPartNo || 'no OEM'})</option>)}
              </select>
            </FormGroup>
            <div className="form-row">
              <FormGroup label="Qty Available *"><input type="number" value={form.qtyAvailable} onChange={e => setForm(p => ({ ...p, qtyAvailable: e.target.value }))} required /></FormGroup>
              <FormGroup label="Reorder Level"><input type="number" value={form.reorderLevel} onChange={e => setForm(p => ({ ...p, reorderLevel: e.target.value }))} /></FormGroup>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
              <button type="submit" className="btn btn-primary">Save Stock</button>
            </div>
          </form>
        </Modal>
      )}

      {addQtyModal && (
        <Modal title={`Add Stock — ${addQtyModal.part?.partName}`} onClose={() => setAddQtyModal(null)}>
          <FormGroup label="Quantity to Add">
            <input type="number" value={addQty} onChange={e => setAddQty(e.target.value)} autoFocus />
          </FormGroup>
          <div className="modal-footer">
            <button className="btn btn-secondary" onClick={() => setAddQtyModal(null)}>Cancel</button>
            <button className="btn btn-primary" onClick={handleAddQty} disabled={!addQty}>Add Stock</button>
          </div>
        </Modal>
      )}
    </>
  );
}
