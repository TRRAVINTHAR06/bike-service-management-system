import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { jobCardAPI, estimateAPI, invoiceAPI, qcAPI, serviceCatalogAPI, partsAPI } from '../../services/api';
import { Badge, Loading, FormGroup, Alert, Topbar } from '../../components/ui';
import { formatCurrency, formatDateTime, JOB_STATUSES, PAYMENT_MODES } from '../../utils/helpers';

const FLOW = ['CREATED','INSPECTED','IN_PROGRESS','QC_PENDING','QC_PASSED','READY_FOR_DELIVERY','DELIVERED'];

export default function JobCardDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [jc, setJc] = useState(null);
  const [estimate, setEstimate] = useState(null);
  const [invoice, setInvoice] = useState(null);
  const [qc, setQc] = useState(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('overview');
  const [statusForm, setStatusForm] = useState({ status: '', remarks: '' });
  const [estimateForm, setEstimateForm] = useState({ serviceIds: [], parts: [], discount: 0, taxPercent: 18 });
  const [services, setServices] = useState([]);
  const [parts, setParts] = useState([]);
  const [paymentForm, setPaymentForm] = useState({ invoiceId: '', amount: '', mode: 'CASH' });
  const [qcForm, setQcForm] = useState({ engineCheck:false, brakeCheck:false, lightCheck:false, tiresCheck:false, cleanlinessCheck:false, roadTestDone:false, remarks:'' });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [msg, setMsg] = useState('');

  const load = async () => {
    setLoading(true);
    try {
      const res = await jobCardAPI.getById(id);
      setJc(res.data);
      setStatusForm(p => ({ ...p, status: res.data.status }));
      try { const er = await estimateAPI.getByJobCard(id); setEstimate(er.data); } catch {}
      try { const ir = await invoiceAPI.getByJobCard(id); setInvoice(ir.data); if (ir.data) setPaymentForm(p => ({ ...p, invoiceId: ir.data.id })); } catch {}
      try { const qr = await qcAPI.getByJobCard(id); setQc(qr.data); } catch {}
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [id]);
  useEffect(() => {
    serviceCatalogAPI.getAll().then(r => setServices(r.data || []));
    partsAPI.getAll().then(r => setParts(r.data || []));
  }, []);

  const flash = (m, isErr) => { if (isErr) setError(m); else setMsg(m); setTimeout(() => { setError(''); setMsg(''); }, 3000); };

  const updateStatus = async () => {
    setSaving(true);
    try { await jobCardAPI.updateStatus(id, statusForm); await load(); flash('Status updated'); }
    catch (e) { flash(e?.message || 'Failed', true); }
    finally { setSaving(false); }
  };

  const createEstimate = async () => {
    setSaving(true);
    try {
      await estimateAPI.create({ jobCardId: Number(id), ...estimateForm, serviceIds: estimateForm.serviceIds.map(Number) });
      await load(); flash('Estimate created');
    } catch (e) { flash(e?.message || 'Failed', true); }
    finally { setSaving(false); }
  };

  const approveEstimate = async () => {
    setSaving(true);
    try { await estimateAPI.approve(id, 'advisor'); await load(); flash('Estimate approved'); }
    catch (e) { flash(e?.message || 'Failed', true); }
    finally { setSaving(false); }
  };

  const generateInvoice = async () => {
    setSaving(true);
    try { await invoiceAPI.generate(id); await load(); flash('Invoice generated'); }
    catch (e) { flash(e?.message || 'Failed', true); }
    finally { setSaving(false); }
  };

  const recordPayment = async () => {
    setSaving(true);
    try {
      await invoiceAPI.recordPayment({ ...paymentForm, invoiceId: Number(paymentForm.invoiceId), amount: Number(paymentForm.amount) });
      await load(); flash('Payment recorded'); setPaymentForm(p => ({ ...p, amount: '' }));
    } catch (e) { flash(e?.message || 'Failed', true); }
    finally { setSaving(false); }
  };

  const submitQc = async () => {
    setSaving(true);
    try { await qcAPI.submit({ ...qcForm, jobCardId: Number(id) }); await load(); flash('QC submitted'); }
    catch (e) { flash(e?.message || 'Failed', true); }
    finally { setSaving(false); }
  };

  if (loading) return <Loading />;
  if (!jc) return <div className="page-content">Job card not found</div>;

  const currentStep = FLOW.indexOf(jc.status);
  const nextStatuses = JOB_STATUSES.filter(s => s !== jc.status && s !== 'CANCELLED');

  return (
    <>
      <Topbar
        title={jc.jobCardNo}
        subtitle={`${jc.serviceType?.replace(/_/g,' ')} · ${jc.customer?.name}`}
        actions={<button className="btn btn-secondary btn-sm" onClick={() => navigate('/job-cards')}>← Back</button>}
      />
      <div className="page-content">
        {error && <Alert type="error">{error}</Alert>}
        {msg && <Alert type="success">{msg}</Alert>}

        {/* Status Flow */}
        <div className="card" style={{ marginBottom: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4, flexWrap: 'wrap' }}>
            {FLOW.map((s, i) => (
              <div key={s} style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3 }}>
                  <div style={{ width: 10, height: 10, borderRadius: '50%', background: i < currentStep ? 'var(--success)' : i === currentStep ? 'var(--accent)' : 'var(--border-strong)' }} />
                  <span style={{ fontSize: 9, fontFamily: 'var(--font-mono)', color: i === currentStep ? 'var(--accent)' : 'var(--text-muted)', whiteSpace: 'nowrap' }}>{s.replace(/_/g,' ')}</span>
                </div>
                {i < FLOW.length - 1 && <div style={{ width: 24, height: 1, background: i < currentStep ? 'var(--success)' : 'var(--border)', marginBottom: 14 }} />}
              </div>
            ))}
          </div>
        </div>

        <div className="grid-2" style={{ gap: 16 }}>
          {/* Left column */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

            {/* Overview card */}
            <div className="card">
              <div className="tab-row">
                {['overview','estimate','invoice','qc'].map(t => (
                  <button key={t} className={`tab ${tab === t ? 'active' : ''}`} onClick={() => setTab(t)}>{t}</button>
                ))}
              </div>

              {tab === 'overview' && (
                <div>
                  <div className="info-grid" style={{ marginBottom: 16 }}>
                    <div className="info-item"><div className="info-label">Status</div><div className="info-value"><span className={`badge badge-${jc.status?.toLowerCase()}`}>{jc.status?.replace(/_/g,' ')}</span></div></div>
                    <div className="info-item"><div className="info-label">Service Type</div><div className="info-value">{jc.serviceType?.replace(/_/g,' ')}</div></div>
                    <div className="info-item"><div className="info-label">Odometer In</div><div className="info-value mono">{jc.odometerIn ? `${jc.odometerIn} km` : '—'}</div></div>
                    <div className="info-item"><div className="info-label">Odometer Out</div><div className="info-value mono">{jc.odometerOut ? `${jc.odometerOut} km` : '—'}</div></div>
                    <div className="info-item"><div className="info-label">Check In</div><div className="info-value" style={{ fontSize: 12 }}>{formatDateTime(jc.checkInTime)}</div></div>
                    <div className="info-item"><div className="info-label">Delivered</div><div className="info-value" style={{ fontSize: 12 }}>{formatDateTime(jc.deliveryTime)}</div></div>
                    <div className="info-item"><div className="info-label">Insurance Claim</div><div className="info-value">{jc.insuranceClaim ? jc.insuranceClaimNo || 'Yes' : 'No'}</div></div>
                    <div className="info-item"><div className="info-label">Advisor</div><div className="info-value">{jc.advisor?.name || '—'}</div></div>
                  </div>
                  {jc.customerInstructions && (
                    <div style={{ background: 'var(--bg-elevated)', borderRadius: 'var(--radius)', padding: 12, fontSize: 13, color: 'var(--text-secondary)' }}>
                      <div style={{ fontSize: 10, fontFamily: 'var(--font-mono)', color: 'var(--text-muted)', marginBottom: 4 }}>CUSTOMER INSTRUCTIONS</div>
                      {jc.customerInstructions}
                    </div>
                  )}
                </div>
              )}

              {tab === 'estimate' && (
                <div>
                  {estimate ? (
                    <div>
                      <div className="info-grid" style={{ marginBottom: 12 }}>
                        <div className="info-item"><div className="info-label">Parts Total</div><div className="info-value">{formatCurrency(estimate.partsTotal)}</div></div>
                        <div className="info-item"><div className="info-label">Labour Total</div><div className="info-value">{formatCurrency(estimate.laborTotal)}</div></div>
                        <div className="info-item"><div className="info-label">Discount</div><div className="info-value">{formatCurrency(estimate.discount)}</div></div>
                        <div className="info-item"><div className="info-label">Tax</div><div className="info-value">{formatCurrency(estimate.taxAmount)}</div></div>
                        <div className="info-item"><div className="info-label">Grand Total</div><div className="info-value" style={{ color: 'var(--accent)', fontSize: 18 }}>{formatCurrency(estimate.grandTotal)}</div></div>
                        <div className="info-item"><div className="info-label">Approval</div><div className="info-value"><span className={`badge badge-${estimate.approvalStatus?.toLowerCase()}`}>{estimate.approvalStatus}</span></div></div>
                      </div>
                      {estimate.approvalStatus === 'PENDING' && (
                        <div style={{ display: 'flex', gap: 8 }}>
                          <button className="btn btn-primary btn-sm" onClick={approveEstimate} disabled={saving}>Approve</button>
                          <button className="btn btn-danger btn-sm">Reject</button>
                        </div>
                      )}
                      {estimate.approvalStatus === 'APPROVED' && !invoice && (
                        <button className="btn btn-primary btn-sm" onClick={generateInvoice} disabled={saving}>Generate Invoice</button>
                      )}
                    </div>
                  ) : (
                    <div>
                      <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 12 }}>No estimate yet. Select services and parts:</p>
                      <FormGroup label="Services">
                        <select multiple style={{ height: 100 }} onChange={e => setEstimateForm(p => ({ ...p, serviceIds: Array.from(e.target.selectedOptions, o => o.value) }))}>
                          {services.map(s => <option key={s.id} value={s.id}>{s.serviceName} — {formatCurrency(s.laborCharge)}</option>)}
                        </select>
                      </FormGroup>
                      <div className="form-row">
                        <FormGroup label="Discount (₹)"><input type="number" value={estimateForm.discount} onChange={e => setEstimateForm(p => ({ ...p, discount: e.target.value }))} /></FormGroup>
                        <FormGroup label="Tax %"><input type="number" value={estimateForm.taxPercent} onChange={e => setEstimateForm(p => ({ ...p, taxPercent: e.target.value }))} /></FormGroup>
                      </div>
                      <button className="btn btn-primary btn-sm" onClick={createEstimate} disabled={saving}>Create Estimate</button>
                    </div>
                  )}
                </div>
              )}

              {tab === 'invoice' && (
                <div>
                  {invoice ? (
                    <div>
                      <div className="info-grid" style={{ marginBottom: 12 }}>
                        <div className="info-item"><div className="info-label">Invoice No</div><div className="info-value mono" style={{ fontSize: 12 }}>{invoice.invoiceNo}</div></div>
                        <div className="info-item"><div className="info-label">Total</div><div className="info-value">{formatCurrency(invoice.totalAmount)}</div></div>
                        <div className="info-item"><div className="info-label">Paid</div><div className="info-value" style={{ color: 'var(--success)' }}>{formatCurrency(invoice.paidAmount)}</div></div>
                        <div className="info-item"><div className="info-label">Balance</div><div className="info-value" style={{ color: 'var(--danger)' }}>{formatCurrency(invoice.balanceAmount)}</div></div>
                        <div className="info-item"><div className="info-label">Status</div><div className="info-value"><span className={`badge badge-${invoice.paymentStatus?.toLowerCase()}`}>{invoice.paymentStatus}</span></div></div>
                      </div>
                      {invoice.paymentStatus !== 'PAID' && (
                        <div style={{ background: 'var(--bg-elevated)', borderRadius: 'var(--radius)', padding: 12, marginTop: 12 }}>
                          <div style={{ fontSize: 11, fontFamily: 'var(--font-mono)', color: 'var(--text-muted)', marginBottom: 10 }}>RECORD PAYMENT</div>
                          <div className="form-row">
                            <FormGroup label="Amount"><input type="number" value={paymentForm.amount} onChange={e => setPaymentForm(p => ({ ...p, amount: e.target.value }))} /></FormGroup>
                            <FormGroup label="Mode">
                              <select value={paymentForm.mode} onChange={e => setPaymentForm(p => ({ ...p, mode: e.target.value }))}>
                                {PAYMENT_MODES.map(m => <option key={m}>{m}</option>)}
                              </select>
                            </FormGroup>
                          </div>
                          <button className="btn btn-primary btn-sm" onClick={recordPayment} disabled={saving || !paymentForm.amount}>Record Payment</button>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div style={{ color: 'var(--text-muted)', fontSize: 13 }}>
                      No invoice generated yet. Approve estimate first.
                    </div>
                  )}
                </div>
              )}

              {tab === 'qc' && (
                <div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 14 }}>
                    {[['engineCheck','Engine Check'],['brakeCheck','Brake Check'],['lightCheck','Light Check'],['tiresCheck','Tyres Check'],['cleanlinessCheck','Cleanliness'],['roadTestDone','Road Test']].map(([key, label]) => (
                      <label key={key} style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', fontSize: 13 }}>
                        <input type="checkbox" checked={qcForm[key]} onChange={e => setQcForm(p => ({ ...p, [key]: e.target.checked }))} style={{ width: 'auto' }} />
                        {label}
                      </label>
                    ))}
                  </div>
                  <FormGroup label="Remarks"><textarea rows={2} value={qcForm.remarks} onChange={e => setQcForm(p => ({ ...p, remarks: e.target.value }))} /></FormGroup>
                  <button className="btn btn-primary btn-sm" onClick={submitQc} disabled={saving}>Submit QC</button>
                  {qc && (
                    <div style={{ marginTop: 12, padding: 10, background: 'var(--bg-elevated)', borderRadius: 'var(--radius)', fontSize: 12 }}>
                      <div>Last QC: <span className={`badge badge-${qc.passed ? 'approved' : 'cancelled'}`}>{qc.passed ? 'PASSED' : 'FAILED'}</span></div>
                      {qc.remarks && <div style={{ color: 'var(--text-muted)', marginTop: 4 }}>{qc.remarks}</div>}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Right column */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {/* Customer & Vehicle */}
            <div className="card">
              <div className="card-title" style={{ marginBottom: 12 }}>Customer & Vehicle</div>
              <div style={{ marginBottom: 14 }}>
                <div style={{ fontSize: 11, fontFamily: 'var(--font-mono)', color: 'var(--text-muted)', marginBottom: 6 }}>CUSTOMER</div>
                <div style={{ fontWeight: 600 }}>{jc.customer?.name}</div>
                <div style={{ fontSize: 12, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>{jc.customer?.phone}</div>
                <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{jc.customer?.email}</div>
              </div>
              <div className="divider" />
              <div>
                <div style={{ fontSize: 11, fontFamily: 'var(--font-mono)', color: 'var(--text-muted)', marginBottom: 6 }}>VEHICLE</div>
                <div style={{ fontWeight: 600 }}>{jc.vehicle?.make} {jc.vehicle?.model} {jc.vehicle?.year}</div>
                <div style={{ fontSize: 12, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>Reg: {jc.vehicle?.regNo || '—'}</div>
                <div style={{ fontSize: 12, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>Chassis: {jc.vehicle?.chassisNo}</div>
                <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{jc.vehicle?.color} · {jc.vehicle?.fuelType}</div>
              </div>
            </div>

            {/* Update Status */}
            <div className="card">
              <div className="card-title" style={{ marginBottom: 12 }}>Update Status</div>
              <FormGroup label="New Status">
                <select value={statusForm.status} onChange={e => setStatusForm(p => ({ ...p, status: e.target.value }))}>
                  {JOB_STATUSES.map(s => <option key={s} value={s}>{s.replace(/_/g,' ')}</option>)}
                </select>
              </FormGroup>
              <FormGroup label="Remarks">
                <input value={statusForm.remarks} onChange={e => setStatusForm(p => ({ ...p, remarks: e.target.value }))} placeholder="Optional remarks..." />
              </FormGroup>
              <div style={{ display: 'flex', gap: 8 }}>
                <button className="btn btn-primary btn-sm" onClick={updateStatus} disabled={saving}>Update Status</button>
                {jc.status === 'READY_FOR_DELIVERY' && (
                  <button className="btn btn-secondary btn-sm" onClick={() => jobCardAPI.deliver(id).then(load)}>Mark Delivered</button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
