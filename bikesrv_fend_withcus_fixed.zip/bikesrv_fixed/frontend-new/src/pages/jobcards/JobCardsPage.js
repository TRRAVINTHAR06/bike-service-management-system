import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { jobCardAPI, customerAPI, vehicleAPI, branchAPI } from '../../services/api';
import { Modal, Badge, Loading, EmptyState, FormGroup, Topbar, Alert } from '../../components/ui';
import { formatDate, formatDateTime, JOB_STATUSES, SERVICE_TYPES } from '../../utils/helpers';

function NewJobCardForm({ onSave, onClose }) {
  const [step, setStep] = useState(1);
  const [customers, setCustomers] = useState([]);
  const [vehicles, setVehicles] = useState([]);
  const [searchPhone, setSearchPhone] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [form, setForm] = useState({
    branchId: 1, customerId: '', vehicleId: '', serviceType: 'PAID_SERVICE',
    odometerIn: '', customerInstructions: '', insuranceClaim: false, complaints: ['']
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const searchCustomer = async () => {
    if (!searchPhone) return;
    try {
      const res = await customerAPI.getByPhone(searchPhone);
      setSelectedCustomer(res.data);
      setForm(p => ({ ...p, customerId: res.data.id }));
      const vRes = await vehicleAPI.getByCustomer(res.data.id);
      setVehicles(vRes.data || []);
    } catch { setError('Customer not found'); }
  };

  const submit = async (e) => {
    e.preventDefault(); setLoading(true); setError('');
    try {
      const payload = {
        ...form,
        customerId: Number(form.customerId),
        vehicleId: Number(form.vehicleId),
        odometerIn: form.odometerIn ? Number(form.odometerIn) : null,
        complaints: form.complaints.filter(c => c.trim()),
      };
      await jobCardAPI.create(payload);
      onSave();
    } catch (err) { setError(err?.message || 'Failed to create job card'); }
    finally { setLoading(false); }
  };

  return (
    <form onSubmit={submit}>
      {error && <Alert type="error">{error}</Alert>}

      {step === 1 && (
        <>
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 12, fontFamily: 'var(--font-mono)' }}>Step 1 of 2 — Find Customer</div>
            <div style={{ display: 'flex', gap: 8 }}>
              <input placeholder="Search by phone number" value={searchPhone} onChange={e => setSearchPhone(e.target.value)} onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), searchCustomer())} />
              <button type="button" className="btn btn-secondary" onClick={searchCustomer}>Search</button>
            </div>
          </div>

          {selectedCustomer && (
            <div style={{ background: 'var(--bg-elevated)', border: '1px solid var(--accent-border)', borderRadius: 'var(--radius)', padding: 14, marginBottom: 16 }}>
              <div style={{ fontWeight: 600, color: 'var(--accent)' }}>{selectedCustomer.name}</div>
              <div style={{ fontSize: 12, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>{selectedCustomer.phone} · {selectedCustomer.email}</div>
            </div>
          )}

          {vehicles.length > 0 && (
            <FormGroup label="Select Vehicle *">
              <select value={form.vehicleId} onChange={e => setForm(p => ({ ...p, vehicleId: e.target.value }))} required>
                <option value="">-- select vehicle --</option>
                {vehicles.map(v => <option key={v.id} value={v.id}>{v.make} {v.model} ({v.regNo || v.chassisNo})</option>)}
              </select>
            </FormGroup>
          )}

          <div className="modal-footer">
            <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
            <button type="button" className="btn btn-primary" onClick={() => setStep(2)} disabled={!form.vehicleId}>Next →</button>
          </div>
        </>
      )}

      {step === 2 && (
        <>
          <div style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 16, fontFamily: 'var(--font-mono)' }}>Step 2 of 2 — Job Details</div>
          <div className="form-row">
            <FormGroup label="Service Type *">
              <select value={form.serviceType} onChange={e => setForm(p => ({ ...p, serviceType: e.target.value }))}>
                {SERVICE_TYPES.map(t => <option key={t} value={t}>{t.replace(/_/g, ' ')}</option>)}
              </select>
            </FormGroup>
            <FormGroup label="Odometer In (km)">
              <input type="number" value={form.odometerIn} onChange={e => setForm(p => ({ ...p, odometerIn: e.target.value }))} />
            </FormGroup>
          </div>
          <FormGroup label="Customer Instructions">
            <textarea rows={2} value={form.customerInstructions} onChange={e => setForm(p => ({ ...p, customerInstructions: e.target.value }))} />
          </FormGroup>
          <FormGroup label="Complaints (one per line)">
            <textarea rows={3} value={form.complaints.join('\n')} onChange={e => setForm(p => ({ ...p, complaints: e.target.value.split('\n') }))} placeholder="Engine noise&#10;Brake issue&#10;..." />
          </FormGroup>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
            <input type="checkbox" id="insurance" checked={form.insuranceClaim} onChange={e => setForm(p => ({ ...p, insuranceClaim: e.target.checked }))} style={{ width: 'auto' }} />
            <label htmlFor="insurance" style={{ fontSize: 13, color: 'var(--text-secondary)' }}>Insurance Claim</label>
          </div>
          {form.insuranceClaim && (
            <FormGroup label="Insurance Claim No">
              <input value={form.insuranceClaimNo || ''} onChange={e => setForm(p => ({ ...p, insuranceClaimNo: e.target.value }))} />
            </FormGroup>
          )}
          <div className="modal-footer">
            <button type="button" className="btn btn-secondary" onClick={() => setStep(1)}>← Back</button>
            <button type="submit" className="btn btn-primary" disabled={loading}>{loading ? 'Creating...' : 'Create Job Card'}</button>
          </div>
        </>
      )}
    </form>
  );
}

export default function JobCardsPage() {
  const [jobCards, setJobCards] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('ALL');
  const [showModal, setShowModal] = useState(false);
  const navigate = useNavigate();

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = filter === 'ALL'
        ? await jobCardAPI.getByBranch(1)
        : await jobCardAPI.getByBranchAndStatus(1, filter);
      setJobCards(res.data || []);
    } finally { setLoading(false); }
  }, [filter]);

  useEffect(() => { load(); }, [load]);

  const statusFilters = ['ALL', 'CREATED', 'IN_PROGRESS', 'QC_PENDING', 'READY_FOR_DELIVERY', 'DELIVERED'];

  return (
    <>
      <Topbar title="Job Cards" subtitle={`${jobCards.length} records`}
        actions={<button className="btn btn-primary" onClick={() => setShowModal(true)}>+ New Job Card</button>}
      />
      <div className="page-content">
        <div className="tab-row" style={{ marginBottom: 16 }}>
          {statusFilters.map(s => (
            <button key={s} className={`tab ${filter === s ? 'active' : ''}`} onClick={() => setFilter(s)}>
              {s.replace(/_/g, ' ')}
            </button>
          ))}
        </div>

        <div className="card">
          {loading ? <Loading /> : (
            <div className="table-wrap">
              <table>
                <thead><tr>
                  <th>Job Card No</th><th>Customer</th><th>Vehicle</th>
                  <th>Service Type</th><th>Odometer</th><th>Status</th>
                  <th>Created</th><th>Actions</th>
                </tr></thead>
                <tbody>
                  {jobCards.length === 0 ? (
                    <tr><td colSpan={8}><EmptyState message="No job cards found" icon="◈" /></td></tr>
                  ) : jobCards.map(jc => (
                    <tr key={jc.id}>
                      <td><span className="mono" style={{ color: 'var(--accent)', fontSize: 11 }}>{jc.jobCardNo}</span></td>
                      <td><span style={{ fontWeight: 500 }}>{jc.customer?.name || '—'}</span></td>
                      <td style={{ fontSize: 12 }}>{jc.vehicle ? `${jc.vehicle.make} ${jc.vehicle.model}` : '—'}</td>
                      <td style={{ fontSize: 11 }}>{jc.serviceType?.replace(/_/g,' ') || '—'}</td>
                      <td className="mono" style={{ fontSize: 12 }}>{jc.odometerIn ? `${jc.odometerIn} km` : '—'}</td>
                      <td><span className={`badge badge-${jc.status?.toLowerCase()}`}>{jc.status?.replace(/_/g,' ')}</span></td>
                      <td style={{ fontSize: 11, color: 'var(--text-muted)' }}>{formatDate(jc.createdAt)}</td>
                      <td><button className="btn btn-ghost btn-sm" onClick={() => navigate(`/job-cards/${jc.id}`)}>View →</button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {showModal && (
        <Modal title="New Job Card" size="lg" onClose={() => setShowModal(false)}>
          <NewJobCardForm onSave={() => { setShowModal(false); load(); }} onClose={() => setShowModal(false)} />
        </Modal>
      )}
    </>
  );
}
