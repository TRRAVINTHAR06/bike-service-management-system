import React, { useState, useEffect } from 'react';
import { invoiceAPI, branchAPI, serviceCatalogAPI, vehicleAPI, customerAPI } from '../../services/api';
import { Loading, EmptyState, Modal, FormGroup, Alert, Topbar, StatCard } from '../../components/ui';
import { formatCurrency, formatDate, SERVICE_TYPES } from '../../utils/helpers';

export function InvoicesPage() {
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    invoiceAPI.getByCustomer && setLoading(true);
    import('../../services/api').then(({ invoiceAPI: api }) => {
      api.getById && setLoading(false);
    });
    setLoading(false);
    setInvoices([]);
  }, []);

  return (
    <>
      <Topbar title="Invoices" subtitle="All invoices" />
      <div className="page-content">
        <div style={{ padding: '60px 20px', textAlign: 'center', color: 'var(--text-muted)' }}>
          <div style={{ fontSize: 32, marginBottom: 12, opacity: 0.3 }}>◫</div>
          <p style={{ fontSize: 13 }}>To view an invoice, navigate to a Job Card and open the Invoice tab.</p>
          <p style={{ fontSize: 12, marginTop: 6, fontFamily: 'var(--font-mono)' }}>Invoices are linked 1:1 to job cards.</p>
        </div>
      </div>
    </>
  );
}

export function BranchesPage() {
  const [branches, setBranches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ name:'', address:'', city:'', state:'', pincode:'', phone:'', email:'' });
  const [error, setError] = useState('');

  const load = async () => {
    setLoading(true);
    try { const res = await branchAPI.getAll(); setBranches(res.data || []); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, []);

  const openEdit = (b) => { setEditing(b); setForm(b || { name:'', address:'', city:'', state:'', pincode:'', phone:'', email:'' }); setShowModal(true); };

  const submit = async (e) => {
    e.preventDefault(); setError('');
    try {
      if (editing?.id) await branchAPI.update(editing.id, form);
      else await branchAPI.create(form);
      setShowModal(false); setEditing(null); load();
    } catch (err) { setError(err?.message || 'Failed'); }
  };

  const f = k => e => setForm(p => ({ ...p, [k]: e.target.value }));

  return (
    <>
      <Topbar title="Branches" subtitle={`${branches.length} branches`}
        actions={<button className="btn btn-primary" onClick={() => openEdit(null)}>+ New Branch</button>}
      />
      <div className="page-content">
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px,1fr))', gap: 16 }}>
          {loading ? <Loading /> : branches.map(b => (
            <div key={b.id} className="card">
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
                <div style={{ fontWeight: 700, fontSize: 15 }}>{b.name}</div>
                <span className={`badge ${b.active ? 'badge-active' : 'badge-cancelled'}`}>{b.active ? 'Active' : 'Inactive'}</span>
              </div>
              <div style={{ fontSize: 12, color: 'var(--text-muted)', lineHeight: 1.8 }}>
                <div>{b.address}</div>
                <div>{b.city}, {b.state} {b.pincode}</div>
                <div className="mono" style={{ marginTop: 6 }}>{b.phone}</div>
                <div>{b.email}</div>
              </div>
              <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
                <button className="btn btn-secondary btn-sm" onClick={() => openEdit(b)}>Edit</button>
                <button className="btn btn-danger btn-sm" onClick={() => branchAPI.delete(b.id).then(load)}>Deactivate</button>
              </div>
            </div>
          ))}
        </div>
      </div>
      {showModal && (
        <Modal title={editing ? 'Edit Branch' : 'New Branch'} onClose={() => { setShowModal(false); setEditing(null); }}>
          {error && <Alert type="error">{error}</Alert>}
          <form onSubmit={submit}>
            <FormGroup label="Branch Name *"><input value={form.name} onChange={f('name')} required /></FormGroup>
            <FormGroup label="Address *"><textarea rows={2} value={form.address} onChange={f('address')} required /></FormGroup>
            <div className="form-row-3">
              <FormGroup label="City"><input value={form.city} onChange={f('city')} /></FormGroup>
              <FormGroup label="State"><input value={form.state} onChange={f('state')} /></FormGroup>
              <FormGroup label="Pincode"><input value={form.pincode} onChange={f('pincode')} /></FormGroup>
            </div>
            <div className="form-row">
              <FormGroup label="Phone"><input value={form.phone} onChange={f('phone')} /></FormGroup>
              <FormGroup label="Email"><input type="email" value={form.email} onChange={f('email')} /></FormGroup>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
              <button type="submit" className="btn btn-primary">Save Branch</button>
            </div>
          </form>
        </Modal>
      )}
    </>
  );
}

export function ServiceCatalogPage() {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ serviceName:'', serviceType:'PAID_SERVICE', description:'', laborCharge:'', stdMinutes:'', applicableModels:'' });
  const [error, setError] = useState('');

  const load = async () => { setLoading(true); try { const r = await serviceCatalogAPI.getAll(); setServices(r.data || []); } finally { setLoading(false); } };
  useEffect(() => { load(); }, []);

  const openEdit = (s) => { setEditing(s); setForm(s || { serviceName:'', serviceType:'PAID_SERVICE', description:'', laborCharge:'', stdMinutes:'', applicableModels:'' }); setShowModal(true); };

  const submit = async (e) => {
    e.preventDefault(); setError('');
    try {
      if (editing?.id) await serviceCatalogAPI.update(editing.id, form);
      else await serviceCatalogAPI.create(form);
      setShowModal(false); setEditing(null); load();
    } catch (err) { setError(err?.message || 'Failed'); }
  };

  const f = k => e => setForm(p => ({ ...p, [k]: e.target.value }));

  return (
    <>
      <Topbar title="Service Catalog" subtitle={`${services.length} services`}
        actions={<button className="btn btn-primary" onClick={() => openEdit(null)}>+ New Service</button>}
      />
      <div className="page-content">
        <div className="card">
          {loading ? <Loading /> : (
            <div className="table-wrap">
              <table>
                <thead><tr><th>Service Name</th><th>Type</th><th>Labour Charge</th><th>Std Time</th><th>Applicable Models</th><th>Actions</th></tr></thead>
                <tbody>
                  {services.length === 0 ? <tr><td colSpan={6}><EmptyState message="No services defined" icon="◆" /></td></tr>
                  : services.map(s => (
                    <tr key={s.id}>
                      <td style={{ fontWeight: 500 }}>{s.serviceName}</td>
                      <td style={{ fontSize: 11 }}><span className="badge badge-default">{s.serviceType?.replace(/_/g,' ')}</span></td>
                      <td style={{ color: 'var(--accent)' }}>{formatCurrency(s.laborCharge)}</td>
                      <td className="mono" style={{ fontSize: 12 }}>{s.stdMinutes ? `${s.stdMinutes} min` : '—'}</td>
                      <td style={{ fontSize: 11, color: 'var(--text-muted)', maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{s.applicableModels || '—'}</td>
                      <td>
                        <div className="action-menu">
                          <button className="btn btn-ghost btn-sm" onClick={() => openEdit(s)}>Edit</button>
                          <button className="btn btn-danger btn-sm" onClick={() => serviceCatalogAPI.deactivate(s.id).then(load)}>Remove</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
      {showModal && (
        <Modal title={editing ? 'Edit Service' : 'New Service'} onClose={() => { setShowModal(false); setEditing(null); }}>
          {error && <Alert type="error">{error}</Alert>}
          <form onSubmit={submit}>
            <FormGroup label="Service Name *"><input value={form.serviceName} onChange={f('serviceName')} required /></FormGroup>
            <div className="form-row">
              <FormGroup label="Service Type">
                <select value={form.serviceType} onChange={f('serviceType')}>
                  {SERVICE_TYPES.map(t => <option key={t} value={t}>{t.replace(/_/g,' ')}</option>)}
                </select>
              </FormGroup>
              <FormGroup label="Labour Charge (₹)"><input type="number" value={form.laborCharge} onChange={f('laborCharge')} /></FormGroup>
            </div>
            <div className="form-row">
              <FormGroup label="Std Time (minutes)"><input type="number" value={form.stdMinutes} onChange={f('stdMinutes')} /></FormGroup>
              <FormGroup label="Applicable Models"><input value={form.applicableModels} onChange={f('applicableModels')} /></FormGroup>
            </div>
            <FormGroup label="Description"><textarea rows={2} value={form.description} onChange={f('description')} /></FormGroup>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
              <button type="submit" className="btn btn-primary">Save Service</button>
            </div>
          </form>
        </Modal>
      )}
    </>
  );
}

export function VehiclesPage() {
  const [vehicles, setVehicles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ customerId:'', chassisNo:'', engineNo:'', regNo:'', make:'', model:'', year:'', color:'', odometer:'', fuelType:'PETROL' });
  const [phone, setPhone] = useState('');
  const [customer, setCustomer] = useState(null);
  const [error, setError] = useState('');

  const load = async () => {
    setLoading(true);
    try {
      const res = await customerAPI.getAll();
      const cust = res.data || [];
      const all = [];
      for (const c of cust.slice(0,20)) {
        const vr = await vehicleAPI.getByCustomer(c.id);
        (vr.data || []).forEach(v => all.push({ ...v, customer: c }));
      }
      setVehicles(all);
    } finally { setLoading(false); }
  };
  useEffect(() => { load(); }, []);

  const findCust = async () => {
    try { const r = await customerAPI.getByPhone(phone); setCustomer(r.data); setForm(p => ({ ...p, customerId: r.data.id })); }
    catch { setError('Customer not found'); }
  };

  const submit = async (e) => {
    e.preventDefault(); setError('');
    try {
      await vehicleAPI.create({ ...form, customerId: Number(form.customerId), year: Number(form.year), odometer: Number(form.odometer) });
      setShowModal(false); load();
    } catch (err) { setError(err?.message || 'Failed'); }
  };

  const f = k => e => setForm(p => ({ ...p, [k]: e.target.value }));

  return (
    <>
      <Topbar title="Vehicles" subtitle={`${vehicles.length} registered`}
        actions={<button className="btn btn-primary" onClick={() => { setShowModal(true); setCustomer(null); setPhone(''); }}>+ Register Vehicle</button>}
      />
      <div className="page-content">
        <div className="card">
          {loading ? <Loading /> : (
            <div className="table-wrap">
              <table>
                <thead><tr><th>Vehicle</th><th>Owner</th><th>Reg No</th><th>Chassis No</th><th>Odometer</th><th>Fuel</th></tr></thead>
                <tbody>
                  {vehicles.length === 0 ? <tr><td colSpan={6}><EmptyState message="No vehicles found" icon="◎" /></td></tr>
                  : vehicles.map(v => (
                    <tr key={v.id}>
                      <td><div style={{ fontWeight: 600 }}>{v.make} {v.model}</div><div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{v.year} · {v.color}</div></td>
                      <td>{v.customer?.name}<div style={{ fontSize: 11, fontFamily: 'var(--font-mono)', color: 'var(--text-muted)' }}>{v.customer?.phone}</div></td>
                      <td className="mono" style={{ fontSize: 12, color: 'var(--accent)' }}>{v.regNo || '—'}</td>
                      <td className="mono" style={{ fontSize: 11, color: 'var(--text-muted)' }}>{v.chassisNo}</td>
                      <td className="mono" style={{ fontSize: 12 }}>{v.odometer ? `${v.odometer} km` : '—'}</td>
                      <td style={{ fontSize: 12 }}>{v.fuelType || '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
      {showModal && (
        <Modal title="Register Vehicle" size="lg" onClose={() => setShowModal(false)}>
          {error && <Alert type="error">{error}</Alert>}
          <form onSubmit={submit}>
            <div style={{ display:'flex', gap:8, marginBottom:14 }}>
              <input placeholder="Owner phone number" value={phone} onChange={e => setPhone(e.target.value)} />
              <button type="button" className="btn btn-secondary" onClick={findCust}>Find Customer</button>
            </div>
            {customer && <div style={{ padding:'10px 12px', background:'var(--bg-elevated)', borderRadius:'var(--radius)', marginBottom:14, fontSize:13 }}>{customer.name} · {customer.phone}</div>}
            <div className="form-row">
              <FormGroup label="Make *"><input value={form.make} onChange={f('make')} required placeholder="Honda, TVS, Bajaj..." /></FormGroup>
              <FormGroup label="Model *"><input value={form.model} onChange={f('model')} required placeholder="Activa, Apache..." /></FormGroup>
            </div>
            <div className="form-row">
              <FormGroup label="Chassis No *"><input value={form.chassisNo} onChange={f('chassisNo')} required /></FormGroup>
              <FormGroup label="Engine No"><input value={form.engineNo} onChange={f('engineNo')} /></FormGroup>
            </div>
            <div className="form-row-3">
              <FormGroup label="Reg No"><input value={form.regNo} onChange={f('regNo')} /></FormGroup>
              <FormGroup label="Year"><input type="number" value={form.year} onChange={f('year')} /></FormGroup>
              <FormGroup label="Color"><input value={form.color} onChange={f('color')} /></FormGroup>
            </div>
            <div className="form-row">
              <FormGroup label="Odometer (km)"><input type="number" value={form.odometer} onChange={f('odometer')} /></FormGroup>
              <FormGroup label="Fuel Type">
                <select value={form.fuelType} onChange={f('fuelType')}>
                  {['PETROL','DIESEL','ELECTRIC','CNG','HYBRID'].map(t => <option key={t}>{t}</option>)}
                </select>
              </FormGroup>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
              <button type="submit" className="btn btn-primary" disabled={!customer}>Register Vehicle</button>
            </div>
          </form>
        </Modal>
      )}
    </>
  );
}
