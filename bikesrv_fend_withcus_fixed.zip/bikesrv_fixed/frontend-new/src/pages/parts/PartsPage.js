import React, { useState, useEffect, useCallback } from 'react';
import { partsAPI } from '../../services/api';
import { Loading, EmptyState, Modal, FormGroup, Alert, Topbar } from '../../components/ui';
import { formatCurrency } from '../../utils/helpers';

function PartForm({ initial, onSave, onClose }) {
  const [form, setForm] = useState(initial || { partName:'', oemPartNo:'', partCategory:'', applicableModels:'', unit:'pcs', costPrice:'', sellingPrice:'', warrantyMonths:'' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const f = k => e => setForm(p => ({ ...p, [k]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault(); setLoading(true); setError('');
    try {
      if (initial?.id) await partsAPI.update(initial.id, form);
      else await partsAPI.create(form);
      onSave();
    } catch (err) { setError(err?.message || 'Failed'); }
    finally { setLoading(false); }
  };

  return (
    <form onSubmit={submit}>
      {error && <Alert type="error">{error}</Alert>}
      <div className="form-row">
        <FormGroup label="Part Name *"><input value={form.partName} onChange={f('partName')} required /></FormGroup>
        <FormGroup label="OEM Part No"><input value={form.oemPartNo} onChange={f('oemPartNo')} /></FormGroup>
      </div>
      <div className="form-row">
        <FormGroup label="Category"><input value={form.partCategory} onChange={f('partCategory')} placeholder="Engine, Brake, Body..." /></FormGroup>
        <FormGroup label="Unit"><input value={form.unit} onChange={f('unit')} placeholder="pcs, set, litre..." /></FormGroup>
      </div>
      <div className="form-row">
        <FormGroup label="Cost Price (₹)"><input type="number" value={form.costPrice} onChange={f('costPrice')} /></FormGroup>
        <FormGroup label="Selling Price (₹)"><input type="number" value={form.sellingPrice} onChange={f('sellingPrice')} /></FormGroup>
      </div>
      <div className="form-row">
        <FormGroup label="Applicable Models"><input value={form.applicableModels} onChange={f('applicableModels')} placeholder="Honda Activa, TVS Jupiter..." /></FormGroup>
        <FormGroup label="Warranty (months)"><input type="number" value={form.warrantyMonths} onChange={f('warrantyMonths')} /></FormGroup>
      </div>
      <div className="modal-footer">
        <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
        <button type="submit" className="btn btn-primary" disabled={loading}>{loading ? 'Saving...' : 'Save Part'}</button>
      </div>
    </form>
  );
}

export default function PartsPage() {
  const [parts, setParts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = search.length > 2 ? await partsAPI.search(search) : await partsAPI.getAll();
      setParts(res.data || []);
    } finally { setLoading(false); }
  }, [search]);

  useEffect(() => { const t = setTimeout(load, 300); return () => clearTimeout(t); }, [load]);

  return (
    <>
      <Topbar title="Parts Master" subtitle={`${parts.length} parts`}
        actions={<button className="btn btn-primary" onClick={() => { setEditing(null); setShowModal(true); }}>+ New Part</button>}
      />
      <div className="page-content">
        <div className="card">
          <div className="card-header">
            <div className="search-bar">
              <span style={{ color: 'var(--text-muted)' }}>⌕</span>
              <input placeholder="Search by name or OEM part no..." value={search} onChange={e => setSearch(e.target.value)} />
            </div>
          </div>
          {loading ? <Loading /> : (
            <div className="table-wrap">
              <table>
                <thead><tr>
                  <th>Part Name</th><th>OEM Part No</th><th>Category</th>
                  <th>Cost Price</th><th>Selling Price</th><th>Warranty</th><th>Models</th><th>Actions</th>
                </tr></thead>
                <tbody>
                  {parts.length === 0 ? <tr><td colSpan={8}><EmptyState message="No parts found" icon="⬡" /></td></tr>
                  : parts.map(p => (
                    <tr key={p.id}>
                      <td style={{ fontWeight: 500 }}>{p.partName}</td>
                      <td className="mono" style={{ fontSize: 11, color: 'var(--accent)' }}>{p.oemPartNo || '—'}</td>
                      <td style={{ fontSize: 12 }}>{p.partCategory || '—'}</td>
                      <td>{formatCurrency(p.costPrice)}</td>
                      <td style={{ color: 'var(--success)' }}>{formatCurrency(p.sellingPrice)}</td>
                      <td style={{ fontSize: 12 }}>{p.warrantyMonths ? `${p.warrantyMonths}m` : '—'}</td>
                      <td style={{ fontSize: 11, color: 'var(--text-muted)', maxWidth: 140, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.applicableModels || '—'}</td>
                      <td>
                        <div className="action-menu">
                          <button className="btn btn-ghost btn-sm" onClick={() => { setEditing(p); setShowModal(true); }}>Edit</button>
                          <button className="btn btn-danger btn-sm" onClick={() => partsAPI.deactivate(p.id).then(load)}>Remove</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {showModal && (
        <Modal title={editing ? 'Edit Part' : 'New Part'} size="lg" onClose={() => { setShowModal(false); setEditing(null); }}>
          <PartForm initial={editing} onSave={() => { setShowModal(false); setEditing(null); load(); }} onClose={() => { setShowModal(false); setEditing(null); }} />
        </Modal>
      )}
    </>
  );
}
