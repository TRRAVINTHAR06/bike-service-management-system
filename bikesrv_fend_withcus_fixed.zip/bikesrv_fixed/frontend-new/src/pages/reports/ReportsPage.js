import React, { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import { dashboardAPI, jobCardAPI } from '../../services/api';
import { StatCard, Loading, Topbar } from '../../components/ui';
import { formatCurrency } from '../../utils/helpers';

const COLORS = ['#f97316','#3b82f6','#22c55e','#a855f7','#ef4444','#eab308'];

export default function ReportsPage() {
  const [summary, setSummary] = useState(null);
  const [revenue, setRevenue] = useState(null);
  const [loading, setLoading] = useState(true);
  const branchId = 1;

  const from = new Date();
  from.setDate(from.getDate() - 30);
  const to = new Date();

  useEffect(() => {
    async function load() {
      setLoading(true);
      try {
        const [sRes, rRes] = await Promise.all([
          dashboardAPI.getSummary(branchId),
          dashboardAPI.getRevenue(branchId, from.toISOString(), to.toISOString()),
        ]);
        setSummary(sRes.data);
        setRevenue(rRes.data);
      } catch (e) { console.error(e); }
      finally { setLoading(false); }
    }
    load();
  }, []);

  const statusData = summary ? [
    { name: 'Created', value: summary.created || 0 },
    { name: 'In Progress', value: summary.inProgress || 0 },
    { name: 'QC Pending', value: summary.qcPending || 0 },
    { name: 'Ready', value: summary.readyForDelivery || 0 },
    { name: 'Delivered', value: summary.delivered || 0 },
  ] : [];

  if (loading) return <Loading />;

  return (
    <>
      <Topbar title="Reports" subtitle="Branch 1 · Last 30 days" />
      <div className="page-content">
        <div className="grid-4" style={{ marginBottom: 24 }}>
          <StatCard label="Total Job Cards" value={summary?.totalJobCards || 0} color="var(--accent)" />
          <StatCard label="Revenue (30d)" value={formatCurrency(revenue?.totalRevenue || 0)} color="var(--success)" />
          <StatCard label="Invoices (30d)" value={revenue?.invoiceCount || 0} color="var(--info)" />
          <StatCard label="Delivered" value={summary?.delivered || 0} color="#6b7280" />
        </div>

        <div className="grid-2" style={{ gap: 16 }}>
          <div className="card">
            <div className="card-header">
              <span className="card-title">Job Card Status Breakdown</span>
            </div>
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={statusData} barSize={36}>
                <XAxis dataKey="name" tick={{ fill: '#9a9a98', fontSize: 10, fontFamily: 'JetBrains Mono' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: '#9a9a98', fontSize: 10 }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ background: '#1c1f22', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 6, fontSize: 12 }} cursor={{ fill: 'rgba(255,255,255,0.03)' }} />
                <Bar dataKey="value" radius={[4,4,0,0]}>
                  {statusData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="card">
            <div className="card-header">
              <span className="card-title">Status Distribution</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
              <ResponsiveContainer width="50%" height={200}>
                <PieChart>
                  <Pie data={statusData.filter(d => d.value > 0)} dataKey="value" cx="50%" cy="50%" outerRadius={80} innerRadius={40}>
                    {statusData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Pie>
                  <Tooltip contentStyle={{ background: '#1c1f22', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 6, fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
              <div style={{ flex: 1 }}>
                {statusData.map((d, i) => (
                  <div key={d.name} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                    <div style={{ width: 8, height: 8, borderRadius: '50%', background: COLORS[i % COLORS.length], flexShrink: 0 }} />
                    <span style={{ fontSize: 12, color: 'var(--text-secondary)', flex: 1 }}>{d.name}</span>
                    <span style={{ fontSize: 12, fontFamily: 'var(--font-mono)', fontWeight: 700 }}>{d.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="card" style={{ marginTop: 16 }}>
          <div className="card-header">
            <span className="card-title">Revenue Summary — Last 30 Days</span>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20, padding: '10px 0' }}>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 11, fontFamily: 'var(--font-mono)', color: 'var(--text-muted)', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '1px' }}>Total Revenue</div>
              <div style={{ fontSize: 32, fontWeight: 800, color: 'var(--success)', letterSpacing: '-1px' }}>{formatCurrency(revenue?.totalRevenue || 0)}</div>
            </div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 11, fontFamily: 'var(--font-mono)', color: 'var(--text-muted)', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '1px' }}>Invoices Raised</div>
              <div style={{ fontSize: 32, fontWeight: 800, letterSpacing: '-1px' }}>{revenue?.invoiceCount || 0}</div>
            </div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 11, fontFamily: 'var(--font-mono)', color: 'var(--text-muted)', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '1px' }}>Avg per Invoice</div>
              <div style={{ fontSize: 32, fontWeight: 800, color: 'var(--accent)', letterSpacing: '-1px' }}>
                {revenue?.invoiceCount > 0 ? formatCurrency((revenue.totalRevenue || 0) / revenue.invoiceCount) : '₹0'}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
