import axios from 'axios';

const API_BASE = 'http://localhost:8080/api';

const api = axios.create({ baseURL: API_BASE });

api.interceptors.request.use(config => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  res => res.data,
  err => {
    if (err.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(err.response?.data || err);
  }
);

export const authAPI = {
  login: (data) => api.post('/auth/login', data),
  register: (data) => api.post('/auth/register', data),
  forgotPassword: (data) => api.post('/auth/forgot-password', data),
  resetPassword: (data) => api.post('/auth/reset-password', data),
};

export const customerAuthAPI = {
  register: (data) => api.post('/customer/auth/register', data),
  login: (data) => api.post('/customer/auth/login', data),
};

export const customerPortalAPI = {
  getProfile: () => api.get('/customer/profile'),
  updateProfile: (data) => api.put('/customer/profile', data),
  getBikes: () => api.get('/customer/bikes'),
  addBike: (data) => api.post('/customer/bikes', data),
  updateBike: (id, data) => api.put(`/customer/bikes/${id}`, data),
  deleteBike: (id) => api.delete(`/customer/bikes/${id}`),
  getAppointments: () => api.get('/customer/appointments'),
  bookAppointment: (data) => api.post('/customer/appointments', data),
  getServiceHistory: () => api.get('/customer/service-history'),
  getServiceDetail: (jobCardId) => api.get(`/customer/service-history/${jobCardId}`),
  trackStatus: () => api.get('/customer/status'),
  getInvoices: () => api.get('/customer/invoices'),
  getInvoicePayments: (invoiceId) => api.get(`/customer/invoices/${invoiceId}/payments`),
  submitFeedback: (data) => api.post('/customer/feedback', data),
  getMyFeedback: () => api.get('/customer/feedback'),
  submitModificationRequest: (data) => api.post('/customer/modification-requests', data),
  getModificationRequests: () => api.get('/customer/modification-requests'),
  getBranches: () => api.get('/customer/branches'),
};

export const branchAPI = {
  getAll: () => api.get('/branches'),
  getActive: () => api.get('/branches/active'),
  getById: (id) => api.get(`/branches/${id}`),
  create: (data) => api.post('/branches', data),
  update: (id, data) => api.put(`/branches/${id}`, data),
  delete: (id) => api.delete(`/branches/${id}`),
};

export const customerAPI = {
  getAll: () => api.get('/customers'),
  getById: (id) => api.get(`/customers/${id}`),
  getByPhone: (phone) => api.get(`/customers/phone/${phone}`),
  getByBranch: (branchId) => api.get(`/customers/branch/${branchId}`),
  search: (query) => api.get(`/customers/search?query=${query}`),
  create: (data) => api.post('/customers', data),
  update: (id, data) => api.put(`/customers/${id}`, data),
};

export const vehicleAPI = {
  getById: (id) => api.get(`/vehicles/${id}`),
  getByCustomer: (customerId) => api.get(`/vehicles/customer/${customerId}`),
  getByChassis: (chassisNo) => api.get(`/vehicles/chassis/${chassisNo}`),
  create: (data) => api.post('/vehicles', data),
  update: (id, data) => api.put(`/vehicles/${id}`, data),
};

export const jobCardAPI = {
  getAll: () => api.get('/job-cards'),
  getById: (id) => api.get(`/job-cards/${id}`),
  getByNo: (no) => api.get(`/job-cards/no/${no}`),
  getByBranch: (branchId) => api.get(`/job-cards/branch/${branchId}`),
  getByCustomer: (customerId) => api.get(`/job-cards/customer/${customerId}`),
  getByVehicle: (vehicleId) => api.get(`/job-cards/vehicle/${vehicleId}`),
  getByStatus: (status) => api.get(`/job-cards/status/${status}`),
  getByBranchAndStatus: (branchId, status) => api.get(`/job-cards/branch/${branchId}/status/${status}`),
  create: (data) => api.post('/job-cards', data),
  updateStatus: (id, data) => api.patch(`/job-cards/${id}/status`, data),
  deliver: (id, odometer) => api.patch(`/job-cards/${id}/deliver${odometer ? `?odometerOut=${odometer}` : ''}`),
};

export const appointmentAPI = {
  getByBranch: (branchId) => api.get(`/appointments/branch/${branchId}`),
  getByCustomer: (customerId) => api.get(`/appointments/customer/${customerId}`),
  getById: (id) => api.get(`/appointments/${id}`),
  create: (data) => api.post('/appointments', data),
  updateStatus: (id, status) => api.patch(`/appointments/${id}/status?status=${status}`),
};

export const partsAPI = {
  getAll: () => api.get('/parts'),
  getById: (id) => api.get(`/parts/${id}`),
  search: (query) => api.get(`/parts/search?query=${query}`),
  create: (data) => api.post('/parts', data),
  update: (id, data) => api.put(`/parts/${id}`, data),
  deactivate: (id) => api.delete(`/parts/${id}`),
};

export const inventoryAPI = {
  getByBranch: (branchId) => api.get(`/inventory/branch/${branchId}`),
  getLowStock: (branchId) => api.get(`/inventory/branch/${branchId}/low-stock`),
  getStock: (branchId, partId) => api.get(`/inventory/branch/${branchId}/part/${partId}`),
  addOrUpdate: (data) => api.post('/inventory', data),
  addStock: (branchId, partId, qty) => api.patch(`/inventory/branch/${branchId}/part/${partId}/add?qty=${qty}`),
};

export const serviceCatalogAPI = {
  getAll: () => api.get('/services'),
  getById: (id) => api.get(`/services/${id}`),
  getByType: (type) => api.get(`/services/type/${type}`),
  create: (data) => api.post('/services', data),
  update: (id, data) => api.put(`/services/${id}`, data),
  deactivate: (id) => api.delete(`/services/${id}`),
};

export const estimateAPI = {
  getByJobCard: (jobCardId) => api.get(`/estimates/job-card/${jobCardId}`),
  create: (data) => api.post('/estimates', data),
  approve: (jobCardId, approvedBy) => api.patch(`/estimates/job-card/${jobCardId}/approve?approvedBy=${approvedBy}`),
  reject: (jobCardId, remarks) => api.patch(`/estimates/job-card/${jobCardId}/reject?remarks=${remarks}`),
};

export const invoiceAPI = {
  getById: (id) => api.get(`/invoices/${id}`),
  getByJobCard: (jobCardId) => api.get(`/invoices/job-card/${jobCardId}`),
  getByCustomer: (customerId) => api.get(`/invoices/customer/${customerId}`),
  generate: (jobCardId) => api.post(`/invoices/generate/${jobCardId}`),
  recordPayment: (data) => api.post('/invoices/payments', data),
  getPayments: (invoiceId) => api.get(`/invoices/${invoiceId}/payments`),
};

export const qcAPI = {
  getByJobCard: (jobCardId) => api.get(`/qc/job-card/${jobCardId}`),
  submit: (data) => api.post('/qc', data),
};

export const bayAPI = {
  getByBranch: (branchId) => api.get(`/bays/branch/${branchId}`),
  create: (data) => api.post('/bays', data),
  updateStatus: (id, status) => api.patch(`/bays/${id}/status?status=${status}`),
};

export const dashboardAPI = {
  getSummary: (branchId) => api.get(`/dashboard/branch/${branchId}/summary`),
  getRevenue: (branchId, from, to) => api.get(`/dashboard/branch/${branchId}/revenue?from=${from}&to=${to}`),
};

export const technicianAPI = {
  assign: (data) => api.post('/technician-assignments', data),
  getByJobCard: (jobCardId) => api.get(`/technician-assignments/job-card/${jobCardId}`),
  getByTechnician: (id) => api.get(`/technician-assignments/technician/${id}`),
  complete: (id, actualMinutes) => api.patch(`/technician-assignments/${id}/complete${actualMinutes ? `?actualMinutes=${actualMinutes}` : ''}`),
};

export default api;
