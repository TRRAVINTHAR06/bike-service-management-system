export const formatCurrency = (amount) => {
  if (amount == null) return '₹0';
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(amount);
};

export const formatDate = (dateStr) => {
  if (!dateStr) return '—';
  return new Date(dateStr).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
};

export const formatDateTime = (dateStr) => {
  if (!dateStr) return '—';
  return new Date(dateStr).toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
};

export const statusColor = (status) => {
  const map = {
    CREATED: 'created', INSPECTED: 'inspected', IN_PROGRESS: 'in_progress',
    ON_HOLD: 'default', QC_PENDING: 'qc_pending', QC_PASSED: 'qc_passed',
    READY_FOR_DELIVERY: 'ready_for_delivery', DELIVERED: 'delivered', CANCELLED: 'cancelled',
    PENDING: 'pending', APPROVED: 'approved', REJECTED: 'default',
    PAID: 'paid', PARTIAL: 'partial', BOOKED: 'created', CONFIRMED: 'approved',
    ARRIVED: 'in_progress', NO_SHOW: 'cancelled', ACTIVE: 'active',
  };
  return map[status?.toUpperCase()] || 'default';
};

export const getInitials = (name) => {
  if (!name) return '?';
  return name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2);
};

export const JOB_STATUSES = [
  'CREATED','INSPECTED','IN_PROGRESS','ON_HOLD','QC_PENDING','QC_PASSED','READY_FOR_DELIVERY','DELIVERED','CANCELLED'
];

export const SERVICE_TYPES = [
  'FREE_SERVICE','PAID_SERVICE','RUNNING_REPAIR','ACCIDENTAL_REPAIR','AMC','EXPRESS_SERVICE','BREAKDOWN'
];

export const PAYMENT_MODES = ['CASH','UPI','CARD','NET_BANKING','INSURANCE','CREDIT','ADVANCE'];

export const USER_ROLES = ['ADMIN','BRANCH_MANAGER','SERVICE_ADVISOR','TECHNICIAN','QC_INSPECTOR','ACCOUNTS','STORE_INCHARGE'];
